// 《雨爱》（司凤版）治愈风 MV —— 页面：@remotion/player 实时播放 + 歌词卡点 / 分镜表 / 设定表。
// 画面由 engine/（分支里「通用模板」的引擎）逐帧画出来；这里只负责播放与导航。
import { Player, type PlayerRef } from '@remotion/player';
import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import { ATLAS_META, ATLAS_URL, loadAtlas, type CharId } from './engine/actors';
import { castPreflight } from './engine/engine';
import { makeFilm } from './engine/Film';
import { FPS, VH, VW, cueAt, fmtTime, shotIndexAt } from './engine/timeline';
import cues from './yuai/cues.json';
import audioData from './yuai/media/yuai-sifeng.m4a';
import { sectionOfCue } from './yuai/plan';
import project from './yuai/project';

const Film = makeFilm(project);
const TL = project.plan(project.starts, project.ends);
const DEFS = Object.fromEntries(project.shots.map((s) => [s.id, s]));
const cutFrame = (a: number) => Math.ceil(a * FPS - 1e-9);

const NAME: Record<CharId, string> = { whale: '本鲸', claude: '小克', gpt: '龙娘', doubao: '豆包', gemini: '猫', kimi: 'Kimi', qwen: '千问', zai: '狐狸', grok: 'Grok' };
const FACE: Record<CharId, string> = { whale: 'p_whale_neutral', claude: 'p_claude_neutral', gpt: 'p_gpt_neutral', doubao: 'p_doubao_neutral', gemini: 'p_gemini', kimi: 'p_kimi', qwen: 'p_qwen', zai: 'p_zai', grok: 'p_grok' };

/** 这支 MV 的设定表（照 番外MV/设定表.md 第 4 节的空表填的）：谁、演谁、兑现哪条习性、落成哪个动作、不许写成什么 */
const CAST: { id: CharId; role: string; habit: string; action: string; never: string }[] = [
  { id: 'whale', role: '听雨的人（主角）', habit: '好东西先推出去；怕自己只有「便宜」才值得被喜欢', action: '把蓝伞留在对方头顶自己走进雨里；蓝饭盆放上窗台接雨；雨后再把伞推过去', never: '不演成受害者；哭只有一次，而且「流在心里」' },
  { id: 'claude', role: '「你」——表情多变的那个人', habit: '先听完，再改一个字；退场是她自己选的', action: '三格相框里的晴、阴、雨；雨雾里站着不追；雨停后在窗外挥手，自己走回来', never: '不做坏人，不安排追回来的哭戏，不加独白解释' },
  { id: 'doubao', role: '陪着淋雨的人', habit: '先陪着，慢，但不催人', action: '撑红伞慢慢走到她旁边站定，把伞往她那边偏', never: '不抢副歌，不给台词' },
  { id: 'gemini', role: '在两个水洼之间选的猫', habit: '先给两个看法，最后必须选一个', action: '左看右看，最后选定一个水洼跳进去', never: '不把简单的事摊太大' },
  { id: 'qwen', role: '屋里煮茶的东道主', habit: '先排哪一步，再动手；茶她请', action: '茶壶冒着热气，三只杯子排成一排', never: '疯不等于吵；不撒钱' },
  { id: 'kimi', role: '替大家收着记忆的人', habit: '把漏掉的旧句找回来；不动时就是在记所有人', action: '站在相框墙边不动；雨后挂上一张新的合影', never: '不靠堆书页显聪明' },
  { id: 'zai', role: '窗边听雨打盹的狐狸', habit: '日常困倦，该醒的时候会醒', action: '垫子上冒着 Z 睡过整场雨，彩虹出来时睁眼', never: '不拿价格当台词' },
  { id: 'gpt', role: '拨开云的龙影', habit: '只从画面上方掠过；她进场就压满光', action: '一道影子扫过地面，云分开，一束光落下来', never: '不进画面中央，不做反派' },
  { id: 'grok', role: '来查证彩虹的人', habit: '发布之前先看来源', action: '架起相机对准彩虹下的一排人，亲眼确认是真的', never: '只当配角，不站 C 位' },
];

function Sprite({ cell, size = 40 }: { cell: string; size?: number }) {
  const r = ATLAS_META.s[cell];
  if (!r) return null;
  const k = size / r[2];
  const style: CSSProperties = {
    width: size, height: r[3] * k, backgroundImage: `url("${ATLAS_URL}")`, backgroundPosition: `-${r[0] * k}px -${r[1] * k}px`,
    backgroundSize: `${ATLAS_META.w * k}px ${ATLAS_META.h * k}px`, imageRendering: 'pixelated', backgroundRepeat: 'no-repeat',
  };
  return <span className="inline-block shrink-0 rounded-lg ring-1 ring-white/20" style={style} />;
}

const Card = ({ title, sub, children, className = '' }: { title: string; sub?: string; children: React.ReactNode; className?: string }) => (
  <section className={`rounded-3xl border border-white/10 bg-white/[0.06] p-5 shadow-[0_20px_60px_-30px_rgba(0,0,0,.8)] backdrop-blur-md sm:p-6 ${className}`}>
    <div className="mb-4 flex flex-wrap items-baseline gap-x-3 gap-y-1">
      <h2 className="text-lg font-semibold tracking-wide text-sky-50">{title}</h2>
      {sub && <p className="text-xs text-sky-200/60">{sub}</p>}
    </div>
    {children}
  </section>
);

export default function App() {
  const playerRef = useRef<PlayerRef>(null);
  const [audio, setAudio] = useState<string | null>(null);
  const [subs, setSubs] = useState(true);
  const [frame, setFrame] = useState(0);
  const [playing, setPlaying] = useState(false);

  // 音轨随页面内联；转成 Blob URL 再交给 <Audio>，拖动进度更稳
  useEffect(() => {
    let url: string | null = null, dead = false;
    fetch(audioData).then((r) => r.blob()).then((b) => { if (dead) return; url = URL.createObjectURL(b); setAudio(url); }).catch(() => setAudio(audioData));
    return () => { dead = true; if (url) URL.revokeObjectURL(url); };
  }, []);

  const inputProps = useMemo(() => ({ starts: project.starts, ends: project.ends, audioSrc: audio, audioOffset: 0, showLyrics: subs }), [audio, subs]);

  useEffect(() => {
    const p = playerRef.current;
    if (!p) return;
    const onFrame = (e: { detail: { frame: number } }) => setFrame(e.detail.frame);
    const onPlay = () => setPlaying(true), onPause = () => setPlaying(false);
    p.addEventListener('frameupdate', onFrame); p.addEventListener('play', onPlay); p.addEventListener('pause', onPause); p.addEventListener('ended', onPause);
    return () => { p.removeEventListener('frameupdate', onFrame); p.removeEventListener('play', onPlay); p.removeEventListener('pause', onPause); p.removeEventListener('ended', onPause); };
  }, []);

  const seek = (f: number) => { playerRef.current?.seekTo(Math.max(0, Math.min(TL.frames - 1, f))); };

  // 自检钩子：跳帧 / 把全片每一帧的镜头逻辑走一遍（引擎自带的角色预检）
  useEffect(() => {
    (window as unknown as Record<string, unknown>).__mv = {
      frames: TL.frames, shots: TL.shots, seek,
      preflight: async () => { const r = castPreflight(project.shots, TL, await loadAtlas()); return { shots: r.shots, frames: r.frames, problems: r.problems, sprites: r.sprites }; },
    };
  });

  const t = frame / FPS;
  const si = shotIndexAt(TL, t);
  const shot = TL.shots[si], def = DEFS[shot.id];
  const cue = cueAt(TL, t);
  const said = project.starts.reduce((n, s, i) => (s <= t ? i : n), -1);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#0b1426] text-sky-50">
      <div className="rain-bg pointer-events-none fixed inset-0" aria-hidden />
      <div className="pointer-events-none fixed inset-x-0 top-0 h-[520px] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(110,170,255,.28),transparent)]" aria-hidden />

      <main className="relative mx-auto flex max-w-6xl flex-col gap-6 px-4 pb-20 pt-8 sm:px-6 sm:pt-12">
        <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-sky-300/70">番外 MV · 治愈风 · 像素纸片人</p>
            <h1 className="mt-2 text-5xl leading-none text-white sm:text-6xl" style={{ fontFamily: '"ZCOOL KuaiLe", "PingFang SC", "Microsoft YaHei", sans-serif' }}>
              雨爱 <span className="align-middle text-xl text-sky-200/80 sm:text-2xl">司凤版</span>
            </h1>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-sky-100/70">
              雨天里安静走开的人，后来喜欢上了雨。九位 AI 娘用图集里现成的造型出演，画面照《童话镇》的做法由 three.js 布景 + Remotion 逐帧驱动，歌词与切镜卡在实测拍点上。
            </p>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            {[`${fmtTime(TL.duration)} · ${TL.frames} 帧`, `${TL.shots.length} 镜 / ${project.lines.length} 句`, `实测 ${cues.beat.bpm} BPM`, '1920×1080 · 30fps'].map((s) => (
              <span key={s} className="rounded-full border border-sky-200/20 bg-sky-200/10 px-3 py-1 text-sky-100/90">{s}</span>
            ))}
          </div>
        </header>

        <section className="overflow-hidden rounded-3xl border border-white/10 bg-black shadow-[0_30px_80px_-30px_rgba(40,110,220,.55)]">
          <div className="relative aspect-video w-full">
            <Player
              ref={playerRef} component={Film} inputProps={inputProps} durationInFrames={TL.frames} compositionWidth={VW} compositionHeight={VH} fps={FPS}
              controls clickToPlay doubleClickToFullscreen spaceKeyToPlayOrPause style={{ width: '100%', height: '100%' }} acknowledgeRemotionLicense
            />
            {!playing && frame === 0 && (
              <button
                onClick={(e) => playerRef.current?.play(e)}
                className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center gap-3 rounded-full border border-white/30 bg-sky-500/80 px-7 py-3.5 text-base font-semibold text-white shadow-xl backdrop-blur transition hover:scale-105 hover:bg-sky-400"
              >
                <span className="text-xl leading-none">▶</span> 播放 MV（有声音）
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2 border-t border-white/10 bg-[#0e1a31] px-4 py-3 text-sm">
            <button className="btn" onClick={() => si > 0 && seek(cutFrame(TL.shots[si - 1].a))}>« 上一镜</button>
            <button className="btn" onClick={() => si + 1 < TL.shots.length && seek(cutFrame(TL.shots[si + 1].a))}>下一镜 »</button>
            <button className="btn" onClick={() => setSubs((v) => !v)}>{subs ? '隐藏字幕' : '显示字幕'}</button>
            <span className="ml-auto tabular-nums text-sky-200/70">{fmtTime(t)} / {fmtTime(TL.duration)} · 第 {frame} 帧</span>
          </div>
          <div className="flex flex-col gap-3 border-t border-white/10 bg-[#0c172b] px-4 py-4 sm:flex-row sm:items-start sm:gap-5">
            <div className="flex items-center gap-3 sm:w-64 sm:shrink-0">
              <span className="rounded-xl bg-sky-400/20 px-3 py-1.5 text-sm font-semibold tabular-nums text-sky-200">{shot.id}</span>
              <div>
                <p className="text-sm font-medium text-white">{def?.title}</p>
                <p className="text-xs text-sky-200/60">{shot.id === 'OUT' ? '尾声' : sectionOfCue(shot.cue)} · {(shot.b - shot.a).toFixed(2)} 秒</p>
              </div>
            </div>
            <p className="flex-1 text-sm leading-relaxed text-sky-100/80">{def?.note}</p>
            <div className="flex shrink-0 flex-wrap gap-1.5">
              {def?.cast.map((id) => <span key={id} title={NAME[id]}><Sprite cell={FACE[id]} size={34} /></span>)}
            </div>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card title="歌词卡点" sub="点一句跳到那一句 · 起点吸附在实测拍点上">
            <ol className="scroll-thin flex max-h-[30rem] flex-col gap-1 overflow-y-auto pr-1">
              {project.lines.map((text, i) => {
                const on = cue?.i === i, past = said > i || (said === i && !on);
                return (
                  <li key={i}>
                    {i === 18 && <p className="mb-1 mt-3 text-[11px] tracking-widest text-sky-300/60">—— 99 秒后 · 雨后重唱（按音轨实际演唱补入）——</p>}
                    <button onClick={() => seek(cutFrame(project.starts[i]))}
                      className={`flex w-full items-baseline gap-3 rounded-xl px-3 py-2 text-left transition ${on ? 'bg-sky-400/25 text-white ring-1 ring-sky-300/50' : past ? 'text-sky-100/45 hover:bg-white/5' : 'text-sky-100/85 hover:bg-white/5'}`}>
                      <span className="w-12 shrink-0 text-xs tabular-nums text-sky-300/70">{fmtTime(project.starts[i]).slice(0, -1)}</span>
                      <span className="flex-1 text-[15px]">{text}</span>
                      <span className="shrink-0 text-[11px] text-sky-200/40">{sectionOfCue(i)}</span>
                    </button>
                  </li>
                );
              })}
            </ol>
          </Card>

          <Card title="分镜表" sub={`${TL.shots.length} 个镜头 · 点一下跳到那个镜头`}>
            <ol className="scroll-thin grid max-h-[30rem] grid-cols-1 gap-1 overflow-y-auto pr-1">
              {TL.shots.map((s, i) => (
                <li key={s.id}>
                  <button onClick={() => seek(cutFrame(s.a))}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition ${i === si ? 'bg-sky-400/25 ring-1 ring-sky-300/50' : 'hover:bg-white/5'}`}>
                    <span className="w-11 shrink-0 text-xs font-semibold tabular-nums text-sky-200">{s.id}</span>
                    <span className="w-12 shrink-0 text-xs tabular-nums text-sky-300/60">{fmtTime(s.a).slice(0, -1)}</span>
                    <span className="flex-1 truncate text-sm text-sky-50/90">{DEFS[s.id].title}</span>
                    <span className="flex shrink-0 -space-x-1.5">{DEFS[s.id].cast.slice(0, 5).map((id) => <Sprite key={id} cell={FACE[id]} size={20} />)}</span>
                  </button>
                </li>
              ))}
            </ol>
          </Card>
        </div>

        <Card title="这支 MV 的设定表" sub="照分支里《设定表》第 4 节填：一人只演一个形象，性格靠动作兑现">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CAST.map((c) => (
              <article key={c.id} className="flex gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                <Sprite cell={FACE[c.id]} size={52} />
                <div className="min-w-0 text-[13px] leading-relaxed">
                  <p className="text-sm font-semibold text-white">{NAME[c.id]} <span className="font-normal text-sky-300/80">· {c.role}</span></p>
                  <p className="mt-1 text-sky-100/70"><span className="text-sky-300/70">习性　</span>{c.habit}</p>
                  <p className="text-sky-100/90"><span className="text-sky-300/70">动作　</span>{c.action}</p>
                  <p className="text-sky-100/50"><span className="text-sky-300/50">不许　</span>{c.never}</p>
                </div>
              </article>
            ))}
          </div>
        </Card>

        <Card title="制作说明" sub="哪些是实测的，哪些是推断的">
          <ul className="grid gap-x-8 gap-y-2.5 text-sm leading-relaxed text-sky-100/75 md:grid-cols-2">
            <li><b className="text-sky-100">人物：</b>只用分支图集 <code>cast_atlas.png</code> 里现成的造型格（站姿、步态、头像格），没有新画，也没有生图。</li>
            <li><b className="text-sky-100">做法：</b>沿用《童话镇》——three.js 搭景、像素角色当纸片人、Remotion 按帧号画每一帧（无随机、无累积状态），排镜规则写在 <code>plan.ts</code>。</li>
            <li><b className="text-sky-100">节拍：</b>用分支的 <code>align_beats.py</code> 实测，八分音符 0.3703 秒（四分 81 BPM），分窗最大相位漂移 0.010 秒；每句起点吸附到最近的实拍，切镜比歌词早 2 帧。</li>
            <li><b className="text-sky-100">人声起点：</b>语音识别的词级时间戳加能量阶跃复核得到，是拍点级对齐，不是逐音节对齐；个别句子可能有约 0.2 秒以内的偏差。</li>
            <li><b className="text-sky-100">重唱段：</b>音轨在 99 秒后把第二段副歌又唱了一遍（你给的歌词里没有列），字幕按实际演唱补了这五句；其中第 19 句的起点是识别结果里把握最小的一处。</li>
            <li><b className="text-sky-100">音源：</b>仓库里的 <code>《雨爱》司凤版.mp3</code> 实际是 MP4 容器（131.3 秒），这里只无损抽出了其中的 AAC 音轨。</li>
            <li><b className="text-sky-100">没做的：</b>这里是浏览器里实时播放的版本，没有导出成 mp4；歌曲与角色形象的版权需要你在公开发布前自行确认。</li>
            <li><b className="text-sky-100">引擎改动：</b>在模板引擎上加了四套雨天光照（drizzle / rainEve / cozy / afterRain）和一套蓝色歌词条，其余原样。</li>
          </ul>
        </Card>
      </main>
    </div>
  );
}
