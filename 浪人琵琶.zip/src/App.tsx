import { useEffect, useMemo, useRef, useState } from "react";
import storyboard from "./storyboard.json";

type Shot = {
  id: string; frame: number; start: number; end: number; line: number | null; lyric: string;
  look?: string; title?: string; cast?: string[]; note?: string; section: string;
};
const SHOTS = storyboard as Shot[];

const NAMES: Record<string, string> = { whale: "本鲸", qwen: "千问", gemini: "Gemini 猫", kimi: "Kimi", doubao: "豆包", gpt: "龙娘", zai: "狐狸", claude: "小克" };
const CAST_COLOR: Record<string, string> = {
  whale: "bg-sky-200 text-sky-900", qwen: "bg-violet-200 text-violet-900", gemini: "bg-fuchsia-200 text-fuchsia-900", kimi: "bg-indigo-200 text-indigo-900",
  doubao: "bg-rose-200 text-rose-900", gpt: "bg-slate-200 text-slate-900", zai: "bg-stone-300 text-stone-900", claude: "bg-orange-200 text-orange-900",
};
const LOOK_LABEL: Record<string, string> = { golden: "暖午后", dusk: "黄昏", night: "夜", rainEve: "雨夜", cozy: "屋内", afterRain: "雨后清晨" };
const STILL: Record<string, string> = { C01: "f00070", C03: "f00260", C10: "f01120", C11: "f01260", C15: "f01760", C18: "f02100", C22: "f02560", C29: "f03760", C33: "f04250", C35: "f04460", C41: "f05120" };

const CAST_TABLE = [
  { id: "whale", role: "浪人 / 小生", why: "唱这首歌的就是她；「怕自己只有便宜才值得被喜欢」= 「和你有些不搭」「两袖清风」", act: "带着饭盆喝花茶 · 微醺爬不上马 · 雨里抖袖子 · 最后在门口挥手" },
  { id: "qwen", role: "美眷「你」", why: "图集里唯一的中式宽袖 + 折扇 + 茶；茶会戏的东道主，「先排哪一步再动手」", act: "推茶盏 · 抬扇掩面一躬 · 拂袖卷花瓣 · 夜里发现伞、撑开、出门找人" },
  { id: "kimi", role: "桥上弹琵琶的另一位浪人", why: "「先把漏掉的旧句找回来」", act: "弹断了弦的琵琶 · 第二遍把断弦接回去，掉下去的音才飘上来" },
  { id: "doubao", role: "醉花楼门口招呼客人的姑娘", why: "暖场的人", act: "踩拍揽客 · 「官人进来坐坐好吗」· 第二遍开门是让人躲雨" },
  { id: "gpt", role: "酒馆掌柜", why: "先接住乱局", act: "送酒 · 打烊按灯 · 把爬不上马的本鲸劝下来 · 漏雨先摆碗" },
  { id: "zai", role: "酒馆账房", why: "困倦地记账，有事立刻醒", act: "全程趴柜台打盹 · 一滴漏雨砸在算盘上竖耳惊醒" },
  { id: "claude", role: "角落里捧书喝茶的茶客", why: "书卷气，只在场、不抢戏", act: "别人喝酒她看书翻页 · 清晨抱着书过桥" },
  { id: "gemini", role: "趴在院墙上看热闹的邻家猫娘", why: "「先给两个看法，最后必须选一个」", act: "两人对视时左看看右看看 · 墙头够蝴蝶 · 跳下桌撞飞点心" },
];

const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, "0")}`;

export default function App() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [filter, setFilter] = useState<string>("全部");
  const sections = useMemo(() => Array.from(new Set(SHOTS.map((s) => s.section))), []);
  const current = useMemo(() => SHOTS.find((s) => t >= s.start && t < s.end) ?? null, [t]);

  useEffect(() => {
    const a = audioRef.current; if (!a) return;
    const onT = () => setT(a.currentTime);
    a.addEventListener("timeupdate", onT); a.addEventListener("play", () => setPlaying(true)); a.addEventListener("pause", () => setPlaying(false));
    return () => a.removeEventListener("timeupdate", onT);
  }, []);
  useEffect(() => { if (current) document.getElementById(`shot-${current.id}`)?.scrollIntoView({ block: "nearest", behavior: "smooth" }); }, [current?.id]);

  const seek = (s: number) => { const a = audioRef.current; if (!a) return; a.currentTime = s + 0.05; a.play(); };
  const visible = filter === "全部" ? SHOTS : SHOTS.filter((s) => s.section === filter);
  const dur = 172.9;

  return (
    <div className="min-h-screen bg-[#17141a] text-stone-200" style={{ fontFamily: "'Noto Serif SC','Songti SC','SimSun',serif" }}>
      {/* 顶栏 */}
      <header className="sticky top-0 z-20 border-b border-stone-800 bg-[#17141a]/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-5 py-3">
          <h1 className="text-xl font-bold tracking-widest text-rose-200">浪人琵琶 <span className="text-sm font-normal text-stone-400">· 大肥鱼翻唱版 · 分镜</span></h1>
          <div className="ml-auto flex flex-wrap gap-2 text-sm">
            <a className="rounded-full bg-rose-500/90 px-4 py-1.5 font-semibold text-white hover:bg-rose-400" href="/浪人琵琶_MV工程.zip" download>下载工程 zip（2.8 MB）</a>
            <a className="rounded-full border border-stone-600 px-4 py-1.5 hover:border-rose-300 hover:text-rose-200" href="/remade.md" download>remade.md</a>
            <a className="rounded-full border border-stone-600 px-4 py-1.5 hover:border-rose-300 hover:text-rose-200" href="/分镜脚本.md" download>分镜脚本.md</a>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-24">
        {/* 一句话 + 播放器 */}
        <section className="grid gap-6 py-8 md:grid-cols-[1.4fr_1fr]">
          <div>
            <p className="text-3xl leading-relaxed text-stone-100">小生的花伞<span className="text-rose-300">还落在你家</span>。</p>
            <p className="mt-3 leading-7 text-stone-400">
              浪人把伞落在了一户人家，这把伞成了她唯一「想回去」的理由。<b className="text-stone-200">41 句歌词 · 44 个镜头 · 2 分 52.9 秒</b>。三遍副歌三种画面：
              <span className="text-amber-200">回忆</span>（那杯花茶）→ <span className="text-sky-200">另一边</span>（千问夜里发现门边的伞）→ <span className="text-rose-200">回家</span>（一把伞下走回去）。
              人物全部来自分支 <code className="rounded bg-stone-800 px-1 text-xs">人物/</code> 图集（预检统计用到 295 格精灵），背景与道具全是引擎体块现搭，<b className="text-stone-200">没有生成任何图片</b>。
            </p>
            <div className="mt-5 flex flex-wrap gap-2 text-xs">
              {["角色预检通过 44 镜 / 5187 帧", "文字预检通过 144 字", "align 实测 measured=true · 72 BPM", "typecheck 0 报错", "成片未出（约 40 分钟 full）"].map((x) => (
                <span key={x} className={`rounded-full px-3 py-1 ${x.startsWith("成片") ? "bg-stone-800 text-stone-400" : "bg-emerald-900/50 text-emerald-200"}`}>{x}</span>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-stone-800 bg-[#1f1b24] p-4">
            <div className="mb-2 flex items-baseline justify-between text-xs text-stone-400"><span>对着音频看分镜</span><span>{fmt(t)} / {fmt(dur)}</span></div>
            <audio ref={audioRef} src="/langren-pipa.mp3" controls preload="metadata" className="w-full" />
            {/* 镜头进度条 */}
            <div className="relative mt-3 h-6 w-full overflow-hidden rounded bg-stone-800" onClick={(e) => { const r = e.currentTarget.getBoundingClientRect(); seek(((e.clientX - r.left) / r.width) * dur); }}>
              {SHOTS.map((s) => (
                <div key={s.id} title={`${s.id} ${s.lyric}`} className={`absolute top-0 h-full border-r border-[#17141a] ${s.id.startsWith("N") ? "bg-indigo-900/70" : s.section.includes("副歌") ? "bg-rose-900/60" : "bg-amber-900/50"} ${current?.id === s.id ? "!bg-rose-400" : ""}`}
                  style={{ left: `${(s.start / dur) * 100}%`, width: `${((s.end - s.start) / dur) * 100}%` }} />
              ))}
            </div>
            <div className="mt-3 min-h-[4.5rem] rounded-lg bg-stone-900/60 p-3 text-sm">
              {current ? (
                <>
                  <div className="flex items-center gap-2 text-rose-200"><span className="font-mono text-xs text-stone-400">{current.id}</span><span className="text-base">{current.lyric || current.title}</span></div>
                  <p className="mt-1 text-xs leading-5 text-stone-400">{current.note}</p>
                </>
              ) : <p className="text-xs text-stone-500">{playing ? "……" : "按播放，这里会跟着音频显示当前镜头；点下面任意一镜可跳到那一句。"}</p>}
            </div>
          </div>
        </section>

        {/* 歌词理解 */}
        <section className="rounded-2xl border border-stone-800 bg-[#1f1b24] p-6">
          <h2 className="text-lg font-bold text-rose-200">歌词是怎么读的</h2>
          <div className="mt-4 grid gap-4 text-sm leading-6 text-stone-300 md:grid-cols-3">
            <div><b className="text-amber-200">伞 = 留在那里的一部分自己。</b>「小生的花伞还落在你家」不是忘了拿，是有了回去的理由。第一镜从门柱边收着的伞拉开，第二遍副歌千问在门边发现它，最后它又靠回原位——C01 / C21 / C39 是同一个位置、同一个机位。</div>
            <div><b className="text-sky-200">思念 = 淋在身上的雨。</b>伞在你家，所以「我的思念似六月里的小雨哗哗」时她没有伞可撑：雨夜街心，头顶浮出一把半透明的花伞影子又散掉（C18）。这句音频里唱了两遍，给的文本里没有，按音频补回。</div>
            <div><b className="text-rose-200">「不想回家」唱完时她已经在家。</b>浪人本来就没有家；暮色里她在院门外回头看那扇窗（C07），全片最后一镜停在同一扇门口（C41）。尾声四句「我化成风……浪人回头」翻唱音频里没有，「回头」的意思做进了 C32–C35：她往回走，千问撑着那把伞迎面而来。</div>
          </div>
        </section>

        {/* 谁演谁 */}
        <section className="mt-8">
          <h2 className="text-lg font-bold text-rose-200">这支 MV 里谁是谁</h2>
          <p className="mt-1 text-xs text-stone-500">一人一个形象；性格靠动作兑现；歌里的感情戏不回写进日常线（本鲸 × 千问只在这支片子里成立）。</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {CAST_TABLE.map((c) => (
              <div key={c.id} className="rounded-xl border border-stone-800 bg-[#1f1b24] p-4 text-sm">
                <div className="flex items-center gap-2"><span className={`rounded px-2 py-0.5 text-xs font-bold ${CAST_COLOR[c.id]}`}>{NAMES[c.id]}</span><span className="font-semibold text-stone-100">{c.role}</span></div>
                <p className="mt-2 text-xs leading-5 text-stone-400"><span className="text-stone-500">兑现：</span>{c.why}</p>
                <p className="mt-1 text-xs leading-5 text-stone-300"><span className="text-stone-500">动作：</span>{c.act}</p>
              </div>
            ))}
          </div>
        </section>

        {/* 分镜表 */}
        <section className="mt-10">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="mr-3 text-lg font-bold text-rose-200">分镜（{visible.length} 镜）</h2>
            {["全部", ...sections].map((s) => (
              <button key={s} onClick={() => setFilter(s)} className={`rounded-full px-3 py-1 text-xs ${filter === s ? "bg-rose-500 text-white" : "bg-stone-800 text-stone-300 hover:bg-stone-700"}`}>{s.split(" · ")[0]}</button>
            ))}
          </div>
          <ol className="mt-4 space-y-2">
            {visible.map((s, i) => {
              const newSection = i === 0 || visible[i - 1].section !== s.section;
              const active = current?.id === s.id;
              return (
                <li key={s.id} id={`shot-${s.id}`}>
                  {newSection && <h3 className="mb-2 mt-6 border-l-4 border-rose-400 pl-3 text-base font-bold text-stone-100">{s.section}</h3>}
                  <div onClick={() => seek(s.start)} className={`grid cursor-pointer gap-3 rounded-xl border p-3 transition md:grid-cols-[5rem_1fr_14rem] ${active ? "border-rose-400 bg-rose-950/30" : "border-stone-800 bg-[#1f1b24] hover:border-stone-600"}`}>
                    <div className="text-xs text-stone-400"><div className="font-mono text-base text-stone-100">{s.id}</div><div>{fmt(s.start)}–{fmt(s.end)}</div><div className="mt-1 text-stone-500">{s.look && (LOOK_LABEL[s.look] ?? s.look)}</div></div>
                    <div>
                      <div className="text-base text-rose-100">{s.lyric || s.title}{s.line != null && <span className="ml-2 text-xs text-stone-500">第 {s.line} 句</span>}</div>
                      <p className="mt-1 text-sm leading-6 text-stone-300">{s.note}</p>
                      <div className="mt-2 flex flex-wrap gap-1">{(s.cast ?? []).map((c) => <span key={c} className={`rounded px-1.5 py-0.5 text-[11px] ${CAST_COLOR[c]}`}>{NAMES[c]}</span>)}</div>
                    </div>
                    <div>{STILL[s.id] ? <img src={`/stills/${STILL[s.id]}.jpg`} alt={`${s.id} 抽帧`} loading="lazy" className="w-full rounded-lg border border-stone-700" /> : <div className="flex h-full min-h-[5rem] items-center justify-center rounded-lg border border-dashed border-stone-800 text-[11px] text-stone-600">未抽帧 · npm run film -- sheet --shot {s.id}</div>}</div>
                  </div>
                </li>
              );
            })}
          </ol>
        </section>

        {/* 交付与边界 */}
        <section className="mt-10 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-stone-800 bg-[#1f1b24] p-5 text-sm leading-6 text-stone-300">
            <h2 className="text-lg font-bold text-rose-200">怎么放进项目</h2>
            <p className="mt-2">解压 zip，把 <code className="rounded bg-stone-800 px-1 text-xs">番外MV/浪人琵琶/</code> 整个放进分支同名位置，然后：</p>
            <pre className="mt-2 overflow-x-auto rounded-lg bg-black/40 p-3 text-xs text-emerald-200">{`npm ci && pip install --user numpy pillow
npm run film -- info  番外MV/浪人琵琶   # 预检全过
npm run film -- sheet 番外MV/浪人琵琶   # 分镜总览图
npm run film -- full  番外MV/浪人琵琶   # 出成片`}</pre>
            <p className="mt-2 text-xs text-stone-500">cues.json 记着音源 sha256（90dedd6d…），与根目录 大肥鱼翻唱《浪人琵琶》.mp3 相同；换音源须重跑 align。</p>
          </div>
          <div className="rounded-2xl border border-stone-800 bg-[#1f1b24] p-5 text-sm leading-6 text-stone-300">
            <h2 className="text-lg font-bold text-rose-200">机器查过的 / 人看过的 / 没做的</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>机器：typecheck 0 报错；角色预检通过（顺着走、倒着走一致）；文字预检通过；align 平均移动 0.095 s。</li>
              <li>人：抽了 14 帧看构图，改了桥面高度与 C01 / C29 / C41 机位。<b className="text-stone-100">没有人从头到尾连续看过、听过。</b></li>
              <li>没做：成片（沙盒渲 5187 帧约 40 分钟）、逐音节对齐、封面与文案、原曲与形象的授权核对。</li>
              <li>踩到的坑：引擎 <code className="text-xs">basic()/toon()</code> 材质按颜色全局缓存，镜头里直接改会污染别的镜头——灯笼改用独享材质，幻影先 clone 材质再调透明。</li>
            </ul>
          </div>
        </section>
      </main>
    </div>
  );
}
