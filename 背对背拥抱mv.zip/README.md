# Whale Island MV Studio

A React, Vite and Tailwind application for the supplied "Back to Back" music video.

## Run

```sh
npm install
npm run dev
npm run build
```

The entry point is `src/App.tsx`. The interface is in Simplified Chinese.

## Features

- Music playback, seeking, volume, speed, keyboard controls and immersive viewing.
- The actual Whale and Claude sprite assets and animation frames from the requested branch.
- Four new paper-art environments, six story chapters and all 48 supplied lyric lines.
- Character, word and line caption modes with adjustable caption offset.
- Readable lyric-driven shot directions and original-character action previews.
- Downloadable full-length MP4, SRT subtitles and a JSON storyboard project.
- Locally stored preview preferences and responsive desktop/mobile layouts.

## Timing And Rendering

The supplied `.mp3` was actually an AAC-in-MP4 container. It was transcoded to a real MP3 without changing its timing for reliable browser playback.

Line transitions were sampled directly from the reference video at 4 frames per second. Combined lines were split for the supplied lyric layout. **Individual character and word timings are interpolated, not verified vocal forced alignment.** The calibration interface makes this limitation explicit. The video has not been reviewed end-to-end by a person.

`src/lib/renderMV.ts` is a deterministic Canvas2D/2.5D renderer shared by browser preview and offline rendering. It combines the new paper-art backgrounds with the original animated sprites, lyric-specific props, camera drift and depth-extruded typography. It is not a fully modeled WebGL environment.

The downloadable MP4 is the standard 1280x720, 24 fps render with character captions and zero timing offset. Preview adjustments do not change that pre-rendered file. SRT and JSON exports include current timing adjustments.

To regenerate the static thumbnails:

```sh
npx tsx scripts/render-mv.ts --stills
```

To render the full video, install FFmpeg or provide its path:

```sh
FFMPEG_PATH=/path/to/ffmpeg npx tsx scripts/render-mv.ts
```

## Sources And Rights

Source branch: https://github.com/aavvcasdas/latest-aiyunying/tree/arena/bb6a02da-latest-aiyunying

Character images and animation frames are cropped without redrawing from `通用模板/engine/assets/cast_atlas.png`, using the branch's atlas coordinates and action metadata. The music and reference video are the user's supplied `背对背拥抱.mp3` and `背对背拥抱.mp4`. New environment illustrations were generated for this implementation. The character relationship is an independent MV interpretation, not a change to the original character canon.

ZCOOL KuaiLe is the source branch's SIL OFL font. The interface uses a locally subsetted Noto Sans SC font, also SIL OFL. Public redistribution permissions for the music and character artwork have not been established; verify them before public release.