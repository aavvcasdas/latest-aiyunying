import { useEffect, useMemo, useRef, useState } from 'react';
import { Download, FileCode2, Loader2, Package, Pause, Play, SkipBack, SkipForward } from 'lucide-react';
import {
  M, CHAR_IDS, type CharId, baseUrl, origUrl, layoutOf, actionsOf, renderAction, buildPack, buildPatchZip, saveBlob,
  RESIDUE, TOTALS, STRIPS, SIZES, ACTION_COUNT, FRAME_COUNT, PATCH_TEXT, PATCH_NAME, BASE_COMMIT, type Progress,
} from './lib/hd';

const CAST = M.CAST as Record<CharId, { name: string; model: string; front: string }>;
const BGS = [
  { id: 'dark', label: '深色', css: '#0c0d11' },
  { id: 'mid', label: '中灰', css: '#7b808b' },
  { id: 'light', label: '浅色', css: '#efeae0' },
  { id: 'checker', label: '棋盘', css: '' },
] as const;
type BgId = (typeof BGS)[number]['id'];
const bgProps = (bg: BgId) => (bg === 'checker' ? { className: 'checker' } : { style: { background: BGS.find((b) => b.id === bg)!.css } });

function BgPicker({ value, onChange }: { value: BgId; onChange: (b: BgId) => void }) {
  return (
    <div className="flex items-center gap-1 text-xs">
      <span className="mr-1 text-[var(--mute)]">底色</span>
      {BGS.map((b) => (
        <button key={b.id} onClick={() => onChange(b.id)} aria-pressed={value === b.id}
          className={`rounded-md border px-2 py-1 ${value === b.id ? 'border-[var(--ink)] bg-[var(--ink)] text-white' : 'border-[var(--line)] bg-white hover:border-[var(--ink)]'}`}>{b.label}</button>
      ))}
    </div>
  );
}

function CharTabs({ value, onChange }: { value: CharId; onChange: (c: CharId) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      {CHAR_IDS.map((id) => (
        <button key={id} onClick={() => onChange(id)} aria-pressed={value === id}
          className={`rounded-md border px-2.5 py-1.5 text-sm ${value === id ? 'border-[var(--accent)] bg-[var(--accent)] text-white' : 'border-[var(--line)] bg-white hover:border-[var(--ink)]'}`}>
          {CAST[id].name}<span className={`ml-1.5 text-xs ${value === id ? 'text-white/70' : 'text-[var(--mute)]'}`}>{id}</span>
        </button>
      ))}
    </div>
  );
}

function Player({ id, name, bg }: { id: CharId; name: string; bg: BgId }) {
  const cv = useRef<HTMLCanvasElement>(null), strip = useRef<HTMLCanvasElement>(null);
  const layout = useMemo(() => layoutOf(id), [id]);
  const meta = useMemo(() => M.actionMeta(name), [name]);
  // 帧和它所属的「角色/动作」绑在一起：角色一换格子尺寸立刻变，旧帧不能按新尺寸画
  const key = `${id}/${name}`;
  const [res, setRes] = useState<{ key: string; frames: Uint8ClampedArray[] } | null>(null);
  const frames = res && res.key === key && res.frames[0]?.length === layout.cw * layout.ch * 4 ? res.frames : null;
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(true);
  const hold = meta.loop ? 0 : Math.round(meta.fps * 0.9);
  const cur = frames ? Math.min(frames.length - 1, t % (frames.length + hold)) : 0;
  const TW = 64, TH = Math.round((TW * layout.ch) / layout.cw);

  useEffect(() => {
    let dead = false; setT(0);
    renderAction(id, name).then((f) => { if (!dead) setRes({ key, frames: f }); }).catch((e) => console.error(e));
    return () => { dead = true; };
  }, [id, name, key]);
  useEffect(() => {
    if (!frames || !playing) return;
    const h = setInterval(() => setT((v) => v + 1), 1000 / meta.fps);
    return () => clearInterval(h);
  }, [frames, playing, meta.fps]);
  useEffect(() => {
    const c = cv.current; if (!c || !frames) return;
    c.getContext('2d')!.putImageData(new ImageData(frames[cur] as never, layout.cw, layout.ch), 0, 0);
  }, [frames, cur, layout]);
  useEffect(() => {
    const s = strip.current; if (!s || !frames) return;
    const ctx = s.getContext('2d')!; ctx.clearRect(0, 0, s.width, s.height);
    const tmp = document.createElement('canvas'); tmp.width = layout.cw; tmp.height = layout.ch; const tc = tmp.getContext('2d')!;
    frames.forEach((f, i) => { tc.putImageData(new ImageData(f as never, layout.cw, layout.ch), 0, 0); ctx.drawImage(tmp, i * TW * 2, 0, TW * 2, TH * 2); });
  }, [frames, layout, TH]);

  const step = (d: number) => { if (!frames) return; setPlaying(false); setT((cur + d + frames.length) % frames.length); };
  return (
    <div className="overflow-hidden rounded-xl border border-[var(--line)] bg-white">
      <div {...bgProps(bg)} >
        <div className="relative flex h-[340px] items-end justify-center sm:h-[420px]">
          <canvas ref={cv} width={layout.cw} height={layout.ch} className={`max-h-full max-w-full ${frames ? '' : 'opacity-0'}`} />
          {!frames && <div className="absolute inset-0 grid place-items-center text-sm text-white mix-blend-difference"><span className="flex items-center gap-2"><Loader2 className="animate-spin" size={16} />正在从基础格派生 {meta.n} 帧…</span></div>}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2 border-t border-[var(--line)] px-3 py-2 text-sm">
        <button onClick={() => step(-1)} className="rounded-md border border-[var(--line)] p-1.5 hover:border-[var(--ink)]" aria-label="上一帧"><SkipBack size={15} /></button>
        <button onClick={() => setPlaying((p) => !p)} className="flex items-center gap-1.5 rounded-md bg-[var(--ink)] px-3 py-1.5 text-white">{playing ? <Pause size={15} /> : <Play size={15} />}{playing ? '暂停' : '播放'}</button>
        <button onClick={() => step(1)} className="rounded-md border border-[var(--line)] p-1.5 hover:border-[var(--ink)]" aria-label="下一帧"><SkipForward size={15} /></button>
        <span className="ml-1 font-medium">{CAST[id].name} · {meta.label}</span>
        <span className="text-[var(--mute)]">第 {cur + 1} / {meta.n} 帧 · {meta.fps} fps · {meta.loop ? '循环' : '播一遍定格'} · 格 {layout.cw}×{layout.ch}</span>
      </div>
      <div className="overflow-x-auto border-t border-[var(--line)]">
        <div className="relative" style={{ width: meta.n * TW, height: TH, background: bg === 'checker' ? undefined : BGS.find((b) => b.id === bg)!.css }}>
          <canvas ref={strip} width={meta.n * TW * 2} height={TH * 2} style={{ width: meta.n * TW, height: TH }} className={bg === 'checker' ? 'checker' : ''} />
          {frames && <div className="pointer-events-none absolute top-0 border-2 border-[var(--accent)]" style={{ left: cur * TW, width: TW, height: TH }} />}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [id, setId] = useState<CharId>('whale');
  const [bg, setBg] = useState<BgId>('dark');
  const [zoom, setZoom] = useState(1);
  const acts = useMemo(() => actionsOf(id), [id]);
  const [act, setAct] = useState('idle');
  useEffect(() => { if (!acts.some((a) => a.name === act)) setAct(acts[0].name); }, [acts, act]);
  const actName = acts.some((a) => a.name === act) ? act : acts[0].name;

  const [job, setJob] = useState<{ title: string; p: Progress } | null>(null);
  const [err, setErr] = useState('');
  const pack = async (title: string, ids: CharId[], scale: 4 | 2, file: string) => {
    if (job) return; setErr(''); setJob({ title, p: { done: 0, total: 1, label: '准备' } });
    try { saveBlob(await buildPack(ids, scale, (p) => setJob({ title, p })), file); } catch (e) { setErr(String(e)); } finally { setJob(null); }
  };
  const patchZip = async () => saveBlob(await buildPatchZip(), '补丁包_latest-aiyunying_q版HD.zip');

  const front = CAST[id].front, s = SIZES[front], disp = (s[1] > 120 ? 2 : 3.6) * zoom;
  const pct = ((TOTALS.before / TOTALS.ring) * 100).toFixed(1);

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-[var(--line)] bg-[var(--paper)]/92 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-4 px-4">
          <div className="leading-tight"><div className="text-sm font-semibold">Q 版 HD 图包</div><div className="text-[11px] text-[var(--mute)]">latest-aiyunying · arena/bb6a02da · 基线 {BASE_COMMIT}</div></div>
          <nav className="ml-auto hidden gap-5 text-sm text-[var(--mute)] md:flex">
            <a href="#compare" className="hover:text-[var(--ink)]">清晰度对比</a><a href="#actions" className="hover:text-[var(--ink)]">动作</a><a href="#edge" className="hover:text-[var(--ink)]">白边</a><a href="#download" className="hover:text-[var(--ink)]">下载</a><a href="#limits" className="hover:text-[var(--ink)]">没做的</a>
          </nav>
          <a href="#download" className="flex items-center gap-1.5 rounded-md bg-[var(--ink)] px-3 py-2 text-sm font-medium text-white"><Download size={15} />下载</a>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 pb-8 pt-10">
        <h1 className="max-w-3xl text-3xl font-semibold leading-tight tracking-tight sm:text-[40px]">八位 Q 版角色：4 倍高清、{ACTION_COUNT} 个重新派生的动作、抠图残留清掉</h1>
        <p className="mt-4 max-w-3xl text-[15px] leading-7 text-[var(--mute)]">
          素材全部取自仓库 <code>人物/</code> 与 <code>通用模板/engine/assets/cast_atlas.png</code> 的原格。仓库里没有更高清的 Q 版原图，所以清晰度来自对 108 张基础格做 4 倍超分；动作在高清格上重新派生。原图集一个字节没改，这一包并排放在 <code>人物/q版HD/</code>。
        </p>
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            ['单格分辨率', '84×90 → 336×360', '108 张基础格，4 倍'],
            ['动作', `${ACTION_COUNT} 个 / ${FRAME_COUNT} 帧`, '每人 13–16 个，同格同锚点'],
            ['抠图残留像素', `${TOTALS.before} → ${TOTALS.after}`, `原占墨线内圈的 ${pct}%`],
            ['走路帧补墨线', `${TOTALS.outlined} 张`, '原来只有走路帧没有描边'],
          ].map(([k, v, d]) => (
            <div key={k} className="rounded-xl border border-[var(--line)] bg-white p-4"><div className="text-xs text-[var(--mute)]">{k}</div><div className="mt-1 text-xl font-semibold tabular-nums">{v}</div><div className="mt-1 text-xs text-[var(--mute)]">{d}</div></div>
          ))}
        </div>
        <div className="mt-5 overflow-hidden rounded-xl border border-[var(--line)] bg-white">
          <div className="flex flex-wrap items-center gap-3 border-b border-[var(--line)] px-3 py-2"><span className="text-sm font-medium">高清正面格（点一位看对比和动作）</span><div className="ml-auto"><BgPicker value={bg} onChange={setBg} /></div></div>
          <div {...bgProps(bg)}>
            <div className="flex items-end gap-2 overflow-x-auto px-4 pb-4 pt-6 sm:justify-center sm:gap-4">
              {CHAR_IDS.map((c) => (
                <button key={c} onClick={() => setId(c)} className={`shrink-0 rounded-lg p-1 text-center outline-offset-2 ${id === c ? 'outline outline-2 outline-[var(--accent)]' : ''}`}>
                  <img src={baseUrl(CAST[c].front)} alt={CAST[c].name} className="mx-auto h-28 w-auto sm:h-36" draggable={false} />
                  <div className="mt-1 rounded bg-black/55 px-1.5 py-0.5 text-[11px] text-white">{CAST[c].name}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="compare" className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-end gap-3">
          <div><h2 className="text-xl font-semibold">清晰度对比</h2><p className="mt-1 text-sm text-[var(--mute)]">左：原格按最近邻放大（引擎现在的显示方式）。右：高清格缩到同样大小。</p></div>
          <div className="ml-auto flex flex-wrap items-center gap-3"><BgPicker value={bg} onChange={setBg} />
            <div className="flex items-center gap-1 text-xs"><span className="mr-1 text-[var(--mute)]">放大</span>{[1, 2].map((z) => <button key={z} onClick={() => setZoom(z)} aria-pressed={zoom === z} className={`rounded-md border px-2 py-1 ${zoom === z ? 'border-[var(--ink)] bg-[var(--ink)] text-white' : 'border-[var(--line)] bg-white'}`}>{z}×</button>)}</div>
          </div>
        </div>
        <div className="mt-3"><CharTabs value={id} onChange={setId} /></div>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {[{ title: `原格 ${s[0]}×${s[1]}`, src: origUrl(front), pix: true }, { title: `高清格 ${s[0] * 4}×${s[1] * 4}`, src: baseUrl(front), pix: false }].map((p) => (
            <figure key={p.title} className="overflow-hidden rounded-xl border border-[var(--line)] bg-white">
              <figcaption className="border-b border-[var(--line)] px-3 py-2 text-sm font-medium">{p.title}</figcaption>
              <div {...bgProps(bg)}><div className="flex h-[380px] items-start justify-center overflow-auto p-4"><img src={p.src} alt={p.title} draggable={false} style={{ width: s[0] * disp, height: s[1] * disp, maxWidth: 'none', imageRendering: p.pix ? 'pixelated' : 'auto' }} /></div></div>
            </figure>
          ))}
        </div>
        <p className="mt-3 text-sm leading-6 text-[var(--mute)]">超分用的是 Real-ESRGAN 动漫权重。它补出来的线条和高光是模型推断的，不是原图里有的信息；发型、配色、服饰、道具位置沿用原格。八位的正面格我逐位看过，造型与原格一致。</p>
      </section>

      <section id="actions" className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-end gap-3"><div><h2 className="text-xl font-semibold">动作</h2><p className="mt-1 text-sm text-[var(--mute)]">这里播放的帧是浏览器用仓库里同一份 <code>motion_hd.mjs</code> 现场算出来的，和图包里的帧同源。</p></div><div className="ml-auto"><BgPicker value={bg} onChange={setBg} /></div></div>
        <div className="mt-3"><CharTabs value={id} onChange={setId} /></div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {acts.map((a) => (
            <button key={a.name} onClick={() => setAct(a.name)} aria-pressed={actName === a.name}
              className={`rounded-md border px-2.5 py-1 text-sm ${actName === a.name ? 'border-[var(--ink)] bg-[var(--ink)] text-white' : 'border-[var(--line)] bg-white hover:border-[var(--ink)]'}`}>{a.label}<span className={`ml-1.5 text-xs ${actName === a.name ? 'text-white/60' : 'text-[var(--mute)]'}`}>{a.name}</span></button>
          ))}
        </div>
        <div className="mt-3"><Player id={id} name={actName} bg={bg} /></div>

        <h3 className="mt-8 text-base font-semibold">旧动作怪在哪（原图集里的帧，原样放大 2 倍）</h3>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          {[
            { k: 'act_whale_spin', title: '本鲸 spin', note: '把人横向压成细条，中间几帧只剩一条竖线。新包里没有这个动作；只有千问有「转身」，用正面 / 侧身 / 镜像换格。' },
            { k: 'act_gemini_lookaround', title: '猫 lookaround', note: '正面格是披散长发，侧身格是双马尾，两套造型硬切。新包里张望和「二选一」只用正面格做转头。' },
          ].map((o) => (
            <figure key={o.k} className="overflow-hidden rounded-xl border border-[var(--line)] bg-white">
              <figcaption className="border-b border-[var(--line)] px-3 py-2 text-sm font-medium">{o.title} · {STRIPS[o.k].n} 帧</figcaption>
              <div {...bgProps(bg)}><div className="overflow-x-auto p-3"><img src={origUrl(o.k)} alt={o.title} draggable={false} style={{ height: STRIPS[o.k].h * 2, width: STRIPS[o.k].w * STRIPS[o.k].n * 2, maxWidth: 'none', imageRendering: 'pixelated' }} /></div></div>
              <p className="px-3 py-2.5 text-sm leading-6 text-[var(--mute)]">{o.note}</p>
            </figure>
          ))}
        </div>
      </section>

      <section id="edge" className="mx-auto max-w-6xl px-4 py-8">
        <h2 className="text-xl font-semibold">白边：量出来在哪、清掉多少</h2>
        <div className="mt-3 grid gap-4 md:grid-cols-[1.1fr_1fr]">
          <div className="space-y-3 text-sm leading-7">
            <p>图集的 alpha 只有 0 和 255 两档，透明区 RGB 是纯黑，所以白边不是渲染时插值带出来的。每格最外圈是烘焙时自动加的 1 像素墨线（<code>#181425</code>），抠图残留的浅色像素夹在<strong>墨线内侧那一圈</strong>。</p>
            <p>判定规则只动「比里面亮、朝白色偏、往里又找不到相近颜色」的像素，把它重上色成里面的颜色。轮廓和墨线不变；蕾丝、围裙、手、浅色发梢这些有厚度的浅色不会被碰。</p>
            <p>高清格的轮廓外另做了 3 圈颜色外扩（alpha 仍是 0），线性过滤或缩放时不会从透明区带进黑边或白边。</p>
            <p className="text-[var(--mute)]">这里量的是图集本身。成片里看到的白边还可能来自 bloom 和色差（根目录 README 里写过），那部分我没有改，也没有渲染复测。</p>
          </div>
          <div className="overflow-hidden rounded-xl border border-[var(--line)] bg-white">
            <table className="w-full text-sm tabular-nums">
              <thead><tr className="border-b border-[var(--line)] text-left text-xs text-[var(--mute)]"><th className="px-3 py-2 font-medium">角色</th><th className="px-3 py-2 font-medium">基础格</th><th className="px-3 py-2 font-medium">残留（前）</th><th className="px-3 py-2 font-medium">残留（后）</th><th className="px-3 py-2 font-medium">补墨线</th></tr></thead>
              <tbody>
                {CHAR_IDS.map((c) => <tr key={c} className="border-b border-[var(--line)] last:border-0"><td className="px-3 py-1.5">{CAST[c].name}</td><td className="px-3 py-1.5">{RESIDUE[c].frames}</td><td className="px-3 py-1.5">{RESIDUE[c].before}</td><td className="px-3 py-1.5">{RESIDUE[c].after}</td><td className="px-3 py-1.5">{RESIDUE[c].outlined}</td></tr>)}
                <tr className="bg-[var(--paper)] font-medium"><td className="px-3 py-1.5">合计</td><td className="px-3 py-1.5">{TOTALS.frames}</td><td className="px-3 py-1.5">{TOTALS.before}</td><td className="px-3 py-1.5">{TOTALS.after}</td><td className="px-3 py-1.5">{TOTALS.outlined}</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section id="download" className="mx-auto max-w-6xl px-4 py-8">
        <h2 className="text-xl font-semibold">下载</h2>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-[var(--line)] bg-white p-5">
            <div className="flex items-center gap-2 font-semibold"><Package size={18} />人物图包</div>
            <p className="mt-2 text-sm leading-6 text-[var(--mute)]">在浏览器里现场生成：<code>base/</code> 高清基础格、每个动作一张网格图、<code>index.json</code> 帧表、处理记录。全员 4 倍按仓库端烘焙的体积估算约 190 MB、要算两三分钟——这一档我没有在浏览器里实测，实测过的是豆包单人包（7.7 MB，11 秒）。建议先下单人包。</p>
            <div className="mt-4 grid gap-2">
              <button disabled={!!job} onClick={() => pack(`${CAST[id].name} 4×`, [id], 4, `人物图包_q版HD_${id}_4x.zip`)} className="flex items-center justify-between rounded-md border border-[var(--line)] px-3 py-2.5 text-left text-sm hover:border-[var(--ink)] disabled:opacity-50"><span><b>{CAST[id].name}</b> 单人 · 4 倍</span><Download size={15} /></button>
              <button disabled={!!job} onClick={() => pack('全员 4×', CHAR_IDS, 4, '人物图包_q版HD_全员_4x.zip')} className="flex items-center justify-between rounded-md bg-[var(--ink)] px-3 py-2.5 text-left text-sm text-white disabled:opacity-50"><span><b>全员 · 4 倍</b>（装进仓库用这一包）</span><Download size={15} /></button>
              <button disabled={!!job} onClick={() => pack('全员 2×', CHAR_IDS, 2, '人物图包_q版HD_全员_2x.zip')} className="flex items-center justify-between rounded-md border border-[var(--line)] px-3 py-2.5 text-left text-sm hover:border-[var(--ink)] disabled:opacity-50"><span><b>全员 · 2 倍</b>（体积约四分之一，未实测）</span><Download size={15} /></button>
            </div>
            {job && (
              <div className="mt-4" role="status">
                <div className="flex items-center gap-2 text-sm"><Loader2 size={15} className="animate-spin" />{job.title}：{job.p.label}<span className="ml-auto tabular-nums text-[var(--mute)]">{job.p.done} / {job.p.total}</span></div>
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[var(--line)]"><div className="h-full bg-[var(--accent)]" style={{ width: `${(job.p.done / job.p.total) * 100}%` }} /></div>
              </div>
            )}
            {err && <p className="mt-3 text-sm text-red-700">生成失败：{err}</p>}
          </div>
          <div className="rounded-xl border border-[var(--line)] bg-white p-5">
            <div className="flex items-center gap-2 font-semibold"><FileCode2 size={18} />补丁包</div>
            <p className="mt-2 text-sm leading-6 text-[var(--mute)]">仓库里 <code>git diff</code> 出来的真补丁（9 个文件，全是新增，外加 <code>package.json</code> 两条脚本）。不含图片，图片在图包里。</p>
            <div className="mt-4 grid gap-2">
              <button onClick={patchZip} className="flex items-center justify-between rounded-md bg-[var(--ink)] px-3 py-2.5 text-left text-sm text-white"><span><b>补丁包 .zip</b>（.patch + 安装说明）</span><Download size={15} /></button>
              <button onClick={() => saveBlob(new Blob([PATCH_TEXT], { type: 'text/x-diff' }), PATCH_NAME)} className="flex items-center justify-between rounded-md border border-[var(--line)] px-3 py-2.5 text-left text-sm hover:border-[var(--ink)]"><span>只要 <b>{PATCH_NAME}</b>（{Math.round(new Blob([PATCH_TEXT]).size / 1024)} KB）</span><Download size={15} /></button>
            </div>
            <pre className="mt-4 overflow-x-auto rounded-md bg-[#15161a] p-3 text-[12px] leading-5 text-[#e6e3da]">{`git checkout arena/bb6a02da-latest-aiyunying
git apply ${PATCH_NAME}
unzip 人物图包_q版HD_全员_4x.zip      # 在仓库根解压
npm run cast:hd:check                 # 核对帧表与图
npm run cast:hd                       # 可选：重新派生`}</pre>
          </div>
        </div>
      </section>

      <section id="limits" className="mx-auto max-w-6xl px-4 pb-16 pt-8">
        <h2 className="text-xl font-semibold">验证过的，和没做的</h2>
        <div className="mt-3 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-[var(--line)] bg-white p-5">
            <h3 className="font-semibold">验证过</h3>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm leading-6">
              <li>补丁对基线 {BASE_COMMIT} 的树 <code>git apply --check</code> 通过。</li>
              <li>干净目录里打补丁、放入基础格、重新烘焙千问和狐狸，产物与原烘焙逐字节相同；<code>cast:hd:check</code> 通过。</li>
              <li>无头 Chromium 里跑过本页：切换角色与动作、播放、三种下载，零报错。导出的豆包单人包里 14 张动作图与仓库端烘焙逐字节相同，网页给出的补丁与仓库补丁逐字节相同。</li>
              <li>内嵌的 108 张 WebP 是无损的，抽查往返像素差为 0。</li>
              <li>我看过：八位正面格、本鲸五组动作、其余每位至少一组动作的分格图。</li>
            </ul>
          </div>
          <div className="rounded-xl border border-[var(--line)] bg-white p-5">
            <h3 className="font-semibold">没做 / 没验证</h3>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm leading-6">
              <li><b>引擎没有接这一包。</b><code>actors.ts</code> 和各 MV 工程仍读旧的 1 倍图集，片子没有重渲。要在成片里生效，还得写多贴图加载。</li>
              <li>仓库的 <code>npm test</code>、<code>typecheck</code> 没有跑（要 Node ≥ 22.18，制作环境是 Node 20）。</li>
              <li>没有人逐帧看过全部 {FRAME_COUNT} 帧；全员图包没有在浏览器里实际导出过。</li>
              <li>本鲸的走路帧比正面格偏暗偏灰，原素材如此，没有校色。</li>
              <li>成片里的 bloom、色差没有动；白边在成片里的表现没有复测。</li>
            </ul>
          </div>
        </div>
        <p className="mt-6 text-xs leading-5 text-[var(--mute)]">形象源头同原图集：ZipZipPipe《大AI和小AI们》，CC BY-NC-SA 4.0（署名、非商用、同协议）。超分权重 Real-ESRGAN，BSD-3-Clause。</p>
      </section>
    </div>
  );
}
