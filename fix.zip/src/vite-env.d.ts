/// <reference types="vite/client" />
declare module '*.patch?raw' { const s: string; export default s; }
declare module '*.md?raw' { const s: string; export default s; }
