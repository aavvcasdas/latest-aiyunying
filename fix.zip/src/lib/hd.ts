// 网页端：加载内嵌的 HD 基础格，用与仓库同一份 motion_hd.mjs 现场派生动作、导出图包与补丁包。
import JSZip from 'jszip';
import * as M from '../hd/motion_hd.mjs';
import patchText from '../assets/patch/q-hd.patch?raw';
import readmeText from '../assets/patch/README-q-hd.md?raw';
import baseReport from '../assets/patch/base_report.json';
import baseMeta from '../assets/patch/base_meta.json';
import report from '../assets/report.json';

export { M };
export const PATCH_NAME = 'latest-aiyunying-q版HD.patch';
export const PATCH_TEXT: string = patchText;
export const BASE_COMMIT = 'b17aae7';

const baseUrls = import.meta.glob('../assets/base/*.webp', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const origUrls = import.meta.glob('../assets/orig/*.png', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
export const baseUrl = (k: string) => baseUrls[`../assets/base/${k}.webp`];
export const origUrl = (k: string) => origUrls[`../assets/orig/${k}.png`];
export const BASE_KEYS = Object.keys(baseUrls).map((p) => p.split('/').pop()!.replace('.webp', '')).sort();

export type CharId = 'whale' | 'gpt' | 'claude' | 'doubao' | 'gemini' | 'kimi' | 'qwen' | 'zai';
export const CHAR_IDS = M.CHAR_IDS as CharId[];
export const SIZES = (report as any).sizes as Record<string, [number, number, number]>; // [1 倍宽, 1 倍高, 补边]
export const RESIDUE = (report as any).residue as Record<string, { frames: number; ring: number; before: number; after: number; outlined: number }>;
export const STRIPS = (report as any).strips as Record<string, { n: number; w: number; h: number }>;
export const TOTALS = Object.values(RESIDUE).reduce((t, r) => ({ frames: t.frames + r.frames, before: t.before + r.before, after: t.after + r.after, outlined: t.outlined + r.outlined, ring: t.ring + r.ring }), { frames: 0, before: 0, after: 0, outlined: 0, ring: 0 });

const hdSize = (k: string) => { const s = SIZES[k]; return s ? { w: (s[0] + 2 * s[2]) * M.S, h: (s[1] + 2 * s[2]) * M.S } : null; };
export const layoutOf = (id: CharId): { cw: number; ch: number; footY: number } => M.layoutOf(id, hdSize);
export const actionsOf = (id: CharId): { name: string; label: string; fps: number; loop: boolean; n: number }[] => (M.ACTIONS_OF as any)[id].map((n: string) => M.actionMeta(n));
export const ACTION_COUNT = CHAR_IDS.reduce((n, id) => n + actionsOf(id).length, 0);
export const FRAME_COUNT = CHAR_IDS.reduce((n, id) => n + actionsOf(id).reduce((m, a) => m + a.n, 0), 0);
export const keysOfChar = (id: CharId) => BASE_KEYS.filter((k) => new RegExp(`(^|_)${id}(_|$)`).test(k));

type Raw = { rgba: Uint8ClampedArray; w: number; h: number };
type Src = { w: number; h: number; pm: Float32Array };
const rawCache = new Map<string, Promise<Raw>>();
const srcCache = new Map<string, Promise<Src>>();
const tick = () => new Promise<void>((r) => setTimeout(r, 0));

/** 解码方式：'exact' = WebGL 按未预乘读回，像素与文件里的完全一致；'canvas' = 2D 画布（会经过一次预乘，半透明边缘像素的 RGB 有舍入）。 */
export let decodePath: 'exact' | 'canvas' = 'exact';
let gl: WebGLRenderingContext | null | undefined;
async function decodeExact(url: string): Promise<Raw | null> {
  try {
    if (gl === undefined) gl = document.createElement('canvas').getContext('webgl', { premultipliedAlpha: false }) as WebGLRenderingContext | null;
    if (!gl || typeof createImageBitmap !== 'function') return null;
    const bmp = await createImageBitmap(await (await fetch(url)).blob(), { premultiplyAlpha: 'none', colorSpaceConversion: 'none' });
    const tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, 0); gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, bmp);
    const fb = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, fb); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE, out = new Uint8Array(bmp.width * bmp.height * 4);
    if (ok) gl.readPixels(0, 0, bmp.width, bmp.height, gl.RGBA, gl.UNSIGNED_BYTE, out);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.deleteFramebuffer(fb); gl.deleteTexture(tex);
    const r = { rgba: new Uint8ClampedArray(out.buffer), w: bmp.width, h: bmp.height }; bmp.close();
    return ok ? r : null;
  } catch { return null; }
}
async function decodeCanvas(url: string): Promise<Raw> {
  const img = new Image(); img.src = url; await img.decode();
  const cv = document.createElement('canvas'); cv.width = img.naturalWidth; cv.height = img.naturalHeight;
  const c = cv.getContext('2d', { willReadFrequently: true })!; c.drawImage(img, 0, 0);
  return { rgba: c.getImageData(0, 0, cv.width, cv.height).data, w: cv.width, h: cv.height };
}
export function loadRaw(k: string): Promise<Raw> {
  let p = rawCache.get(k);
  if (!p) {
    p = (async () => {
      const url = baseUrl(k); if (!url) throw new Error(`缺基础格 ${k}`);
      const exact = decodePath === 'exact' ? await decodeExact(url) : null;
      if (exact) return exact;
      decodePath = 'canvas'; return decodeCanvas(url);
    })();
    rawCache.set(k, p);
  }
  return p;
}
const loadSrc = (k: string): Promise<Src> => {
  let p = srcCache.get(k);
  if (!p) { p = loadRaw(k).then((r) => M.premultiply(r.rgba, r.w, r.h)); srcCache.set(k, p); }
  return p;
};

/** 渲染一个动作的全部帧（逐帧让出主线程）。onFrame 用来报进度。 */
async function renderFrames(id: CharId, name: string, onFrame?: () => void): Promise<Uint8ClampedArray[]> {
  const meta = M.actionMeta(name), layout = layoutOf(id), lm = new Map<string, unknown>(), frames: Uint8ClampedArray[] = [];
  for (let i = 0; i < meta.n; i++) {
    const p = M.frameSpec(id, name, i), src = await loadSrc(p.k);
    let L = lm.get(p.k); if (!L) { L = M.landmarks(src, (M.CAST as any)[id].ratio); lm.set(p.k, L); }
    frames.push(M.poseHD(src, L, p, layout.cw, layout.ch, layout.footY));
    onFrame?.(); await tick();
  }
  return frames;
}

// 预览用的小缓存（一个动作 16 帧约 11 MB，只留最近 5 个）
const actCache = new Map<string, Promise<Uint8ClampedArray[]>>();
export function renderAction(id: CharId, name: string): Promise<Uint8ClampedArray[]> {
  const key = `${id}/${name}`; let p = actCache.get(key);
  if (p) { actCache.delete(key); actCache.set(key, p); return p; }
  p = renderFrames(id, name); actCache.set(key, p);
  while (actCache.size > 5) actCache.delete(actCache.keys().next().value as string);
  return p;
}

export const saveBlob = (blob: Blob, name: string) => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 10000); };

export interface Progress { done: number; total: number; label: string }

/** 人物图包：base/ 高清基础格 + 每个动作一张网格图 + index.json。scale = 4（原生）或 2（缩一半）。 */
export async function buildPack(ids: CharId[], scale: 4 | 2, onProgress: (p: Progress) => void): Promise<Blob> {
  const full = ids.length === CHAR_IDS.length, root = scale === 4 ? '人物/q版HD/' : '人物/q版HD_2x/';
  const zip = new JSZip(), keys = full ? BASE_KEYS : [...new Set(ids.flatMap(keysOfChar))];
  const total = ids.reduce((n, id) => n + actionsOf(id).reduce((m, a) => m + a.n, 0), 0) + keys.length;
  let done = 0; const k = scale / 4;
  const index: any = { scale, note: '每个动作一张网格图，帧号从左到右、从上到下；同一角色所有动作同格同锚点。anchor = 脚底中心在格内的像素坐标。', chars: {}, base: {} };
  for (const id of ids) {
    const layout = layoutOf(id), actions: any = {};
    for (const a of actionsOf(id)) {
      const frames = await renderFrames(id, a.name, () => onProgress({ done: ++done, total, label: `${(M.CAST as any)[id].name} · ${a.label}` }));
      let sheet: { rgba: Uint8ClampedArray; w: number; h: number; cols: number; rows: number } = M.toSheet(frames, layout.cw, layout.ch);
      if (scale === 2) sheet = { ...sheet, ...M.halve(sheet.rgba, sheet.w, sheet.h) };
      M.bleedEdges(sheet.rgba, sheet.w, sheet.h, 3);
      zip.file(`${root}${id}/${a.name}.png`, await M.encodePNG(sheet.rgba, sheet.w, sheet.h));
      actions[a.name] = { label: a.label, file: `${id}/${a.name}.png`, frames: a.n, cols: sheet.cols, rows: sheet.rows, fps: a.fps, loop: a.loop };
    }
    index.chars[id] = { name: (M.CAST as any)[id].name, cell: [layout.cw * k, layout.ch * k], anchor: [(layout.cw / 2) * k, layout.footY * k], size1x: [layout.cw / M.S, layout.ch / M.S], actions };
  }
  for (const key of keys) {
    const raw = await loadRaw(key); let img: { rgba: Uint8ClampedArray; w: number; h: number } = { rgba: new Uint8ClampedArray(raw.rgba), w: raw.w, h: raw.h };
    if (scale === 2) img = M.halve(img.rgba, img.w, img.h);
    M.bleedEdges(img.rgba, img.w, img.h, 3);
    zip.file(`${root}base/${key}.png`, await M.encodePNG(img.rgba, img.w, img.h));
    index.base[key] = { file: `base/${key}.png`, w: img.w, h: img.h };
    onProgress({ done: ++done, total, label: `基础格 ${key}` }); await tick();
  }
  zip.file(`${root}index.json`, JSON.stringify(index, null, 1) + '\n');
  zip.file(`${root}README.md`, readmeText);
  zip.file(`${root}base_report.json`, JSON.stringify(baseReport, null, 1) + '\n');
  zip.file(`${root}base_meta.json`, JSON.stringify(baseMeta, null, 1) + '\n');
  zip.file(`${root}网页导出说明.txt`, [
    `这一包由网页在浏览器里现场生成：${full ? '八位全员' : ids.join('、')}，${scale} 倍。`,
    '动作派生用的是与仓库 通用模板/cast/hd/motion_hd.mjs 相同的代码。',
    decodePath === 'exact'
      ? '基础格按未预乘方式解码（WebGL 读回），动作图应与仓库端 npm run cast:hd 的产物逐字节相同；制作时用无头 Chromium 对豆包单人包核对过，其余角色没有逐个核对。'
      : '这台浏览器没能用 WebGL 解码，改走了 2D 画布：alpha 通道不受影响，但半透明边缘像素的 RGB 会有舍入（alpha 很低处可差几十个色阶，合成后不到 1 个色阶）。要逐字节一致，以仓库端重新烘焙为准。',
    full && scale === 4 ? '装进仓库：在仓库根目录解压本包（得到 人物/q版HD/…），再 git apply 补丁，然后 npm run cast:hd:check。' : '这一包不是「全员 4 倍」，index.json 只含本包里的角色；要装进仓库请用「全员 4 倍」那一包。',
  ].join('\n') + '\n');
  onProgress({ done: total, total, label: '打包 zip' });
  return zip.generateAsync({ type: 'blob', compression: 'STORE' });
}

export const INSTALL_MD = `# 安装：Q 版 HD 图包 + 补丁

基线：分支 arena/bb6a02da-latest-aiyunying，提交 ${BASE_COMMIT}。

\`\`\`bash
git checkout arena/bb6a02da-latest-aiyunying
git apply ${PATCH_NAME}        # 加 9 个文件：工具、说明、index.json，package.json 多两条脚本
unzip 人物图包_q版HD_全员_4x.zip   # 在仓库根解压，得到 人物/q版HD/base/*.png 与 人物/q版HD/<角色>/*.png
npm run cast:hd:check              # 期望：HD 图包核对一致：8 位 · 120 个动作 · 108 张基础格
npm run cast:hd                    # 可选：从 base/ 重新派生全部动作（约两分钟），以这一遍的结果为准
\`\`\`

## 补丁改了什么

| 文件 | 说明 |
| --- | --- |
| 通用模板/cast/hd/motion_hd.mjs | HD 动作派生（纯函数、零依赖；含 PNG 编解码） |
| 通用模板/cast/hd/bake_hd.mjs | 命令行：从 base/ 烘出每个动作的网格图与 index.json；--check 核对 |
| 通用模板/cast/hd/hd_base.py、sr.py | 重做基础格用：去残留 + 补墨线 + 4 倍超分（要 numpy pillow onnx onnxruntime 和权重） |
| 人物/q版HD/README.md、index.json、base_meta.json、base_report.json | 说明、帧表、每格的处理记录 |
| package.json | 多两条脚本：cast:hd、cast:hd:check |

原图集（人物/atlas.png、通用模板/engine/assets/cast_atlas.*）没有改动。回滚：git apply -R ${PATCH_NAME}，再删掉 人物/q版HD/。

## 验证过的

- 补丁对 ${BASE_COMMIT} 的树做过 git apply --check。
- 在只含 package.json 与 通用模板/cast 的干净目录里：打补丁 → 放入 base/ → 重新烘焙千问、狐狸，产物与原烘焙逐字节相同；cast:hd:check 通过。
- 网页导出的豆包单人包：14 张动作图与仓库端烘焙逐字节相同（无头 Chromium 实测）。全员包没有在浏览器里实际导出过。

## 没有验证的

- 仓库的 npm test / npm run typecheck 没有跑（需要 Node ≥ 22.18，制作环境是 Node 20）。读过 docs.test.mjs：它不扫描 人物/q版HD/README.md，本补丁也没改它扫描的文档。
- 引擎没有接这一包，片子没有重渲。详见 人物/q版HD/README.md「还没做、没验证的」。
`;

export async function buildPatchZip(): Promise<Blob> {
  const zip = new JSZip();
  zip.file(PATCH_NAME, PATCH_TEXT);
  zip.file('安装说明.md', INSTALL_MD);
  return zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
}
