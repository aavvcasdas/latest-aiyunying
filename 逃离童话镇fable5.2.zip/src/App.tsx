import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  FONT, Kit, LOOKS, SHOTS, beatInfo, beatPulse, clamp, getAtlas, loadAtlas, makeSky, makeStars,
  rgb, rnd, seg, timeU, type CamState, type Frame, type Hud, type LookName, type ShotDef,
} from './mv/engine';
import { CLIPS, toSong } from './mv/clips';
import type { Line } from './mv/lyrics';
import { AudioEngine } from './mv/audio';
import { wavBlob } from './mv/sfx';
import { registerAll } from './mv/all';

const fmt = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, '0')}`;
const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
const hashId = (s: string) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const params = typeof location !== 'undefined' ? new URLSearchParams(location.search) : new URLSearchParams();
/** 出片模式（?capture）：只留舞台本身，不显示封面 / 控制条 / 结束卡，不跑自己的播放循环 */
const CAPTURE = params.has('capture');
/** ?clip=1 / ?clip=2：只看（只出）某一个片段；不带则封面可选，默认两段连播 */
const Q_CLIP = (() => { const v = parseInt(params.get('clip') ?? '', 10); return v >= 1 && v <= CLIPS.length ? v - 1 : -1; })();

export default function App() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const subRef = useRef<HTMLDivElement>(null);
  const subWrapRef = useRef<HTMLDivElement>(null);
  const flashRef = useRef<HTMLDivElement>(null);
  const fadeRef = useRef<HTMLDivElement>(null);
  const barTRef = useRef<HTMLDivElement>(null);
  const barBRef = useRef<HTMLDivElement>(null);
  const seekRef = useRef<HTMLDivElement>(null);
  const timeRef = useRef<HTMLSpanElement>(null);
  const engRef = useRef<AudioEngine | null>(null);
  if (!engRef.current) engRef.current = new AudioEngine(CLIPS.map(c => ({ url: c.url, cues: c.cues, dur: c.dur })));
  const clipRef = useRef(Q_CLIP >= 0 ? Q_CLIP : 0);
  const chainRef = useRef(Q_CLIP < 0);
  const renderRef = useRef<(ci: number, t: number) => void>(() => { /* 布景搭好后替换 */ });
  const goRef = useRef<(i: number, play: boolean) => void>(() => { /* 见 goClip */ });
  const [clipIdx, setClipIdx] = useState(clipRef.current);
  const [ready, setReady] = useState(false);
  const [audioReady, setAudioReady] = useState(false);
  const [status, setStatus] = useState('布景搭建中…');
  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [ended, setEnded] = useState(false);
  const [sfxOn, setSfxOn] = useState(true);
  const [ui, setUi] = useState(true);
  const [err, setErr] = useState('');
  const [mixing, setMixing] = useState(-1);
  const uiTimer = useRef(0);

  useEffect(() => {
    let raf = 0, dead = false;
    const canvas = canvasRef.current!, wrap = wrapRef.current!, eng = engRef.current!;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    } catch { setErr('当前浏览器无法启用 WebGL，无法播放三维 MV。'); return; }
    renderer.setClearColor(0x000000);
    // 绘制顺序只由「这一帧的场景」决定（同《童话镇》引擎），任意跳帧画面一致
    renderer.setOpaqueSort((a, b) => a.groupOrder - b.groupOrder || a.renderOrder - b.renderOrder || a.z - b.z);
    renderer.setTransparentSort((a, b) => a.groupOrder - b.groupOrder || a.renderOrder - b.renderOrder || b.z - a.z);

    const scene = new THREE.Scene();
    const sky = makeSky(), stars = makeStars();
    const sun = new THREE.DirectionalLight(0xffffff, 2.5);
    const hemi = new THREE.HemisphereLight(0xffffff, 0x888888, 1.5);
    const fog = new THREE.Fog(0xffffff, 10, 100);
    scene.fog = fog;
    scene.add(sky, stars, sun, sun.target, hemi);
    const cam = new THREE.PerspectiveCamera(38, 16 / 9, 0.1, 1500);
    const cardTint = new THREE.Vector3(1, 1, 1);
    const applyLook = (name: LookName) => {
      const L = LOOKS[name], u = (sky.material as THREE.ShaderMaterial).uniforms;
      (u.top.value as THREE.Vector3).copy(rgb(L.top)); (u.hor.value as THREE.Vector3).copy(rgb(L.hor)); (u.low.value as THREE.Vector3).copy(rgb(L.hor)).multiplyScalar(0.8);
      fog.color.setHex(L.hor); fog.near = L.fog[0]; fog.far = L.fog[1];
      sun.color.setHex(L.sun); sun.intensity = L.sunI; sun.position.set(L.dir[0], L.dir[1], L.dir[2]).multiplyScalar(60);
      hemi.color.setHex(L.amb); hemi.groundColor.setHex(L.amb).multiplyScalar(0.5); hemi.intensity = L.ambI;
      cardTint.copy(rgb(L.card)); stars.visible = L.stars > 0; (stars.material as THREE.PointsMaterial).color.setScalar(L.stars);
    };
    const resize = () => {
      const w = wrap.clientWidth, h = wrap.clientHeight;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(w, h, false);
      wrap.style.setProperty('--u', `${h / 100}px`);
    };
    const ro = new ResizeObserver(resize); ro.observe(wrap); resize();

    const hud: Hud = { flash: 0, flashCol: '#fff', fade: 0, bars: 1, shake: 0, tint: '' };
    const pool = new Map<string, unknown>();
    const built = new Map<string, { kit: Kit; update: (f: Frame) => CamState }>();
    let sets: ShotDef[][] = [];
    let curLine: Line | null = null, curKey = '', activeId: string | null = null;
    const build = (s: ShotDef) => {
      let rt = built.get(s.id);
      if (!rt) { const kit = new Kit(getAtlas(), hashId(s.id), pool); rt = { kit, update: s.build(kit) }; built.set(s.id, rt); }
      return rt;
    };

    /** 画第 ci 个片段的第 c0 秒（片段秒）。镜头内部一律用原曲秒 s 驱动 */
    const renderAt = (ci: number, c0: number) => {
      const clip = CLIPS[ci], c = clamp(c0, 0, clip.dur), { s, pick } = toSong(clip, c), defs = sets[ci];
      let sh: ShotDef = defs[0];
      for (let i = defs.length - 1; i >= 0; i--) if (pick >= defs[i].a) { sh = defs[i]; break; }
      const rt = build(sh);
      if (activeId !== sh.id) {
        if (activeId) scene.remove(built.get(activeId)!.kit.root);
        scene.add(rt.kit.root); activeId = sh.id; applyLook(sh.look); (window as any).__shot = sh.id;
      }
      hud.flash = 0; hud.flashCol = '#fff'; hud.fade = 0; hud.bars = 1; hud.shake = 0; hud.tint = '';
      const dur = sh.b - sh.a, u = clamp((s - sh.a) / dur), bt = beatInfo(s);
      timeU.value = s;
      for (const a of rt.kit.actors) a.begin();
      const cs = rt.update({ t: s, T: s, lt: s - sh.a, p: u, u, dur, bp: beatPulse(s), bt, hud });
      const k = hud.shake;
      cam.position.set(cs.p[0] + (rnd(Math.floor(s * 60)) - 0.5) * k, cs.p[1] + (rnd(Math.floor(s * 60) + 9) - 0.5) * k, cs.p[2]);
      cam.up.set(0, 1, 0); cam.lookAt(cs.l[0], cs.l[1], cs.l[2]); if (cs.roll) cam.rotateZ(cs.roll);
      cam.fov = cs.fov - (bt.down ? 0.45 : 0.15) * bt.pulse; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
      sky.position.copy(cam.position); stars.position.copy(cam.position);
      for (const a of rt.kit.actors) a.commit(cam, cardTint);
      for (const th of rt.kit.things) th.face(cam, cardTint);
      renderer.render(scene, cam);

      // ── 叠层：闪白 / 黑场 / 遮幅。字幕层压在这些之上（见 index.css），任何黑场、闪白都盖不住字幕
      flashRef.current!.style.opacity = String(clamp(hud.flash)); flashRef.current!.style.background = hud.flashCol;
      const fade = Math.max(hud.fade, 1 - seg(c, 0, clip.fadeIn), clip.fadeOut > 0 ? seg(c, clip.dur - clip.fadeOut, clip.dur - 0.03) : 0);
      fadeRef.current!.style.opacity = String(clamp(fade));
      const barB = `${9 * Math.max(1, hud.bars)}%`;
      barTRef.current!.style.height = `${9 * hud.bars}%`;
      barBRef.current!.style.height = barB;        // 下遮幅至少留 9%：那是字幕自己的底
      subWrapRef.current!.style.height = barB;     // 字幕永远在下遮幅正中
      canvas.style.filter = hud.tint || '';

      // ── 字幕（逐词点亮：每个词按自己的起音时刻亮，正在唱的那个词高亮放大）
      let L: Line | null = null;
      if (c < clip.dur - 1e-3) for (const x of clip.lines) if (pick >= x.a && pick < x.b) { L = x; break; }   // 片段播完的那一刻字幕收掉，不透到结束卡下面
      const sub = subRef.current!;
      if (L !== curLine) {
        curLine = L; curKey = '';
        sub.innerHTML = L ? L.w.map(w => `<span${w[2] ? ' class="gap"' : ''}>${esc(w[1])}</span>`).join('') : '';
      }
      if (L) {
        let now = -1, nowT = -1e9, key = '';
        for (let i = 0; i < L.w.length; i++) {
          const on = s >= L.w[i][0] - 0.03; key += on ? '1' : '0';
          if (on && L.w[i][0] >= nowT) { nowT = L.w[i][0]; now = i; }
        }
        if (key !== curKey) {
          curKey = key;
          const sp = sub.children;
          for (let i = 0; i < sp.length; i++) sp[i].className = (L.w[i][2] ? 'gap ' : '') + (i === now ? 'on now' : key[i] === '1' ? 'on' : '');
        }
      }
      if (seekRef.current) seekRef.current.style.width = `${(c / clip.dur) * 100}%`;
      if (timeRef.current) timeRef.current.textContent = `${fmt(c)} / ${fmt(clip.dur)}`;
    };

    const loop = () => {
      if (dead) return;
      const ci = clipRef.current, clip = CLIPS[ci];
      let t = eng.time();
      if (t >= clip.dur) {
        if (eng.playing && chainRef.current && ci < CLIPS.length - 1) { goRef.current(ci + 1, true); raf = requestAnimationFrame(loop); return; }
        if (eng.playing) { eng.pause(); eng.seek(clip.dur); setEnded(true); setPlaying(false); }
        t = clip.dur;
      }
      eng.setVolume(clamp(1 - seg(t, clip.dur - 0.04, clip.dur - 0.005)));
      renderAt(ci, t);
      raf = requestAnimationFrame(loop);
    };

    (async () => {
      try {
        const sample = '逃离童话镇乖巧猎枪狼的肚腹里';
        await Promise.all([loadAtlas(), ...Object.values(FONT).map(f => (document as any).fonts.load(`64px ${f.split(',')[0]}`, sample).catch(() => 0))]);
        if (dead) return;
        registerAll();
        sets = CLIPS.map(c => c.shots.map(id => {
          const d = SHOTS.find(x => x.id === id);
          if (!d) throw new Error(`缺少镜头「${id}」`);
          return d;
        }).sort((a, b) => a.a - b.a));
        for (const defs of sets) for (const s of defs) build(s); // 预先搭好两个片段用到的所有布景，切镜头零卡顿
        renderRef.current = renderAt;

        const setClip = (i: number) => { const n = Math.min(CLIPS.length - 1, Math.max(0, Math.floor(i))); clipRef.current = n; eng.setClip(n); setClipIdx(n); return n; };
        (window as any).__mv = {
          /** seek(片段秒[, 片段号 1/2])：出片工具逐帧调用 */
          seek: (t: number, no?: number) => { if (no) setClip(no - 1); renderAt(clipRef.current, t); },
          setClip: (no: number) => { renderAt(setClip(no - 1), 0); },
          get clip() { return clipRef.current + 1; },
          get duration() { return CLIPS[clipRef.current].dur; },
          get cues() { return CLIPS[clipRef.current].cues; },
          get shots() { return sets[clipRef.current].map(x => [x.id, x.a, x.b]); },
          clips: CLIPS.map((c, i) => ({ no: i + 1, id: c.id, title: c.title, file: c.file, duration: c.dur, segs: c.segs, lines: c.lines })),
          mixdown: async (withSfx = true, no?: number) => URL.createObjectURL(await eng.mixdown(no ? no - 1 : clipRef.current, withSfx)),
          sfxOnly: async (no?: number) => { await eng.load(); return URL.createObjectURL(wavBlob(eng.tracks[no ? no - 1 : clipRef.current].sfx!)); },
        };
        (window as any).__captureStage = () => wrapRef.current;
        const q = params.get('t');
        if (q !== null || CAPTURE) { renderAt(clipRef.current, q !== null ? parseFloat(q) : 0); setReady(true); setStarted(true); return; }
        renderAt(clipRef.current, 0);
        setReady(true);
        setStatus('解码片段中…');
        await eng.load(st => setStatus(st === 'song' ? '解码片段中…' : st === 'sfx' ? '合成音效中…' : '准备就绪'));
        if (dead) return;
        setAudioReady(true);
        raf = requestAnimationFrame(loop);
      } catch (e: any) { console.error(e); setErr('加载失败：' + (e?.message ?? e)); }
    })();
    return () => { dead = true; cancelAnimationFrame(raf); ro.disconnect(); renderer.dispose(); eng.pause(); };
  }, []);

  const poke = useCallback(() => {
    setUi(true); window.clearTimeout(uiTimer.current);
    uiTimer.current = window.setTimeout(() => setUi(false), 2200);
  }, []);

  /** 切到第 i 个片段的开头；play = 是否立刻播放 */
  const goClip = useCallback((i: number, play: boolean) => {
    const e = engRef.current!;
    e.pause(); e.setClip(i);
    clipRef.current = i; setClipIdx(i); setEnded(false);
    renderRef.current(i, 0);
    if (play) e.play(0).then(() => { setStarted(true); setPlaying(true); }).catch(() => setErr('音频无法播放，请再点一次。'));
    else setPlaying(false);
  }, []);
  goRef.current = goClip;

  const canPlay = ready && audioReady;
  const start = useCallback((mode: 'all' | number) => {
    if (!canPlay) return;
    chainRef.current = mode === 'all';
    goClip(mode === 'all' ? 0 : mode, true); poke();
  }, [canPlay, goClip, poke]);

  const toggle = useCallback(() => {
    const e = engRef.current!; if (!canPlay) return;
    if (!started) { start(Q_CLIP >= 0 ? Q_CLIP : 'all'); return; }
    if (!e.playing) {
      if (e.time() >= CLIPS[clipRef.current].dur - 0.05) goClip(chainRef.current ? 0 : clipRef.current, true);
      else e.play(e.time()).then(() => setPlaying(true)).catch(() => setErr('音频无法播放，请再点一次。'));
    } else { e.pause(); setPlaying(false); }
    poke();
  }, [canPlay, started, start, goClip, poke]);

  const pick = useCallback((ev: React.MouseEvent | null, i: number) => {
    ev?.stopPropagation(); if (!canPlay) return;
    if (i > 0) chainRef.current = false;
    goClip(i, true); poke();
  }, [canPlay, goClip, poke]);

  const seekTo = useCallback((ev: React.MouseEvent<HTMLDivElement>) => {
    const r = ev.currentTarget.getBoundingClientRect();
    engRef.current!.seek(clamp((ev.clientX - r.left) / r.width) * (CLIPS[clipRef.current].dur - 0.05)); setEnded(false);
    ev.stopPropagation(); poke();
  }, [poke]);
  const full = useCallback((ev: React.MouseEvent) => {
    ev.stopPropagation();
    if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.().catch(() => 0);
  }, []);
  const flipSfx = useCallback((ev: React.MouseEvent) => {
    ev.stopPropagation(); const on = !engRef.current!.sfxOn; engRef.current!.setSfx(on); setSfxOn(on); poke();
  }, [poke]);
  const download = useCallback(async (ev: React.MouseEvent, i: number) => {
    ev.stopPropagation(); if (mixing >= 0) return; setMixing(i);
    try {
      const url = URL.createObjectURL(await engRef.current!.mixdown(i, true));
      const a = document.createElement('a'); a.href = url; a.download = `逃离童话镇_片段${CLIPS[i].no}_${CLIPS[i].title}_含音效.wav`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
    } finally { setMixing(-1); }
  }, [mixing]);

  useEffect(() => {
    const k = (ev: KeyboardEvent) => {
      const e = engRef.current!, d = CLIPS[clipRef.current].dur;
      if (ev.code === 'Space') { ev.preventDefault(); toggle(); }
      if (ev.code === 'ArrowRight') { e.seek(Math.min(d - 0.1, e.time() + 2)); poke(); }
      if (ev.code === 'ArrowLeft') { e.seek(Math.max(0, e.time() - 2)); setEnded(false); poke(); }
      if (ev.code === 'KeyM') { const on = !e.sfxOn; e.setSfx(on); setSfxOn(on); poke(); }
      if (ev.code === 'Digit1' || ev.code === 'Numpad1') pick(null, 0);
      if (ev.code === 'Digit2' || ev.code === 'Numpad2') pick(null, 1);
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [toggle, poke, pick]);

  const showUi = (ui || !playing) && !CAPTURE;
  const clip = CLIPS[clipIdx];
  return (
    <div className="mv-root" onMouseMove={poke}>
      <div ref={wrapRef} className="mv-stage" onClick={toggle} style={{ cursor: showUi ? 'pointer' : 'none' }} data-capture={CAPTURE ? '1' : undefined}>
        <canvas ref={canvasRef} className="mv-canvas" />
        <div className="mv-vignette" />
        <div className="mv-grain" />
        <div ref={flashRef} className="mv-flash" />
        <div ref={barTRef} className="mv-bar mv-bar-t" />
        <div ref={barBRef} className="mv-bar mv-bar-b" />
        <div ref={fadeRef} className="mv-fade" />
        {/* 字幕层：z 序在闪白 / 遮幅 / 黑场之上 */}
        <div ref={subWrapRef} className="mv-subwrap">
          <div ref={subRef} className="mv-sub" />
        </div>

        {started && !ended && !CAPTURE && (
          <div className={`mv-ctrl ${showUi ? 'show' : ''}`} onClick={e => e.stopPropagation()}>
            <button className="mv-btn" onClick={toggle} aria-label={playing ? '暂停' : '播放'}>
              {playing
                ? <svg viewBox="0 0 24 24" width="18" height="18"><rect x="5" y="4" width="5" height="16" fill="currentColor" /><rect x="14" y="4" width="5" height="16" fill="currentColor" /></svg>
                : <svg viewBox="0 0 24 24" width="18" height="18"><path d="M6 4l14 8-14 8z" fill="currentColor" /></svg>}
            </button>
            <div className="mv-tabs">
              {CLIPS.map((c, i) => (
                <button key={c.id} className={`mv-tab ${i === clipIdx ? 'on' : ''}`} onClick={e => pick(e, i)} title={`${c.title}（${c.part}）`}>片段{c.no}</button>
              ))}
            </div>
            <div className="mv-seek" onClick={seekTo}><div ref={seekRef} className="mv-seek-fill" /></div>
            <span ref={timeRef} className="mv-time">0:00.0</span>
            <button className={`mv-btn mv-btn-wide ${sfxOn ? 'on' : ''}`} onClick={flipSfx} aria-label="音效开关" title="背景音效（M 键）">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 9v6h4l5 4V5L8 9z" fill="currentColor" />{sfxOn ? <path d="M16 8.5a5 5 0 010 7M18.5 6a8.5 8.5 0 010 12" /> : <path d="M16 9l5 6M21 9l-5 6" />}</svg>
              <span>音效</span>
            </button>
            <button className="mv-btn" onClick={full} aria-label="全屏">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" /></svg>
            </button>
          </div>
        )}

        {!started && !CAPTURE && (
          <div className="mv-cover">
            <div className="mv-cover-in">
              <div className="mv-cover-kicker">立 体 童 话 书 · 精 做 片 段</div>
              <h1 className="mv-cover-title">逃离童话镇</h1>
              <div className="mv-clips">
                {CLIPS.map((c, i) => (
                  <button key={c.id} className="mv-clipcard" disabled={!canPlay} onClick={e => { e.stopPropagation(); start(i); }}>
                    <span className="mv-clipcard-no">片段{c.no} · {c.part}</span>
                    <span className="mv-clipcard-title">{c.title}</span>
                    <span className="mv-clipcard-dur">{c.dur.toFixed(1)} 秒 · 只看这一段</span>
                  </button>
                ))}
              </div>
              <button className="mv-play" disabled={!canPlay} onClick={e => { e.stopPropagation(); start(Q_CLIP >= 0 ? Q_CLIP : 'all'); }}>
                {err ? '出错了' : canPlay ? (Q_CLIP >= 0 ? `播放片段${CLIPS[Q_CLIP].no}` : '两段连播') : status}
              </button>
              <div className="mv-cover-tip">{err || '建议佩戴耳机 · 空格暂停 · ←→ 快退快进 · 1 / 2 切换片段 · M 开关背景音效'}</div>
            </div>
          </div>
        )}
        {ended && !CAPTURE && (
          <div className="mv-cover mv-cover-end" onClick={e => e.stopPropagation()}>
            <div className="mv-cover-in">
              <div className="mv-cover-kicker">片 段 {clip.no} · 播 放 结 束</div>
              <h1 className="mv-cover-title mv-cover-title-sm">{clip.title}</h1>
              <div className="mv-end-row">
                <button className="mv-play" onClick={e => pick(e, clipIdx)}>再看一遍</button>
                {CLIPS.map((c, i) => i !== clipIdx && (
                  <button key={c.id} className="mv-play mv-play-ghost" onClick={e => pick(e, i)}>看片段{c.no}</button>
                ))}
              </div>
              <div className="mv-end-links">
                {CLIPS.map((c, i) => (
                  <button key={c.id} className="mv-link" onClick={e => download(e, i)}>{mixing === i ? '混音导出中…' : `下载片段${c.no}混音（歌曲 + 背景音效 · WAV）`}</button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
