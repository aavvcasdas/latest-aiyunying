import * as THREE from 'three';
import { PI, ball, basic, box, cone, put, sprite3D } from './engine';

/**
 * 精做版大灰狼（朝向 −x）。
 * 旧的 props.wolf3D 有两个问题让「狼」在暗场里认不出来：
 *   1) 红眼球放在头球「里面」（离球心 0.59 < 半径 0.75），整只狼其实没有眼睛；
 *   2) 通体一个近黑色，没有任何明暗分块。
 * 这一版：眼睛贴在头球表面并外凸、带高光和辉光；浅色口鼻 / 胸毛 / 肚皮 / 爪 / 尾尖；黑鼻头、压低的眉骨、
 * 粉色耳蜗和舌头、暗红口腔、加大的獠牙、一排背鬃。
 * userData：jaw（下颚，rotation.z 正角度 = 张嘴）/ head / body / eyes（两团红瞳辉光）
 */
export function wolfFine3D(bodyCol = 0x5e5a7a, eyeCol = 0xff2d4a, bellyCol = 0xd6cee0) {
  const g = new THREE.Group();
  const dark = 0x15101e, fang = 0xfffaf0;

  const body = put(g, ball(1.05, bodyCol, true), 0.7, 1.15, 0); body.scale.set(1.45, 0.95, 0.85);
  const belly = put(g, ball(0.8, bellyCol, true, 0.02), 0.72, 0.84, 0); belly.scale.set(1.5, 0.6, 1.13);
  const chest = put(g, ball(0.52, bellyCol, true, 0.02), -0.4, 1.22, 0); chest.scale.set(0.8, 1.05, 1.1);
  // 背鬃
  for (let i = 0; i < 6; i++) {
    const sp = cone(0.2, 0.5 - i * 0.03, dark, 4, 0.02);
    sp.position.set(-0.25 + i * 0.42, 1.96 - Math.abs(i - 2) * 0.05, 0); sp.rotation.z = -0.5; g.add(sp);
  }

  const head = new THREE.Group(); put(g, head, -0.6, 1.85, 0);
  put(head, ball(0.75, bodyCol, true), 0, 0, 0);
  put(head, ball(0.26, 0x3a0a14, false, 0), -0.5, -0.2, 0);   // 口腔深处
  const eyes: THREE.Sprite[] = [];
  for (const s of [-1, 1]) {
    const ear = cone(0.26, 0.8, bodyCol, 4); ear.position.set(0.15, 0.58, s * 0.38); ear.rotation.z = -0.15; head.add(ear);
    const inner = cone(0.12, 0.46, 0xff8fa8, 4, 0); inner.position.set(0.1, 0.68, s * 0.5); inner.rotation.z = -0.15; head.add(inner);
    // 眼睛：贴在头球表面（该处表面 z ≈ 0.58）并外凸
    put(head, new THREE.Mesh(new THREE.SphereGeometry(0.14, 12, 8), basic(eyeCol)), -0.42, 0.2, s * 0.56);
    put(head, new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), basic(0xfff6c8)), -0.47, 0.24, s * 0.68);
    const gl = sprite3D('glow', 0.95, eyeCol, true, 0.85); gl.position.set(-0.46, 0.2, s * 0.66); head.add(gl); eyes.push(gl);
    const brow = box(0.48, 0.1, 0.12, dark, 0); brow.position.set(-0.43, 0.34, s * 0.6); brow.rotation.z = -0.42; head.add(brow);
  }

  // 上颚：浅色唇边 + 暗红上膛 + 黑鼻头 + 一排獠牙（最前面一对最大）
  const snout = put(head, box(0.98, 0.36, 0.56, bodyCol), -0.78, -0.08, 0);
  put(snout, box(0.66, 0.14, 0.6, bellyCol, 0.02), -0.14, -0.02, 0);
  put(snout, box(0.8, 0.03, 0.44, 0x4a0c18, 0), -0.05, -0.03, 0);
  put(snout, ball(0.13, dark, false, 0.01), -0.5, 0.3, 0);
  for (let i = 0; i < 4; i++) for (const s of [-1, 1]) {
    put(snout, cone(i === 0 ? 0.09 : 0.065, i === 0 ? 0.34 : 0.22, fang, 5, 0.012), -0.4 + i * 0.22, 0, s * 0.21).rotation.x = PI;
  }

  // 可动下颚 + 舌头 + 下排牙
  const jaw = new THREE.Group(); jaw.position.set(-0.22, -0.24, 0); head.add(jaw);
  put(jaw, box(0.86, 0.22, 0.46, bellyCol), -0.52, -0.1, 0);
  put(jaw, box(0.6, 0.06, 0.26, 0xff5c7a, 0.012), -0.52, 0.12, 0);
  for (let i = 0; i < 4; i++) for (const s of [-1, 1]) {
    put(jaw, cone(i === 0 ? 0.08 : 0.055, i === 0 ? 0.3 : 0.2, fang, 5, 0.012), -0.88 + i * 0.22, 0.12, s * 0.18);
  }

  // 尾巴（浅色尾尖）与四肢（浅色爪）
  const tail = put(g, cone(0.34, 1.5, bodyCol, 5), 2.1, 1.35, 0); tail.rotation.z = -0.9;
  const tip = put(g, cone(0.2, 0.55, bellyCol, 5, 0.02), 2.95, 2.03, 0); tip.rotation.z = -0.9;
  for (const [x, z] of [[-0.1, 0.45], [-0.1, -0.45], [1.4, 0.42], [1.4, -0.42]]) {
    put(g, box(0.3, 1.0, 0.3, bodyCol), x, 0, z);
    put(g, box(0.38, 0.16, 0.38, bellyCol, 0.02), x - 0.05, 0, z);
  }

  g.userData.jaw = jaw; g.userData.head = head; g.userData.body = body; g.userData.eyes = eyes;
  return g;
}
