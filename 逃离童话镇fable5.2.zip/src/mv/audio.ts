/**
 * 播放引擎：每个片段的 WAV 与它的音效轨都解码成 AudioBuffer，用同一个 AudioContext 时钟同时起播——
 * 两条轨在采样级别对齐，画面时间直接读这个时钟（扣掉输出延迟），所以「画面 / 歌 / 音效」三者永远同一刻。
 * 片段用的是无损 WAV，没有 MP3 的编码延迟，片段秒就是采样秒。
 */
import { renderSfx, wavBlob, type Cue } from './sfx';

export const SONG_LEVEL = 0.9;
export const SFX_LEVEL = 0.62;

export interface TrackDef { url: string; cues: Cue[]; dur: number }
interface Track { song: AudioBuffer | null; sfx: AudioBuffer | null }

export class AudioEngine {
  ctx: AudioContext | null = null;
  tracks: Track[];
  cur = 0;
  playing = false;
  sfxOn = true;
  private master: GainNode | null = null;
  private songG: GainNode | null = null;
  private sfxG: GainNode | null = null;
  private srcs: AudioBufferSourceNode[] = [];
  private t0 = 0;
  private off = 0;
  private loading: Promise<void> | null = null;

  constructor(private defs: TrackDef[]) { this.tracks = defs.map(() => ({ song: null, sfx: null })); }

  /** 解码两个片段 + 离线合成各自的音效轨（不需要用户手势，可以在封面阶段就做完） */
  load(onStep?: (s: 'song' | 'sfx' | 'done') => void) {
    if (!this.loading) {
      this.loading = (async () => {
        onStep?.('song');
        const dec = new OfflineAudioContext(2, 44100, 44100);
        for (let i = 0; i < this.defs.length; i++) {
          const arr = await (await fetch(this.defs[i].url)).arrayBuffer();
          this.tracks[i].song = await dec.decodeAudioData(arr);
        }
        onStep?.('sfx');
        for (let i = 0; i < this.defs.length; i++) this.tracks[i].sfx = await renderSfx(this.defs[i].cues, this.defs[i].dur + 0.5);
        onStep?.('done');
      })();
    }
    return this.loading;
  }

  private ensure() {
    if (!this.ctx) {
      const AC: typeof AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AC({ latencyHint: 'interactive' });
      this.master = ctx.createGain(); this.songG = ctx.createGain(); this.sfxG = ctx.createGain();
      this.songG.gain.value = SONG_LEVEL; this.sfxG.gain.value = this.sfxOn ? SFX_LEVEL : 0;
      const lim = ctx.createDynamicsCompressor();
      lim.threshold.value = -2; lim.knee.value = 3; lim.ratio.value = 10; lim.attack.value = 0.002; lim.release.value = 0.15;
      this.songG.connect(this.master); this.sfxG.connect(this.master); this.master.connect(lim); const sc = softClip(ctx); lim.connect(sc); sc.connect(ctx.destination);
      this.ctx = ctx;
    }
    return this.ctx;
  }

  private stopSrcs() {
    for (const s of this.srcs) { try { s.stop(); } catch { /* 已停 */ } s.disconnect(); }
    this.srcs = [];
  }

  /** 切到第 i 个片段（停在 0 秒，不自动播放） */
  setClip(i: number) {
    this.stopSrcs(); this.playing = false; this.cur = i; this.off = 0;
    if (this.ctx && this.master) { this.master.gain.cancelScheduledValues(this.ctx.currentTime); this.master.gain.setValueAtTime(1, this.ctx.currentTime); }
  }

  async play(from: number) {
    await this.load();
    const ctx = this.ensure();
    if (ctx.state !== 'running') await ctx.resume();
    this.stopSrcs();
    const tr = this.tracks[this.cur];
    const when = ctx.currentTime + 0.06;
    const pairs: [AudioBuffer | null, GainNode | null][] = [[tr.song, this.songG], [tr.sfx, this.sfxG]];
    for (const [buf, g] of pairs) {
      if (!buf || !g || from >= buf.duration) continue;
      const s = ctx.createBufferSource(); s.buffer = buf; s.connect(g); s.start(when, Math.max(0, from)); this.srcs.push(s);
    }
    this.t0 = when; this.off = from; this.playing = true;
  }

  pause() { this.off = this.time(); this.stopSrcs(); this.playing = false; }

  seek(t: number) { if (this.playing) void this.play(t); else this.off = t; }

  /** 现在「听到」的是当前片段的第几秒：时钟 − 起播时刻 − 输出延迟 */
  time() {
    if (!this.playing || !this.ctx) return this.off;
    const lat = (this.ctx.outputLatency || 0) + (this.ctx.baseLatency || 0);
    return Math.max(this.off, this.off + (this.ctx.currentTime - this.t0) - lat);
  }

  setVolume(v: number) { if (this.ctx && this.master) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.012); }

  setSfx(on: boolean) {
    this.sfxOn = on;
    if (this.ctx && this.sfxG) this.sfxG.gain.setTargetAtTime(on ? SFX_LEVEL : 0, this.ctx.currentTime, 0.03);
  }

  /** 离线混音：第 i 个片段的歌 + 音效 → WAV（长度与片段逐采样一致，尾部 35 ms 收口防爆音）。给逐帧出片后编码用 */
  async mixdown(i = this.cur, withSfx = true): Promise<Blob> {
    await this.load();
    const sr = 44100, end = this.defs[i].dur, ctx = new OfflineAudioContext(2, Math.round(end * sr), sr);
    const master = ctx.createGain();
    master.gain.setValueAtTime(1, 0); master.gain.setValueAtTime(1, Math.max(0, end - 0.035)); master.gain.linearRampToValueAtTime(0.0001, end);
    const lim = ctx.createDynamicsCompressor();
    lim.threshold.value = -2; lim.knee.value = 3; lim.ratio.value = 10; lim.attack.value = 0.002; lim.release.value = 0.15;
    master.connect(lim); const sc = softClip(ctx); lim.connect(sc); sc.connect(ctx.destination);
    const add = (buf: AudioBuffer | null, level: number) => {
      if (!buf) return;
      const s = ctx.createBufferSource(), g = ctx.createGain(); g.gain.value = level; s.buffer = buf; s.connect(g); g.connect(master); s.start(0);
    };
    add(this.tracks[i].song, SONG_LEVEL);
    if (withSfx) add(this.tracks[i].sfx, SFX_LEVEL);
    return wavBlob(await ctx.startRendering());
  }
}

/**
 * 限幅器之后再接一级软削波：|x| ≤ 0.9 原样通过，以上按 tanh 平滑压到 0.975 以内。
 * 限幅器有 2 ms 起音，鼓点 + 音效叠在一起的瞬态会冒过 0 dB；这一级保证导出的 WAV 和现场播放都不会硬削波。
 */
function softClip(ctx: BaseAudioContext): WaveShaperNode {
  const n = 8193, curve = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1, a = Math.abs(x);
    curve[i] = a <= 0.9 ? x : Math.sign(x) * (0.9 + 0.095 * Math.tanh((a - 0.9) / 0.095));
  }
  const ws = ctx.createWaveShaper(); ws.curve = curve; ws.oversample = 'none';
  return ws;
}
