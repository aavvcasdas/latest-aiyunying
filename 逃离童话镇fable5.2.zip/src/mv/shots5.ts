/**
 * 精做镜头（同名覆盖 shots2 里的旧版）：片段一「狼的 肚腹里 / 哦 一片 黑暗」。
 * 时间仍是原曲秒：狼的 36.54 · 肚腹里 37.42 · 哦 38.40 · 一片 38.62 · 黑暗 39.36
 */
import * as THREE from 'three';
import {
  FONT, PI, back, basic, cam, disc, ei, eio, eo, glowMat, hit, lerp, many, mesh, mixCam, pop, rnd, seg, shot, slam,
  sprite3D, toon, txt,
} from './engine';
import { bubble3D, spotCone } from './props';
import { pine, rock } from './sets3d';
import { wolfFine3D } from './wolf';

export function reg5() {
  /* ───── V1c：狼的 肚腹里 ─────
   * 旧版：近黑的狼站在近黑的洞里，放大 2.1 倍后头和眼睛还被上遮幅切掉 ——「狼看不清」。
   * 精做：
   *   · 新天光 wolfNight + 血月逆光 + 提亮的灰狼，整只狼（含耳尖）完整落在画框里
   *   · 「狼的」  36.54：狼从月亮前扑进画面，红瞳一亮，「狼」字砸下
   *   · 「肚腹里」37.42：张开大嘴 → 小红帽被吸进嘴里 → 37.90 咕咚合嘴、肚子一鼓
   *                      → 38.00 肚皮上弹出透视圆窗，她就在里面 → 镜头一路推进窗里
   */
  shot('V1c', 36.45, 38.35, 'wolfNight', k => {
    k.add(disc(140, 0x2e0c1c));
    k.add(new THREE.Mesh(new THREE.CircleGeometry(4.7, 56), new THREE.MeshBasicMaterial({ color: 0xffdcd2, fog: false })), 2.3, 3.5, -9);
    k.add(sprite3D('glow', 24, 0xff5a70, true, 0.5), 2.3, 3.5, -9.6);
    many(14, i => k.add(pine(3.4 + rnd(i) * 2.6, 0x220c24), -13.5 + i * 2.1, 0, -5.6 - (i % 3) * 1.3));
    many(9, i => k.add(rock(0.8 + rnd(i) * 0.9, 0x40182a, i), -10 + i * 2.6, 0.12, -3.0 - (i % 2) * 1.2));
    k.add(new THREE.Mesh(new THREE.CircleGeometry(4.4, 40).rotateX(-PI / 2), glowMat(0xff8296, 0.16)), 1.4, 0.03, 0.3);

    const S = 1.36, WX = 1.9;
    const wf = wolfFine3D(0x5e5a7a, 0xff2d4a, 0xd6cee0); k.add(wf, WX, 0, -0.3);
    const ud = wf.userData as { jaw: THREE.Group; head: THREE.Group; body: THREE.Mesh; eyes: THREE.Sprite[] };
    const db = k.actor('doubao').wear('hood');
    const wh = k.actor('whale');
    const big = txt('狼', 1.9, { rough: true, stroke: '#1a0208', sw: 0.045, top: true }); k.add(big, -3.35, 3.7, 0.6); big.rotation.z = 0.07;
    const sub = txt('肚腹里', 0.92, { font: FONT.hei, color: '#ffd9df', stroke: '#1a0208', sw: 0.05, sp: 0.1, top: true }); k.add(sub, -3.15, 2.35, 0.6);

    // 肚皮透视窗：发光圆窗 + 窗里的小红帽
    const BX = WX + 0.72 * S, BY = 1.12 * S, BZ = 1.4;
    const win = k.add(new THREE.Group(), BX, BY, BZ);
    win.add(new THREE.Mesh(new THREE.CircleGeometry(0.98, 40), basic(0x4a0c1a)));
    const halo = sprite3D('glow', 2.6, 0xff6a5a, true, 0.6); halo.position.z = 0.01; win.add(halo);
    const rim = mesh(new THREE.TorusGeometry(0.98, 0.07, 6, 40), basic(0xffffff), 0); rim.position.z = 0.03; win.add(rim);
    const inside = k.actor('doubao', 0.6).wear('hood');

    const A1 = cam([BX, BY + 0.12, 4.5], [BX, BY, BZ], 30);
    return ({ t, T, bt, hud }) => {
      const arrive = back(seg(t, 36.54, 36.78));
      const open = eo(seg(t, 37.42, 37.6)) * (1 - eo(seg(t, 37.86, 37.93)));
      const suck = seg(t, 37.46, 37.88), gulp = hit(t, 37.9, 0.36);
      const wpop = back(seg(t, 38.0, 38.2)), push = eio(seg(t, 37.97, 38.33));

      // 狼：扑入 → 低吼（下颚随拍子开合）→ 张嘴 → 吞下 → 肚子一鼓
      wf.visible = t >= 36.54;
      wf.scale.setScalar(Math.max(0.001, S * arrive));
      wf.position.set(WX + (1 - arrive) * 2.4, hit(t, 36.54, 0.3) * 0.3, -0.3);
      ud.head.rotation.z = Math.sin(T * 3.2) * 0.035 - bt.pulse * 0.05 - open * 0.16 + gulp * 0.14;
      ud.jaw.rotation.z = 0.2 + Math.sin(T * 9) * 0.05 * (1 - open) + bt.pulse * 0.1 + open * 0.85 - gulp * 0.18;
      ud.body.scale.set(1.45 * (1 + gulp * 0.1), 0.95 * (1 + gulp * 0.24), 0.85 * (1 + gulp * 0.24));
      ud.eyes.forEach(e => e.scale.setScalar(0.95 + bt.pulse * 0.3 + hit(t, 36.54, 0.4) * 0.9));

      // 小红帽：吓到发抖 → 被吸进嘴里
      if (t < 36.54) db.act('idle', T).at(-2.9, 0, 0.2);
      else if (t < 37.46) db.act('surprise', T, 36.54).at(-2.9 + Math.sin(T * 45) * 0.015, 0, 0.2).emote('fx_exclaim', T);
      else if (t < 37.88) {
        db.act('spin', T).at(lerp(-2.9, -0.2, ei(suck) * 0.6 + suck * 0.4), 0, 0.25)
          .lift(lerp(0, 2.25, suck) + Math.sin(suck * PI) * 0.6).size(1 - suck * 0.5).tilt(suck * 4).noShadow();
      } else db.hide();
      wh.act(t < 36.54 ? 'wave' : t < 37.42 ? 'surprise' : 'shake', T, t < 37.42 ? 36.54 : t < 37.9 ? 37.42 : 37.9)
        .at(-4.45, 0, 0.5).emote(t < 36.54 ? null : t < 37.42 ? 'fx_exclaim' : 'fx_sweat', T);

      slam(big, t, 36.54, 1, 0.15, 2.4);
      slam(sub, t, 37.42, 1, 0.13, 2.3);

      // 透视窗
      win.visible = t >= 38.0; win.scale.setScalar(Math.max(0.001, wpop * (1 + bt.pulse * 0.04)));
      if (t >= 38.0) inside.act('idle', T).at(BX, BY - 0.5 * wpop, BZ + 0.1).size(Math.max(0.05, wpop)).noShadow().emote('fx_sweat', T);
      else inside.hide();

      hud.shake = hit(t, 36.54, 0.32) * 0.34 + hit(t, 37.42, 0.2) * 0.14 + gulp * 0.3;
      hud.flash = hit(t, 36.54, 0.12) * 0.4 + seg(t, 38.25, 38.35) * 0.95; hud.flashCol = t > 38 ? '#5a0f1c' : '#ff3b55';
      const A0 = cam([0.1, 2.2, 9.6 - seg(t, 36.45, 37.9) * 0.45], [0.1, 2.35, -0.3], 36);
      return mixCam(A0, A1, push);
    };
  });

  /* ───── V1c2：哦 一片 黑暗（狼肚子里）─────
   * 旧版整屏压到 75% 黑，肋骨、人物、「黑暗」二字都看不见。精做：
   *   · 新天光 belly：暗红肉壁 + 提亮的肋骨拱，空间读得出来
   *   · 「哦」  38.40：她从上面掉进来，落地一蹲，冒出「哦……」
   *   · 「一片」38.62：肋骨一根根亮出来，镜头后拉——好大一片
   *   · 「黑暗」39.36：整体调暗（不是盖黑），只剩篮子里的小灯和她；「黑暗」用黑字红边，暗场里照样读得清
   */
  shot('V1c2', 38.35, 40.05, 'belly', k => {
    k.add(disc(60, 0x4a0e1a));
    k.add(new THREE.Mesh(new THREE.SphereGeometry(15, 28, 18), new THREE.MeshBasicMaterial({ color: 0x5a0f1c, side: THREE.BackSide })), 0, 2, -2);
    const veil = many(7, i => k.add(sprite3D('glow', 7 + rnd(i) * 5, i % 2 ? 0xff5a6a : 0xff8a5a, true, 0.2), -9 + i * 3 + rnd(i * 3), 1.5 + rnd(i * 5) * 4, -9 - rnd(i * 7) * 3));
    const rb = many(6, i => k.add(mesh(new THREE.TorusGeometry(2.9 + i * 0.12, 0.16, 6, 22, PI), toon(0xd2485a), 0.04), 0, 0.2, 1.4 - i * 1.5));
    const sp = k.add(spotCone(0.25, 2.5, 8, 0xffd8c8, 0.2), 0, 0, 0);
    const db = k.actor('doubao', 1.1).wear('hood');
    const basket = k.thing('prop_basket');
    const lamp = k.add(sprite3D('glow', 2.4, 0xffb45a, true, 0.75), 0.78, 0.6, 0.55);
    const oh = k.add(bubble3D('哦……', 0.3));
    const drops = many(6, () => k.add(sprite3D('drop', 0.42, 0xffa0b0, false, 0.9)));
    const big = txt('黑暗', 1.9, { color: '#08020a', stroke: '#ff5a70', sw: 0.04, px: 200, top: true }); k.add(big, 0, 2.95, -1.2);

    return ({ t, T, bt, hud }) => {
      const land = seg(t, 38.35, 38.47), dark = eio(seg(t, 39.36, 39.85));
      const hb = hit(t, 38.62, 0.32) + hit(t, 39.36, 0.4);   // 两声心跳
      const y = (1 - land * land) * 2.6;

      rb.forEach((m, i) => {
        const a = 38.62 + i * 0.05; m.visible = t >= a;
        m.scale.setScalar((0.6 + 0.4 * back(seg(t, a, a + 0.22))) * (1 + hb * 0.05 + Math.sin(T * 2.4 + i) * 0.015));
      });
      veil.forEach((v, i) => v.scale.setScalar((7 + rnd(i) * 5) * (1 + hb * 0.12 + Math.sin(T * 1.7 + i) * 0.05)));

      db.act(t < 38.62 ? 'surprise' : t < 39.36 ? 'tilt' : 'bow', T, t < 38.62 ? 38.4 : t < 39.36 ? 38.62 : 39.36)
        .at(0, 0, 0.2).lift(y).sq(hit(t, 38.47, 0.22) * 0.28).sil(dark * 0.4, 0x1a0408)
        .emote(t < 38.62 ? 'fx_dizzy' : dark > 0.3 ? 'fx_gloom' : 'fx_question', T);
      basket.at(0.78, 0.3 + y, 0.45);
      lamp.position.set(0.78, 0.62 + y, 0.55);
      lamp.scale.setScalar(2.4 * (0.85 + Math.sin(T * 13) * 0.06 + bt.pulse * 0.12) * (1 - dark * 0.3));

      oh.position.set(1.3, 1.98, 0.5);
      oh.visible = t >= 38.4 && t < 38.95;
      oh.scale.setScalar(Math.max(0.01, pop(t, 38.4, 0.2) * (1 - seg(t, 38.8, 38.95)) * 0.8));

      drops.forEach((m, i) => {
        const ph = (T * 0.9 + rnd(i * 3)) % 1;
        m.visible = t > 38.62;
        m.position.set(-3.3 + i * 1.3 + rnd(i) * 0.4, 3.4 - ph * 3.4, -0.6 - rnd(i * 5) * 2);
        m.material.opacity = (1 - ph) * 0.9;
      });

      sp.scale.set(1 - dark * 0.5, 1, 1 - dark * 0.5);
      (sp.material as THREE.Material).opacity = 0.2 * (1 - dark * 0.5);
      slam(big, t, 39.36, 1, 0.26, 1.5);

      hud.flash = (1 - seg(t, 38.35, 38.56)) * 0.95; hud.flashCol = '#5a0f1c';
      hud.tint = dark > 0.01 ? `brightness(${(1 - dark * 0.42).toFixed(3)}) saturate(${(1 - dark * 0.3).toFixed(3)})` : '';
      hud.fade = dark * 0.2;
      hud.shake = hit(t, 38.47, 0.2) * 0.2 + hb * 0.12;
      const pull = eio(seg(t, 38.56, 39.3));
      return cam([0, 1.5, lerp(5.4, 8.4, pull) + seg(t, 39.3, 40.05) * 0.4], [0, lerp(1.2, 1.4, pull), 0], 35);
    };
  });
}
