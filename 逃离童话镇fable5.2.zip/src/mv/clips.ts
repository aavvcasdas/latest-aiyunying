/**
 * 两个精做片段的定义。
 *
 * 镜头 / 音效 / 歌词里的秒数全部是「原曲秒」，这里只负责把「片段秒」换算成「原曲秒」。
 * 换算关系是实测的：两个 WAV 与原曲做归一化互相关（NCC = 1.000，逐采样吻合），
 * 再用最小二乘解出拼接处两段各自的增益曲线——
 *
 *   片段一 小红帽迷失.WAV（32.020 s）
 *     0.000 – 15.973  = 原曲 28.408 – 44.381（主歌一；开头 0.46 s 淡入）
 *     15.973 – 32.020 = 原曲 60.750 – 76.797（Pre-Chorus）
 *     拼接是「叠放」不是淡化：后段在 15.96 s 整段切入（正好是乐句强拍），前段「磨难」的尾音一直响到 16.36 s
 *
 *   片段二 去他的，乖巧只会饲养恶狼.wav（22.774 s）
 *     0.000 – 18.740  = 原曲 74.187 – 92.927（「为何我打不开」引子 + 副歌到「猎枪！」；开头 0.32 s 淡入）
 *     18.740 – 22.774 = 原曲 97.002 – 101.036（「我对此！感到厌烦！」）
 *     18.80 – 19.34 s 是交叉淡化：后段的「我」淡入时，前段「毙掉」的起音（18.94 s）还在响；
 *     原曲 93.33 – 97.40 的「这循环的回响」两小节（正好 8 拍）在这个音频里被剪掉了
 */
import clip1Url from '../assets/clip1.wav';
import clip2Url from '../assets/clip2.wav';
import { LINES_C1, LINES_C2, type Line } from './lyrics';
import { CUES } from './cues';
import type { Cue } from './sfx';

/** [a, b)：片段秒；off：原曲秒 = 片段秒 + off；hold：选镜头 / 选字幕行时原曲秒的上限（片尾不让下一个镜头露头） */
export interface Seg { a: number; b: number; off: number; hold?: number }
export interface Clip {
  id: string; no: string; title: string; part: string; file: string; url: string;
  dur: number; segs: Seg[]; shots: string[]; lines: Line[]; cues: Cue[];
  /** 画面从黑场淡入 / 淡出到黑场的时长（秒）；0 = 不做 */
  fadeIn: number; fadeOut: number;
}

const SR = 44100;
const D1 = 1412096 / SR;                                // 32.0203
const D2 = 1004337 / SR;                                // 22.7741
const OFF_1A = 1252804 / SR, OFF_1B = 1974666 / SR;     // 28.40825 / 44.77701
const OFF_2A = 3271665 / SR, OFF_2B = 3451334 / SR;     // 74.18741 / 78.26154

const SEGS_1: Seg[] = [
  { a: 0, b: 15.973, off: OFF_1A },
  { a: 15.973, b: D1, off: OFF_1B, hold: 76.69 },       // 最后 0.1 s 已经踩进「去他的」的强拍，画面停在「打不开」的黑场上
];
const SEGS_2: Seg[] = [
  { a: 0, b: 18.74, off: OFF_2A },
  { a: 18.74, b: D2, off: OFF_2B },
];

/** 卡点总表（原曲秒）→ 片段秒；片头 0.2 s 还在淡入、片尾 0.2 s 来不及响完，这两头不放音效 */
function mapCues(segs: Seg[], dur: number): Cue[] {
  const out: Cue[] = [];
  for (const cu of CUES) {
    for (const sg of segs) {
      const c = cu.t - sg.off;
      if (c >= sg.a && c < sg.b && c >= 0.2 && c < dur - 0.2 && (sg.hold === undefined || cu.t <= sg.hold)) out.push({ ...cu, t: +c.toFixed(4) });
    }
  }
  return out.sort((x, y) => x.t - y.t);
}

export const CLIPS: Clip[] = [
  {
    id: 'c1', no: '一', title: '小红帽迷失', part: 'Verse + Pre-Chorus', file: '小红帽迷失.WAV', url: clip1Url,
    dur: D1, segs: SEGS_1, lines: LINES_C1, cues: mapCues(SEGS_1, D1), fadeIn: 0.34, fadeOut: 0,
    shots: ['V1a', 'V1b', 'V1c', 'V1c2', 'V1x', 'V1d', 'PC1a', 'PC1a2', 'PC1b', 'PC2a', 'PC2b', 'PC3', 'PC4'],
  },
  {
    id: 'c2', no: '二', title: '去他的，乖巧只会饲养恶狼', part: 'Chorus', file: '去他的，乖巧只会饲养恶狼.wav', url: clip2Url,
    dur: D2, segs: SEGS_2, lines: LINES_C2, cues: mapCues(SEGS_2, D2), fadeIn: 0.3, fadeOut: 0.3,
    shots: ['PC4', 'C1a', 'C1b', 'C1c', 'C2a', 'C2b', 'C2c', 'C3', 'C4', 'C4b', 'C6a', 'C6b'],
  },
];

/** 片段秒 → 原曲秒（s）以及用来选镜头 / 选字幕行的原曲秒（pick） */
export function toSong(clip: Clip, c: number): { s: number; pick: number } {
  let sg = clip.segs[clip.segs.length - 1];
  for (const x of clip.segs) if (c < x.b) { sg = x; break; }
  const s = c + sg.off;
  return { s, pick: sg.hold !== undefined ? Math.min(s, sg.hold) : s };
}

/** 原曲秒 → 片段秒（不在这个片段里则返回 null） */
export function toClip(clip: Clip, s: number): number | null {
  for (const x of clip.segs) { const c = s - x.off; if (c >= x.a && c < x.b) return c; }
  return null;
}
