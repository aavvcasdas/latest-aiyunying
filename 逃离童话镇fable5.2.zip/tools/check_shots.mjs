/**
 * 截图自检：无头 Chromium（SwiftShader 软件 WebGL）打开 dist/index.html?capture，
 * 按「词」的时刻逐帧 seek → 截图 → 拼联系表；顺带收集页面报错，并跑一遍正常播放流程。
 * 用法：node tools/check_shots.mjs <headless_shell 路径> <playwright-core 所在目录> [只跑哪几张表，如 wolf,pc]
 */
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const [exe, pwDir, only] = process.argv.slice(2);
const { chromium } = createRequire(path.join(pwDir, 'x.js'))('playwright-core');
const ROOT = process.cwd(), URL0 = 'file://' + path.join(ROOT, 'dist/index.html');
const OUT = path.join(ROOT, '.check'), TMP = '/tmp/shots';
fs.mkdirSync(OUT, { recursive: true }); fs.mkdirSync(TMP, { recursive: true });

// [表名, 片段号, 列数, [片段秒, 备注][]]
const SHEETS = [
  // 第二轮修正的复查（3 列大图）
  ['fix1', 1, 3, [[8.60, '狼的 · 耳尖入画'], [9.20, '肚腹里 · 张嘴'], [9.66, '透视窗'], [10.00, '哦 · 人已入画'], [10.12, '哦…… 气泡'], [11.20, '黑暗'],
    [19.20, '预设的'], [26.05, '梦'], [26.70, '何时']]],
  ['fix2', 2, 3, [[4.05, '只会'], [4.55, '饲养'], [5.10, '恶狼'], [7.55, '沉默'], [8.05, '只能 · 划掉'], [8.60, '交换'],
    [17.70, '猎枪'], [18.70, '猎枪 · 推近后'], [19.06, '毙掉']]],
  ['wolf', 1, 4, [[8.10, '狼的 前'], [8.16, '狼的 8.132'], [8.30, ''], [8.60, ''], [9.00, '肚腹里 前'], [9.06, '肚腹里 9.012'], [9.20, '张嘴'], [9.32, '吸入'],
    [9.44, '吸入'], [9.52, '咕咚 9.49'], [9.62, '透视窗'], [9.75, ''], [9.86, '推进'], [9.93, '切换'], [9.97, '肚里'], [10.02, '哦 9.992'],
    [10.12, '落地'], [10.24, '一片 10.212'], [10.45, ''], [10.80, ''], [10.97, '黑暗 10.952'], [11.15, ''], [11.40, ''], [11.62, '最暗']]],
  ['verse', 1, 5, [[0.03, '淡入'], [0.25, '小红帽 0.172'], [0.6, ''], [0.95, '迷失在 0.892'], [1.3, ''], [1.65, '森林 1.592'], [2.2, '提着 2.132'], [2.75, '糕 2.672'], [3.0, '点'], [3.4, '篮'],
    [4.25, '外婆的 4.172'], [4.85, '叮咛 4.732'], [5.35, '你要 5.252'], [5.82, '乖巧 5.732'], [6.7, '和善 6.592'], [7.6, '拽线'], [11.75, '多么 11.692'], [12.3, '夸张 12.192'], [12.5, '啵'], [12.7, '剧本说 12.592'],
    [13.5, '要等待 13.392'], [14.15, '猎人来 13.952'], [14.45, '剖开 14.392'], [14.6, ''], [15.3, '磨难 15.172']]],
  ['pc', 1, 5, [[15.95, '拼接前'], [15.99, 'PC 切入'], [16.3, '高塔 16.203'], [17.25, '是 17.163'], [17.4, '倾倒'], [17.5, '棺椁 17.423'], [18.4, '纺锤 18.303'], [19.0, '是 18.943'], [19.15, '预设的 19.043'], [19.85, '网 19.763'],
    [20.25, '恶龙 20.143'], [21.25, '是 21.163'], [21.65, '借口 21.543'], [22.4, '印证 22.303'], [22.7, '王子 22.603'], [23.15, '多 23.063'], [23.5, '勇敢 23.363'], [24.55, '童话 24.423'], [25.4, '造的 25.283'], [26.0, '梦 25.843'],
    [26.6, '何时 26.463'], [27.25, '想 27.143'], [27.5, '明白 27.403'], [27.95, '吻 27.863'], [28.5, '如果是 28.343'], [29.2, '钥匙 29.083'], [29.6, '为何 29.423'], [30.05, '我 29.983'], [30.3, '打 30.243'], [30.56, '不 30.503'],
    [30.8, '开 30.743'], [30.95, '碎'], [31.3, ''], [31.6, '压黑'], [31.95, '片尾']]],
  ['chorusA', 2, 5, [[0.03, '淡入'], [0.2, '为何 0.013'], [0.65, '我 0.573'], [0.9, '打 0.833'], [1.15, '不 1.093'], [1.4, '开 1.333'], [1.6, '碎'], [2.2, '压黑'], [2.62, '去 2.573'], [3.1, '他 3.053'],
    [3.28, '的 3.233'], [3.42, '乖巧 3.333'], [3.7, '划掉'], [4.0, '只会 3.933'], [4.5, '饲养 4.393'], [5.05, '恶狼 4.953'], [5.25, ''], [5.4, '我要 5.333'], [5.65, '驯服 5.573'], [6.35, '翅膀 6.273'],
    [6.7, '去 6.653'], [7.35, '的 7.293'], [7.5, '沉默 7.433'], [8.0, '只能 7.933'], [8.55, '交换 8.453'], [9.05, '假象 8.973'], [9.4, '这次 9.313'], [9.72, '不用 9.633'], [10.0, '王子 9.913'], [10.5, '登场 10.373']]],
  ['chorusB', 2, 5, [[10.85, '如果 10.773'], [11.4, '被 11.333'], [11.85, '爱 11.793'], [12.35, '终章 12.273'], [12.85, '我要 12.753'], [13.45, '自己 13.393'], [14.0, '写 13.913'], [14.4, '答 14.333'], [14.75, '案'], [14.97, '我宁愿 14.953'],
    [15.1, '淡入中'], [15.65, '自己 15.573'], [16.2, '拿 16.113'], [16.7, '起'], [16.95, '猎 16.893'], [17.62, '枪 17.553'], [18.5, ''], [18.72, '剪接前'], [18.80, '我 18.788'], [18.97, '毙掉 18.943'],
    [19.06, ''], [19.2, ''], [19.3, '对 19.248'], [19.5, '此 19.438'], [19.78, '感 19.718'], [20.4, '静 20.158'], [20.8, '到 20.748'], [21.18, '厌 21.118'], [21.72, '烦 21.658'], [22.0, ''],
    [22.4, ''], [22.6, '淡出'], [22.75, '片尾']]],
];

const browser = await chromium.launch({ executablePath: exe, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
const errs = [];
const hook = (pg, tag) => {
  pg.on('pageerror', e => errs.push(`[${tag}] PAGEERROR ${e.message}`));
  pg.on('console', m => { if (m.type() === 'error') errs.push(`[${tag}] console.error ${m.text().slice(0, 300)}`); });
};

const W = 768, H = 432;
const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
hook(page, 'capture');
await page.goto(URL0 + '?capture&clip=1');
await page.waitForFunction(() => window.__mv, null, { timeout: 180000 });
console.log('clips:', JSON.stringify(await page.evaluate(() => window.__mv.clips.map(c => [c.no, c.title, +c.duration.toFixed(4)]))));
console.log('cues c1/c2:', await page.evaluate(() => { const m = window.__mv; m.setClip(1); const a = m.cues.length; m.setClip(2); const b = m.cues.length; m.setClip(1); return a + ' / ' + b; }));

const sheet = await browser.newPage({ viewport: { width: 1536, height: 900 }, deviceScaleFactor: 1 });
for (const [name, no, cols, frames] of SHEETS) {
  if (only && !only.split(',').includes(name)) continue;
  const cells = [];
  const t0 = Date.now();
  for (let i = 0; i < frames.length; i++) {
    const [t, note] = frames[i];
    const shot = await page.evaluate(([tt, n]) => { window.__mv.seek(tt, n); return window.__shot; }, [t, no]);
    const f = path.join(TMP, `${name}_${i}.png`);
    await page.screenshot({ path: f });
    cells.push(`<div class="c"><img src="file://${f}"><span>${t.toFixed(2)}s · ${shot}${note ? ' · ' + note : ''}</span></div>`);
  }
  const cw = Math.floor(1536 / cols);
  const html = path.join(TMP, `${name}.html`);
  fs.writeFileSync(html, `<meta charset="utf-8"><style>body{margin:0;background:#111;display:flex;flex-wrap:wrap;font:11px/1.2 sans-serif;color:#ff0}.c{position:relative;width:${cw}px}.c img{display:block;width:${cw}px}.c span{position:absolute;left:3px;top:2px;background:rgba(0,0,0,.72);padding:1px 4px}</style>${cells.join('')}`);
  await sheet.goto('file://' + html);
  await sheet.waitForFunction(() => [...document.images].every(im => im.complete && im.naturalWidth > 0));
  await sheet.screenshot({ path: path.join(OUT, `${name}.png`), fullPage: true });
  console.log(`sheet ${name}: ${frames.length} 帧, ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

// 混音轨：两个片段各导出「含音效 / 不含音效」，量时长、峰值、削波采样数
if (!only || only.includes('mix')) {
  const rows = await page.evaluate(async () => {
    const out = [];
    for (const no of [1, 2]) for (const withSfx of [true, false]) {
      const buf = await (await fetch(await window.__mv.mixdown(withSfx, no))).arrayBuffer();
      const dv = new DataView(buf), n = (buf.byteLength - 44) / 2; let peak = 0, clipped = 0, sum = 0;
      for (let i = 0; i < n; i++) { const v = Math.abs(dv.getInt16(44 + i * 2, true)) / 32768; if (v > peak) peak = v; if (v > 0.999) clipped++; sum += v * v; }
      out.push(`片段${no} ${withSfx ? '含音效' : '纯歌曲'}: ${(n / 2 / 44100).toFixed(4)} s · 峰值 ${peak.toFixed(3)} · 削波 ${clipped} · RMS ${Math.sqrt(sum / n).toFixed(4)}`);
    }
    return out;
  });
  console.log('mixdown:\n  ' + rows.join('\n  '));
}

// 正常播放流程：等音频解码 + 音效合成完 → 点「两段连播」→ 播 3 秒 → 跳到片段一结尾看是否自动接片段二
if (!only || only.includes('play')) {
  const p2 = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
  hook(p2, 'play');
  await p2.goto(URL0);
  await p2.waitForFunction(() => { const b = document.querySelector('.mv-play'); return b && !b.disabled; }, null, { timeout: 180000 });
  console.log('cover button:', await p2.textContent('.mv-play'), '| cards:', await p2.$$eval('.mv-clipcard-title', a => a.map(x => x.textContent).join(' / ')));
  await p2.screenshot({ path: path.join(OUT, 'cover.png') });
  await p2.click('.mv-play');
  await p2.waitForTimeout(3000);
  const st = () => p2.evaluate(() => ({ time: document.querySelector('.mv-time')?.textContent, shot: window.__shot, clip: window.__mv.clip, sub: document.querySelector('.mv-sub')?.textContent, tab: document.querySelector('.mv-tab.on')?.textContent }));
  console.log('after 3s:', JSON.stringify(await st()));
  await p2.mouse.move(300, 200);
  const box = await (await p2.$('.mv-seek')).boundingBox();
  await p2.mouse.click(box.x + box.width * 0.985, box.y + box.height / 2);
  await p2.waitForTimeout(2600);
  console.log('after seek→end of clip1 (+2.6s):', JSON.stringify(await st()));
  await p2.mouse.move(310, 210);
  const box2 = await (await p2.$('.mv-seek')).boundingBox();
  await p2.mouse.click(box2.x + box2.width * 0.97, box2.y + box2.height / 2);
  await p2.waitForTimeout(2200);
  console.log('ended card:', JSON.stringify(await p2.evaluate(() => ({ kicker: document.querySelector('.mv-cover-end .mv-cover-kicker')?.textContent, title: document.querySelector('.mv-cover-end .mv-cover-title')?.textContent, btns: [...document.querySelectorAll('.mv-cover-end button')].map(b => b.textContent) }))));
  await p2.screenshot({ path: path.join(OUT, 'end.png') });
}
console.log(errs.length ? 'ERRORS:\n' + [...new Set(errs)].join('\n') : 'NO PAGE ERRORS');
await browser.close();
