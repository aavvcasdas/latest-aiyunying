/**
 * 片段精做 · 第二轮：截图自检（tools/check_shots.mjs）后发现的问题。每一处仍要求恰好匹配一次。
 */
import fs from 'fs';

const P = [];
const rep = (file, find, to) => P.push([file, find, to]);
const S3 = 'src/mv/shots3.ts', S4 = 'src/mv/shots4.ts', S5 = 'src/mv/shots5.ts', CU = 'src/mv/cues.ts';

// ① 第一轮补丁把注释插在了行中间，后半行的 k.add 被注释掉 →「沉默」两个字没上场
rep(S4, `   // 这两个字要被删除线划掉，不能置顶 k.add(g1, -3.2, 3.4, 0.6);`, ` k.add(g1, -3.2, 3.4, 0.6);   // 这两个字要被删除线划掉，不能置顶`);
// ② C1b：狼每个词长大一圈后，狼头会挡住「只会」「饲养」→ 这两个词置顶并加描边；狼最后一档收小一点，脸留在画框里
rep(S4, `const g2 = txt('只会', 0.68, { font: FONT.hei, color: '#fff', sp: 0.2 });`, `const g2 = txt('只会', 0.68, { font: FONT.hei, color: '#fff', stroke: '#0b0a0c', sw: 0.05, sp: 0.2, top: true });`);
rep(S4, `const g3 = txt('饲养', 0.92, { font: FONT.hei, color: '#fff', sp: 0.1 });`, `const g3 = txt('饲养', 0.92, { font: FONT.hei, color: '#fff', stroke: '#0b0a0c', sw: 0.05, sp: 0.1, top: true });`);
rep(S4, `const sc = 0.9 + 0.3 * back(seg(t, 78.12, 78.34)) + 0.35 * back(seg(t, 78.58, 78.8)) + 0.45 * back(seg(t, 79.14, 79.36));`,
  `const sc = 0.9 + 0.3 * back(seg(t, 78.12, 78.34)) + 0.3 * back(seg(t, 78.58, 78.8)) + 0.3 * back(seg(t, 79.14, 79.36));`);
// ③ C4b：镜头推近后「猎」「枪」还是贴边，再往里收
rep(S4, `k.add(g1, -3.05, 2.5, 1.1);`, `k.add(g1, -2.9, 2.5, 1.1);`);
rep(S4, `k.add(g2, 3.1, 1.95, 1.1);`, `k.add(g2, 2.95, 1.95, 1.1);`);
// ④ PC1b「预设的」离上遮幅太近；PC3「梦」太淡、下半截被立体书挡住
rep(S3, `k.add(pre, 1.3, 4.2, 0.6);`, `k.add(pre, 1.3, 3.95, 0.6);`);
rep(S3, `const big = txt('梦', 2.7, { color: 'rgba(255,255,255,.45)', depth: false }); k.add(big, 0, 2.7, -2.5);`,
  `const big = txt('梦', 2.7, { color: 'rgba(255,255,255,.82)', stroke: 'rgba(60,20,110,.55)', sw: 0.02, depth: false }); k.add(big, 0, 3.45, -2.5);`);
// ⑤ V1c：狼再小一号，耳尖完整入画
rep(S5, `const S = 1.42, WX = 1.9;`, `const S = 1.36, WX = 1.9;`);
// ⑥ V1c2：「哦」那一刻她要已经在画面里（落得更快）；「哦……」气泡收进画框
rep(S5, `const land = seg(t, 38.35, 38.52), dark`, `const land = seg(t, 38.35, 38.47), dark`);
rep(S5, `const y = (1 - land * land) * 3.4;`, `const y = (1 - land * land) * 2.6;`);
rep(S5, `.sq(hit(t, 38.52, 0.22) * 0.28)`, `.sq(hit(t, 38.47, 0.22) * 0.28)`);
rep(S5, `hud.shake = hit(t, 38.52, 0.2) * 0.2 + hb * 0.12;`, `hud.shake = hit(t, 38.47, 0.2) * 0.2 + hb * 0.12;`);
rep(S5, `oh.position.set(1.4, 2.3, 0.5);`, `oh.position.set(1.3, 1.98, 0.5);`);
rep(S5, `oh.scale.setScalar(Math.max(0.01, pop(t, 38.4, 0.2) * (1 - seg(t, 38.8, 38.95))));`, `oh.scale.setScalar(Math.max(0.01, pop(t, 38.4, 0.2) * (1 - seg(t, 38.8, 38.95)) * 0.8));`);
rep(CU, `c(38.5, 'thud', 0.35, 1.3),`, `c(38.47, 'thud', 0.35, 1.3),`);

const cache = {}; let fail = 0;
for (const [file, find, to] of P) {
  const src = cache[file] ?? (cache[file] = fs.readFileSync(file, 'utf8'));
  const n = src.split(find).length - 1;
  if (n !== 1) { console.log('✗', file, 'matches=' + n, JSON.stringify(find.slice(0, 80))); fail++; continue; }
  cache[file] = src.replace(find, () => to);
}
if (fail) { console.log(`ABORT：${fail} 处没有恰好匹配一次，未写入任何文件`); process.exit(1); }
for (const [f, s] of Object.entries(cache)) fs.writeFileSync(f, s);
console.log(`patched ${P.length} 处 / ${Object.keys(cache).length} 个文件`);
