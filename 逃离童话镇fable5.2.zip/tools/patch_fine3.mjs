/**
 * 片段精做 · 第三轮：逐词过一遍后，给只有音效、没有画面落点的词补上动作。
 * （替换内容里的说明一律用块注释，避免再出现「行内注释吞掉后半行」的问题。）
 */
import fs from 'fs';

const P = [];
const rep = (file, find, to) => P.push([file, find, to]);
const S2 = 'src/mv/shots2.ts', S3 = 'src/mv/shots3.ts', S4 = 'src/mv/shots4.ts';

/* 「这」43.36：本鲸指着裂缝一蹦 */
rep(S2, `wh.act('point', T).at(-1.25, 0, 0.2).emote('fx_anger', T);`, `wh.act('point', T).at(-1.25, 0, 0.2).lift(hit(t, 43.36, 0.22) * 0.28).emote('fx_anger', T);`);
/* 「才能」71.50：小红帽也冒出问号（「何时」是本鲸先冒） */
rep(S3, `.emote(wake < 0.6 ? 'fx_zzz' : 'fx_exclaim', T);`, `.emote(wake >= 0.6 ? 'fx_exclaim' : t >= 71.5 ? 'fx_question' : 'fx_zzz', T);`);
/* 「龙的」80.08：整条龙往上一窜 */
rep(S4, `gy = 0.3 + Math.sin(T * 5) * 0.15 + u * 0.5;`, `gy = 0.3 + Math.sin(T * 5) * 0.15 + u * 0.5 + hit(t, 80.08, 0.26) * 0.35;`);
/* 「王子」84.10：纸板王子被点名，浑身一哆嗦 */
rep(S4, `pr.rotation.z = -yank * 1.4;`, `pr.rotation.z = -yank * 1.4 + hit(t, 84.1, 0.32) * 0.22 * Math.sin((t - 84.1) * 42);`);
/* 「才是」86.24：爱心一缩，下一拍「终章」的章才盖下来 */
rep(S4, `hr.scale.setScalar(1 + hit(t, 85.52, 0.3) * 0.25 + hit(t, 85.98, 0.3) * 0.4);`, `hr.scale.setScalar(1 + hit(t, 85.52, 0.3) * 0.25 + hit(t, 85.98, 0.3) * 0.4 - hit(t, 86.24, 0.2) * 0.22);`);
/* 「猎」「枪」再往里收一点：镜头推到底时右边那一捺不出画 */
rep(S4, `k.add(g1, -2.9, 2.5, 1.1);`, `k.add(g1, -2.8, 2.5, 1.1);`);
rep(S4, `k.add(g2, 2.95, 1.95, 1.1);`, `k.add(g2, 2.78, 1.95, 1.1);`);

const cache = {}; let fail = 0;
for (const [file, find, to] of P) {
  const src = cache[file] ?? (cache[file] = fs.readFileSync(file, 'utf8'));
  const n = src.split(find).length - 1;
  if (n !== 1) { console.log('✗', file, 'matches=' + n, JSON.stringify(find.slice(0, 80))); fail++; continue; }
  cache[file] = src.replace(find, () => to);
}
if (fail) { console.log(`ABORT：${fail} 处没有恰好匹配一次，未写入任何文件`); process.exit(1); }
for (const [f, s] of Object.entries(cache)) fs.writeFileSync(f, s);
console.log(`patched ${P.length} 处 / ${Object.keys(cache).length} 个文件`);
