/**
 * 片段精做：对分支里现有镜头做「逐词微调」的补丁（每一处都要求恰好匹配一次，否则整体不写入）。
 * 大改的镜头（狼的肚腹里 / 一片黑暗）不在这里，见 src/mv/shots5.ts。
 */
import fs from 'fs';

const P = [];
const rep = (file, find, to) => P.push([file, find, to]);
const E = 'src/mv/engine.ts', S2 = 'src/mv/shots2.ts', S3 = 'src/mv/shots3.ts', S4 = 'src/mv/shots4.ts', CU = 'src/mv/cues.ts', ALL = 'src/mv/all.ts';

/* ───────── 引擎 ───────── */
rep(E, `export const T0 = 0.495;`,
  `export const T0 = 0.51;   // 片段精做校准：对两个 WAV 做瞬态检测，鼓点起音比旧网格（0.495）晚 33–37 ms（中位数）；上调 15 ms，画面仍领先鼓点不到一帧`);
rep(E, `  afterRain: {`,
  `  wolfNight: { top: 0x14051c, hor: 0x7a1230, fog: [16, 110], sun: 0xffd2d8, sunI: 2.7, dir: [-0.35, 0.8, 0.7], amb: 0x8a5a8c, ambI: 1.7, card: 0xffe6ea, stars: 0.5 },
  belly: { top: 0x2a0610, hor: 0x8e1c2c, fog: [12, 70], sun: 0xffb4a0, sunI: 2.4, dir: [0.1, 0.9, 0.6], amb: 0xa04858, ambI: 1.6, card: 0xffe2dc, stars: 0 },
  afterRain: {`);
rep(E, `rough?: boolean; depth?: boolean }`, `rough?: boolean; depth?: boolean; top?: boolean }`);
rep(E, `  mesh0.userData.w = W * k; mesh0.userData.h = H * k;`,
  `  // top：歌词大字永远画在最上面（不做深度测试、最后绘制），不会被角色 / 道具挡住
  if (o.top) mesh0.traverse(x => { const mm = (x as THREE.Mesh).material as THREE.Material | undefined; if (mm) { mm.depthTest = false; x.renderOrder += 20; } });
  mesh0.userData.w = W * k; mesh0.userData.h = H * k;`);
rep(E, `  SHOTS.push({ id, a, b, look, build });`,
  `  // 同名镜头：后注册的覆盖先注册的（精做镜头在 shots5.ts）
  const def = { id, a, b, look, build }, at = SHOTS.findIndex(s => s.id === id);
  if (at >= 0) SHOTS[at] = def; else SHOTS.push(def);`);
rep(ALL, `import { reg4 } from './shots4';`, `import { reg4 } from './shots4';\nimport { reg5 } from './shots5';`);
rep(ALL, `reg1(); reg2(); reg3(); reg4();`, `reg1(); reg2(); reg3(); reg4(); reg5();`);

/* ───────── V1a 小红帽 迷失在 森林 提着 糕点篮 ───────── */
rep(S2, `shot('V1a', 28.58, 32.5, 'forest', k => {`, `shot('V1a', 28.40, 32.5, 'forest', k => {`);   // 片段一从原曲 28.408 起
rep(S2, `x = lerp(-2.8, -0.5, seg(t, 28.58, 29.3));`, `x = lerp(-2.8, -0.5, seg(t, 28.40, 29.3));`);
rep(S2, `const wx = lerp(-4.5, 2.5, seg(t, 28.58, 32.5));`, `const wx = lerp(-4.5, 2.5, seg(t, 28.40, 32.5));`);
rep(S2, `k.add(big, 0, 4.4, -0.5); big.rotation.x = -0.55;`,
  `k.add(big, 0, 4.4, -0.5); big.rotation.x = -0.55;
    const nm = k.add(bubble3D('小红帽', 0.3));   // 「小红帽」：名牌随第一个词弹出
    const lost = txt('迷失', 0.7, { font: FONT.hei, color: '#fff', stroke: '#10281e', sw: 0.06, top: true }); k.add(lost, -1.8, 1.95, 0.6); lost.rotation.z = 0.08;`);
rep(S2, `basket.at(bx, by, 0.25);`,
  `basket.at(bx, by, 0.25);
      slam(nm, t, 28.58, 0.5, 0.14, 2.6); nm.visible = nm.visible && t < 29.3; nm.position.set(x - 0.7, 2.02 + Math.sin(T * 5) * 0.02, 0.3); nm.rotation.z = 0.05;
      slam(lost, t, 29.3, 1, 0.13, 2.4); lost.visible = lost.visible && A; lost.position.x = x - 1.3;   // 「迷失在」`);
rep(S2, `const bx = x + 0.42, by = 0.35 + Math.abs(Math.sin(T * 6)) * 0.06;`,
  `const bx = x + 0.42, by = 0.35 + Math.abs(Math.sin(T * 6)) * 0.06 + hit(t, 30.54, 0.28) * 0.24;   // 「提着」：篮子往上一提`);
rep(S2, `if (A) return cam([x + 0.7, 1.45, 5.8]`, `if (A) hud.shake = hit(t, 29.3, 0.2) * 0.16;\n      if (A) return cam([x + 0.7, 1.45, 5.8]`);

/* ───────── V1b 外婆的 叮咛 是 你要 乖巧 与 和善 ───────── */
rep(S2, `const bub = bubble3D('出门在外，要听话', 0.28); k.add(bub);`,
  `const bub = bubble3D('出门在外，要听话', 0.28); k.add(bub);
    const nm = k.add(bubble3D('外婆', 0.3));   // 「外婆的」：名牌`);
rep(S2, `bub.scale.setScalar(Math.max(0.01, pop(t, 33.14) * (1 - seg(t, 34.05, 34.14))));`,
  `bub.scale.setScalar(Math.max(0.01, pop(t, 33.14) * (1 - seg(t, 34.05, 34.14)) * (1 + hit(t, 33.44, 0.16) * 0.1 + hit(t, 33.66, 0.2) * 0.2)));   // 「是」「你要」：气泡一顿一顿
      slam(nm, t, 32.58, 0.6, 0.14, 2.6); nm.visible = nm.visible && t < 33.14; nm.position.set(1.3, 2.4, 0.25); nm.rotation.z = -0.05;`);
rep(S2, `tg.rotation.z = p[3] + Math.sin(T * 2.5 + i) * 0.04;`,
  `tg.rotation.z = p[3] + Math.sin(T * 2.5 + i) * 0.04 + hit(t, 34.68, 0.25) * 0.3 * (i ? -1 : 1);   // 「与」：两块牌子一晃`);

/* ───────── V1d 剧本说：要等待 猎人来 剖开 这 磨难 ───────── */
rep(S2, `const open = eo(seg(t, 42.8, 43.25));`,
  `const open = eo(seg(t, 42.8, 43.25)), peek = eo(seg(t, 42.36, 42.6)) * 0.24 * (1 - open);   // 「猎人来」：裂缝先透出一道光和猎人的影子`);
rep(S2, `dL.position.x = 2.8 - 3.6 - open * 1.4; dR.position.x = 2.8 + 3.6 + open * 1.4;`,
  `dL.position.x = 2.8 - 3.6 - open * 1.4 - peek; dR.position.x = 2.8 + 3.6 + open * 1.4 + peek;`);
rep(S2, `hu.visible = open > 0;`, `hu.visible = t > 42.36;`);
rep(S2, `k.add(big, 2.35, 2.6, 0.5);`,
  `k.add(big, 2.35, 2.6, 0.5);
    const cut = bar3D(-1.5, 2.4, 1.5, -2.4, 0.1, 0xffffff, true); k.add(cut, 2.8, 2.7, -2.4);   // 「剖开」：一道刀光`);
rep(S2, `slam(big, t, 43.58, 1, 0.16, 2.5); big.rotation.z = -0.08;`,
  `slam(big, t, 43.58, 1, 0.16, 2.5); big.rotation.z = -0.08;
      cut.visible = t >= 42.8 && t < 43.04; cut.scale.set(0.2 + eo(seg(t, 42.8, 42.9)) * 0.8, 1 - seg(t, 42.9, 43.04) * 0.8, 1);`);

/* ───────── Pre-Chorus：「X 是 Y」的「是」逐个落地 ───────── */
const BR_OLD = `const BR = { rough: true, stroke: 'rgba(20,0,2,.6)', sw: 0.03 };`;
const BR_NEW = `const BR = { rough: true, stroke: 'rgba(20,0,2,.6)', sw: 0.03, top: true };   // 歌词大字永远在最上面`;
const SHI = `{ font: FONT.hei, color: '#fff', stroke: '#0b0a0c', sw: 0.05, top: true }`;
rep(S3, BR_OLD, BR_NEW);
// PC1a 高塔（是）
rep(S3, `shot('PC1a', 60.92, 62.2, 'crimson', k => {`, `shot('PC1a', 60.75, 62.2, 'crimson', k => {`);   // 片段一后半从原曲 60.750（强拍）切入
rep(S3, `k.add(tower3D(9.0, 0x261a36, 0x140b20), 0, -0.5, 0);`,
  `const tw = k.add(tower3D(9.0, 0x261a36, 0x140b20), 0, -0.5, 0);
    const shi = txt('是', 0.95, ${SHI}); k.add(shi, 2.4, 6.9, 0.8);`);
rep(S3, `const y = lerp(1.0, 5.4, eo(seg(t, 60.92, 62.0)));`,
  `const y = lerp(1.0, 5.4, eo(seg(t, 60.75, 62.0))), tip = ei(seg(t, 61.94, 62.2)) * 0.24;
      tw.rotation.z = -tip; slam(shi, t, 61.94, 1, 0.12, 2.4);   // 「是」：高塔开始倾倒——下一拍横过来就是棺椁`);
rep(S3, `cl.act('sad', T).at(0, 5.85, 1.35).noShadow().sil(0.7, 0x0b0a0c);`,
  `cl.act('sad', T).at(Math.sin(tip) * 6.3, 5.85 - (1 - Math.cos(tip)) * 6.3, 1.35).noShadow().sil(0.7, 0x0b0a0c);`);
rep(S3, `return cam([-0.6, y, 10.6 - seg(t, 60.92, 62.2) * 1.2], [-0.4, y + 0.8, 0], 36);`,
  `return cam([-0.6, y, 10.6 - seg(t, 60.75, 62.2) * 1.2], [-0.4, y + 0.8, 0], 36);`);
// PC1b 纺锤 是 预设的 网
rep(S3, `const t2 = txt('网', 2.0, BR); k.add(t2, 3.35, 1.45, 0.8); t2.rotation.z = -0.09;`,
  `const t2 = txt('网', 2.0, BR); k.add(t2, 3.35, 1.45, 0.8); t2.rotation.z = -0.09;
    const shi = txt('是', 0.8, ${SHI}); k.add(shi, -0.3, 3.3, 0.6);
    const pre = txt('预设的', 0.66, { font: FONT.hei, color: '#ffd166', stroke: '#0b0a0c', sw: 0.05, sp: 0.12, top: true }); k.add(pre, 1.3, 4.2, 0.6); pre.rotation.z = 0.04;`);
rep(S3, `slam(t1, t, 63.08, 1, 0.15, 2.3); slam(t2, t, 64.54, 1, 0.14, 2.7);`,
  `slam(t1, t, 63.08, 1, 0.15, 2.3); slam(t2, t, 64.54, 1, 0.14, 2.7); slam(shi, t, 63.72, 1, 0.12, 2.4); slam(pre, t, 63.82, 1, 0.12, 2.4);`);
// PC2a 恶龙 是 借口
rep(S3, `const tg = tag3D('借口'); k.add(tg, 0, 3.0, -1.2);`,
  `const tg = tag3D('借口'); k.add(tg, 0, 3.0, -1.2);
    const shi = txt('是', 1.0, ${SHI}); k.add(shi, 3.3, 3.5, 0.6);`);
rep(S3, `slam(big, t, 64.92, 1, 0.16, 2.5); big.visible = !B;`,
  `slam(big, t, 64.92, 1, 0.16, 2.5); big.visible = !B; slam(shi, t, 65.94, 1, 0.12, 2.6); shi.visible = shi.visible && !B;`);
rep(S3, `hit(t, bt(127), 0.3) * 0.25`, `hit(t, bt(127), 0.3) * 0.25 + hit(t, 65.94, 0.2) * 0.2`);
// PC2b 印证 王子 多 勇敢
rep(S3, `sp1.rotation.z = 0.3 + Math.sin(T * 3) * 0.08; sp2.rotation.z = -0.3 - Math.sin(T * 3) * 0.08;`,
  `sp1.rotation.z = 0.3 + Math.sin(T * 3) * 0.08; sp2.rotation.z = -0.3 - Math.sin(T * 3) * 0.08; sp1.visible = sp2.visible = t >= 67.38;   // 「王子」：两束追光啪地打亮`);
rep(S3, `pr.position.y = 1.5 + bt.pulse * 0.07;`, `pr.position.y = 1.5 + bt.pulse * 0.07 + hit(t, 67.38, 0.26) * 0.32;`);
// PC3 童话 造的 梦 何时 才能 想 明白
rep(S3, `k.add(big, 0, 2.7, -2.5);`,
  `k.add(big, 0, 2.7, -2.5);
    const fairy = txt('童话', 1.25, BR); k.add(fairy, -3.0, 3.95, 0.9); fairy.rotation.z = 0.07;`);
rep(S3, `slam(big, t, 70.62, 1, 0.3, 1.5);`, `slam(big, t, 70.62, 1, 0.3, 1.5); slam(fairy, t, 69.2, 1, 0.15, 2.4); fairy.visible = fairy.visible && t < 71.3;`);
rep(S3, `.emote(wake > 0 ? 'fx_bulb' : 'fx_zzz', T);`, `.emote(wake > 0 ? 'fx_bulb' : t >= 71.24 ? 'fx_question' : 'fx_zzz', T);   // 「何时 才能」冒问号，「想」亮灯泡`);
// PC4 … 为何 我 打 不 开
rep(S3, `wh.act('point', T).at(-0.6, 0.0, 0.8).alpha(seg(t, 74.1, 74.4));`,
  `wh.act('point', T).at(-0.6, 0.0, 0.8).alpha(seg(t, 74.1, 74.4)).lift(hit(t, 74.76, 0.28) * 0.3);   // 「我」：本鲸一蹦`);

/* ───────── 副歌 ───────── */
rep(S4, BR_OLD, BR_NEW);
rep(S4, `import { beatSq } from './shots1';`, `import { beatSq } from './shots1';\nimport { wolfFine3D } from './wolf';`);
rep(S4, `const g1 = txt('沉默', 1.5, BR);`, `const g1 = txt('沉默', 1.5, { ...BR, top: false });   // 这两个字要被删除线划掉，不能置顶`);
// C1b 乖巧 只会 饲养 恶狼：换成看得清的精做狼；每个词长大一圈，但脸始终留在画框里；下颚符号改正（正角度才是张嘴）
rep(S4, `const wf = k.add(wolf3D(0x0b0a0c, 0xff2d4a), 2.8, 0, -0.3);`, `const wf = k.add(wolfFine3D(0x2c2440, 0xff2d4a, 0x7a6f92), 2.8, 0, -0.3);`);
rep(S4, `const sc = 0.95 + 0.35 * back(seg(t, 78.12, 78.34)) + 0.45 * back(seg(t, 78.58, 78.8)) + 0.65 * back(seg(t, 79.14, 79.36));`,
  `const sc = 0.9 + 0.3 * back(seg(t, 78.12, 78.34)) + 0.35 * back(seg(t, 78.58, 78.8)) + 0.45 * back(seg(t, 79.14, 79.36));`);
rep(S4, `wf.userData.jaw.rotation.z = -0.25 - hit(t, 79.14, 0.4) * 0.45 - Math.sin(T * 10) * 0.1;`,
  `wf.userData.jaw.rotation.z = 0.28 + hit(t, 79.14, 0.4) * 0.6 + Math.sin(T * 10) * 0.08;`);
// C4b 猎 枪：两个大字收进画框，不再被左右边缘切掉
rep(S4, `const g1 = txt('猎', 2.8, { ...BR, px: 220 }); k.add(g1, -3.5, 2.4, 1.1);`, `const g1 = txt('猎', 2.5, { ...BR, px: 220 }); k.add(g1, -3.05, 2.5, 1.1);`);
rep(S4, `const g2 = txt('枪', 2.8, { ...BR, px: 220 }); k.add(g2, 3.6, 1.8, 1.1);`, `const g2 = txt('枪', 2.5, { ...BR, px: 220 }); k.add(g2, 3.1, 1.95, 1.1);`);
// C6a 我 对 此！感：片段二的剪接把「毙掉」的起音叠在了「我」上——给它一声枪响
rep(S4, `k.add(gan, 0, 3.6, 1.6);`,
  `k.add(gan, 0, 3.6, 1.6);
    // 片段二 18.80–19.34 s 是交叉淡化：前段「毙掉」的起音（原曲 93.13）正叠在「我」上，换算到这条时间轴 = K.wo + 0.155
    const GS = K.wo + 0.155;
    const bang = [...'毙掉'].map((c, i) => { const m = txt(c, 2.0, { ...BR, px: 200 }); k.add(m, 0.3 + i * 3.4, 2.45 - i * 0.25, 1.5); m.rotation.z = i ? -0.1 : 0.08; return m; });
    const boom = k.add(sprite3D('star', 2.6, 0xffffff, true), 0.3, 2.3, 1.2);
    const bits = shards3D(16, [0xffffff, 0xffe9ee, PAL.goldL], 0.3); bits.forEach(m => k.add(m));`);
rep(S4, `slam(gan, t, K.gan, 1, 0.16, 2.2);`,
  `slam(gan, t, K.gan, 1, 0.16, 2.2);
      const fire = hit(t, GS, 0.16);
      boom.visible = fire > 0; boom.scale.setScalar(1.4 + fire * 2.6);
      bang.forEach((m, i) => { slam(m, t, GS + i * 0.06, 1, 0.1, 2.8); m.visible = m.visible && t < ts[i + 1] - 0.03; });   // 「毙」让位给「对」，「掉」让位给「此」
      bits.forEach((m, i) => {   // 被一枪打碎的「循环」
        const kk = seg(t, GS, GS + 0.8), a = rnd(i * 3) * TAU; m.visible = kk > 0 && kk < 1;
        m.position.set(0.3 + Math.cos(a) * kk * 6.5, 2.3 + Math.sin(a) * kk * 4.2 - kk * kk * 1.5, 1.0); m.rotation.set(kk * 9 + i, kk * 7, i);
      });`);
rep(S4, `hud.flash = hit(t, K.wo, 0.1) * 0.5;`, `hud.flash = hit(t, K.wo, 0.1) * 0.5 + hit(t, GS, 0.12) * 0.85; hud.shake += hit(t, GS, 0.28) * 0.6;`);
rep(S4, `shot('C6b', K.hush, 100.9, 'crimson', k => {`, `shot('C6b', K.hush, 101.2, 'crimson', k => {`);   // 片段二在原曲 101.036 结束

/* ───────── 卡点音效 ───────── */
rep(CU, `c(28.7, 'step', 0.35, 1, -0.3),`, `c(28.58, 'pop', 0.4, 1.25, -0.3), c(28.7, 'step', 0.35, 1, -0.3),`);
rep(CU, `c(33.14, 'pop', 0.5),`, `c(32.58, 'pop', 0.4, 1.25, 0.3), c(33.14, 'pop', 0.5), c(33.66, 'tick', 0.4, 1.1, 0.3),`);
rep(CU, `c(36.54, 'growl', 0.8), c(36.54, 'thud', 0.5), c(37.42, 'whoosh', 0.6, 0.8), c(37.9, 'gulp', 0.6),`,
  `c(36.54, 'growl', 0.85), c(36.54, 'thud', 0.55), c(36.62, 'howl', 0.4, 1, 0.3), c(37.42, 'whoosh', 0.65, 0.8), c(37.9, 'gulp', 0.7), c(37.93, 'chomp', 0.7),
  c(38.03, 'pop', 0.5, 0.9, 0.3), c(38.26, 'whoosh', 0.4, 0.6), c(38.5, 'thud', 0.35, 1.3),`);
rep(CU, `c(42.36, 'tick', 0.5),`, `c(42.36, 'tick', 0.5), c(42.36, 'creak', 0.4, 1.1, 0.4),`);
rep(CU, `c(62.2, 'thud', 1.0),`, `c(61.94, 'creak', 0.5, 0.8), c(62.2, 'thud', 1.0),`);
rep(CU, `c(63.72, 'twang', 0.5),`, `c(63.72, 'twang', 0.5), c(63.82, 'pop', 0.35, 1.2, 0.2),`);
rep(CU, `c(65.40, 'flap', 0.6),`, `c(65.40, 'flap', 0.6), c(65.94, 'tick', 0.5, 0.9),`);
rep(CU, `c(72.18, 'ding', 0.8),`, `c(71.24, 'tick', 0.4), c(71.5, 'tick', 0.4, 1.2), c(71.92, 'pop', 0.45, 1.4), c(72.18, 'ding', 0.8),`);
rep(CU, `c(74.2, 'whoosh', 0.4),`, `c(74.2, 'whoosh', 0.4), c(74.76, 'boing', 0.3, 1.2),`);
rep(CU, `c(K.wo, 'thud', 0.8),`, `c(K.wo, 'thud', 0.8), c(K.wo + 0.155, 'gunshot', 1.0), c(K.wo + 0.19, 'shatter', 0.5),`);

rep('index.html', `<title>逃离童话镇 · 立体童话书 3D MV</title>`, `<title>逃离童话镇 · 精做片段｜小红帽迷失 ／ 去他的，乖巧只会饲养恶狼</title>`);

/* ───────── 执行 ───────── */
const cache = {}; let fail = 0;
for (const [file, find, to] of P) {
  const src = cache[file] ?? (cache[file] = fs.readFileSync(file, 'utf8'));
  const n = src.split(find).length - 1;
  if (n !== 1) { console.log('✗', file, 'matches=' + n, JSON.stringify(find.slice(0, 80))); fail++; continue; }
  cache[file] = src.replace(find, () => to);
}
if (fail) { console.log(`ABORT：${fail} 处没有恰好匹配一次，未写入任何文件`); process.exit(1); }
for (const [f, s] of Object.entries(cache)) fs.writeFileSync(f, s);
console.log(`patched ${P.length} 处 / ${Object.keys(cache).length} 个文件`);
