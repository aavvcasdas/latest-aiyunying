// 交付物生成：README / 分镜表 / 歌词.srt / 卡点.json / 设定表补充 / 审片记录 / Vite 源码工程 → zip
import { promises as fs } from 'node:fs';
import path from 'node:path';
import JSZip from 'jszip';
import { BEAT, CAST, LINES, READING, SECTIONS, SHOTS, SONG, STYLE_NOTES } from '@/mv/data';

export interface ReviewLite { shotId: string; status: string; heard: number; note: string; reviewer: string; createdAt: Date | string }

const F = '```';
const ROOT = `番外MV/${SONG.dirName}`;
const fmt = (t: number) => t.toFixed(2);
const frames = Math.round(SONG.duration * SONG.fps);
const mmss = (t: number) => `${Math.floor(t / 60)} 分 ${(t % 60).toFixed(1)} 秒`;
const lineText = (i: number | null) => (i ? LINES[i - 1].text : '（器乐）');
const STATUS: Record<string, string> = { ok: '通过', fix: '需要修改', note: '备注' };
const esc = (s: string) => s.replace(/\|/g, '／').replace(/\n/g, ' ');

export function srt() {
  const ts = (t: number) => {
    const ms = Math.round(t * 1000), h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000), s = Math.floor((ms % 60000) / 1000), r = ms % 1000;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(r).padStart(3, '0')}`;
  };
  return LINES.map((l) => `${l.i}\n${ts(l.s)} --> ${ts(l.e)}\n${l.text}\n`).join('\n');
}

export function cues() {
  return JSON.stringify({
    title: SONG.title, measured: true,
    method: 'HPSS 谐波/打击分离后 300–3000 Hz 人声频段能量分句；节拍为自相关测速 + 动态规划拍点跟踪；三段同旋律互相校核。拍点级对齐，未做人声分离。',
    audio: { file: SONG.audioRepoPath, sampleRate: SONG.sampleRate, samples: SONG.samples, duration: SONG.duration },
    beat: BEAT, fps: SONG.fps, frames,
    lines: LINES.map((l) => ({ i: l.i, text: l.text, s: l.s, e: l.e, fillEnd: l.fe ?? l.e })),
    shots: SHOTS.map((s) => ({ id: s.id, s: s.s, e: s.e, line: s.line, startFrame: Math.round(s.s * SONG.fps) })),
  }, null, 2) + '\n';
}

export function castMd() {
  const rows = CAST.map((c) => `| \`${c.key}\` ${c.who} | ${esc(c.role)} | ${esc(c.habit)} | ${esc(c.action)} | ${esc(c.never)} |`).join('\n');
  return `## 《${SONG.title}》（${SONG.subtitle} · ${LINES.length} 句歌词 · ${SHOTS.length} 镜）

母题：超级棒棒糖是孩子的勇气护身符。魔法会失灵，失灵以后还有自己、朋友和爱；最后那道光是她自己的。本鲸是主角，其余七位各兑现一条习性，只做自己的招牌动作。

| 谁 | 在这支里是谁（形象） | 兑现哪条习性 | 一个能拍出来的动作 | 不许写成 |
| --- | --- | --- | --- | --- |
${rows}

三条检查：

1. **一镜能认出来吗**：本鲸始终拿着那支糖；龙娘只在「接住」时出现；小克捧书、豆包提篮、猫在两条路之间选、千问排积木、狐狸打盹、Kimi 在月亮上——抽一帧都能指认。
2. **去掉性格她还这么动吗**：狐狸「一喊帮忙就醒」、猫「两条路选一条」、Kimi「把漏掉的旧东西找回来」，换人就不成立。
3. **有没有抢主角的定型动作**：举糖只属于本鲸；终段传糖时每人只拿半拍，拿到时做自己的点头。
`;
}

export function storyboardMd() {
  const blocks = SHOTS.map((s) => `### ${s.id} · ${s.title}（${fmt(s.s)}–${fmt(s.e)} 秒，第 ${Math.round(s.s * SONG.fps)} 帧起）

- **歌词**：${s.line ? `第 ${s.line} 句「${lineText(s.line)}」` : '（器乐）'}
- **画面**：${s.desc}
- **角色**：${s.cast}
- **机位**：${s.camera}
- **卡点**：${s.beat}
- **为什么这样拍**：${s.meaning}
`).join('\n');
  return `# 《${SONG.title}》分镜表（${SHOTS.length} 镜）\n\n场景：${[...new Set(SHOTS.map((s) => s.zone))].map((z) => ({ room: '夜里的小卧室', park: '棉花糖游乐场', hill: '黄昏山坡', sky: '星空与月亮', fest: '糖果灯会' })[z]).join(' → ')}。全部程序化 3D，没有背景图。\n\n${blocks}`;
}

export function reviewMd(reviews: ReviewLite[]) {
  if (!reviews.length) return `# 审片记录\n\n导出时还没有任何审片记录：**没有人整片看过、听过**。机器预检不等于好看。\n`;
  const rows = reviews.map((r) => `| ${r.shotId} | ${STATUS[r.status] ?? r.status} | ${r.heard ? '带声音看过' : '只看画面'} | ${esc(r.note || '—')} | ${esc(r.reviewer)} | ${new Date(r.createdAt).toISOString().slice(0, 16).replace('T', ' ')} |`).join('\n');
  const seen = new Set(reviews.filter((r) => r.heard).map((r) => r.shotId));
  return `# 审片记录\n\n共 ${reviews.length} 条；带声音看过的镜头 ${seen.size} / ${SHOTS.length} 个${seen.size < SHOTS.length ? '（还没有覆盖全片，不能写成「整片看过」）' : ''}。\n\n| 镜头 | 结论 | 看法 | 意见 | 审片人 | 时间（UTC） |\n| --- | --- | --- | --- | --- | --- |\n${rows}\n`;
}

export function readme(reviews: ReviewLite[] = []) {
  const shotRows = SHOTS.map((s) => `| ${s.id} | ${fmt(s.s)}–${fmt(s.e)} | ${s.line ? `${s.line}「${lineText(s.line)}」` : '—'} | ${esc(s.title)}：${esc(s.desc)} | ${esc(s.camera)} | ${esc(s.beat)} |`).join('\n');
  const secRows = SECTIONS.map((x) => `| ${x.name} | ${fmt(x.s)}–${fmt(x.e)} | ${x.lines} | ${x.mood} |`).join('\n');
  const lineRows = LINES.map((l) => `| ${l.i} | ${l.text} | ${fmt(l.s)} | ${fmt(l.e)} |`).join('\n');
  const heardShots = new Set(reviews.filter((r) => r.heard).map((r) => r.shotId)).size;
  const fixes = reviews.filter((r) => r.status === 'fix');
  return `# 《${SONG.title}》${SONG.subtitle} MV

番外 MV 新作：**${SHOTS.length} 个镜头、${LINES.length} 句歌词、${mmss(SONG.duration)}（${frames} 帧 @ ${SONG.fps} fps）**，${SONG.width}×${SONG.height}。
Vite 单页 + three.js 0.180（\`源码/\`）；像素角色全部来自 \`人物/atlas.png\`（逐字节一致）；出帧钩子 \`window.__mv.render(t, clean, w, h)\`，直接对接 \`tools/shoot_vite_mv.mjs\`。

> 谁演谁、兑现哪条习性：见第六节；同内容另存为 \`设定表_超级棒棒糖.md\`，可以原样贴进 \`番外MV/设定表.md\` 作为新的一节。

## 一、放进仓库

${F}bash
unzip ${SONG.dirName}.zip -d <仓库根目录>      # 解出 ${ROOT}/
cp ${SONG.audioRepoPath} ${ROOT}/源码/public/mv/chaoji-bangbangtang.wav   # 音轨不随包，.gitignore 已排除
cd ${ROOT}/源码 && npm install && npx tsc --noEmit && npx vite build
npx vite                                       # 浏览器预览：空格播放，拖进度条任意跳帧
${F}

## 二、出片

${F}bash
# 仓库根目录
node tools/shoot_vite_mv.mjs --dist ${ROOT}/源码/dist --out /tmp/frames_bbt --dur ${SONG.duration} --fps ${SONG.fps} --w ${SONG.width} --h ${SONG.height} --query clean
node tools/shoot_vite_mv.mjs --dist ${ROOT}/源码/dist --out /tmp/still_bbt --still 50.2 --w ${SONG.width} --h ${SONG.height}   # 只看一张构图
python3 tools/encode_frames.py --frames /tmp/frames_bbt --audio ${SONG.audioRepoPath} --out ${ROOT}/成片/${SONG.dirName}.mp4 --crf 21 --maxrate 3200k
${F}

- 页面自带 \`window.__mv.render(t, clean, w, h)\`（直接返回画布 JPEG）与 \`window.__seek(t)\`，出帧不用加钩子。
- 音轨从 0 秒对齐混入，不加增益；片尾 71.35–72.30 秒画面渐白，音乐自然收尾。
- 中间帧（约 2171 张 JPEG）放 \`/tmp\`，不进仓库；成片目录叫 \`成片/\`。mp4 默认不入库（见 \`媒体说明.md\`）。

## 三、文件

| 文件 | 说明 |
| --- | --- |
| \`README.md\` | 本文件 |
| \`分镜表.md\` | ${SHOTS.length} 镜逐镜：画面 / 角色 / 机位 / 卡点 / 为什么这样拍 |
| \`歌词.srt\` | ${LINES.length} 句带时间的歌词（实测） |
| \`卡点.json\` | 节拍网格、每句起止、每个镜头的起始帧、测量方法（\`measured: true\`） |
| \`设定表_超级棒棒糖.md\` | 选角表，按 \`番外MV/设定表.md\` 第 5 节的空表填写 |
| \`审片记录.md\` | 人看过 / 听过的记录（导出时从审片台带出） |
| \`源码/src/mv/data.ts\` | 歌词、节拍、段落、分镜、选角——纯数据，改时间只改这里 |
| \`源码/src/mv/kit.ts\` | 程序化贴图、圆角体块、像素纸片人、3D 棒棒糖、彩虹披风 |
| \`源码/src/mv/world.ts\` | 五个区域的程序化 3D 布景、天空、星空、特效池、调色板 |
| \`源码/src/mv/shots.ts\` | ${SHOTS.length} 个镜头的逐帧编排 |
| \`源码/src/mv/engine.ts\` | 渲染器、后期（泛光 / 调色 / 暗角 / 闪白）、歌词条 |
| \`源码/src/mv/atlasData.ts\`、\`源码/public/mv/atlas.png\` | 图集与逐帧坐标表（与 \`告白气球_opus5.5_笨鱼发\` 同一份，图集 = \`人物/atlas.png\`） |
| \`源码/public/mv/kuaile.otf\` | 模板字体站酷快乐体（= \`通用模板/engine/assets/fonts/ZCOOLKuaiLe-Regular.ttf\`，SIL OFL 1.1，许可证随包） |

## 四、和《童话镇》的关系：只借做法，不借画面

${STYLE_NOTES.map((s) => `- ${s}`).join('\n')}

## 五、歌词深读

${READING.map((r) => `**${r.part}（${r.lines}）**　${r.text}`).join('\n\n')}

| 段落 | 时间（秒） | 歌词 | 情绪与画面 |
| --- | --- | --- | --- |
${secRows}

## 六、选角（按 \`番外MV/设定表.md\` 第 5 节填写）

${castMd().split('\n').slice(2).join('\n')}
## 七、分镜（${SHOTS.length} 镜）

切点比开口早两帧（与通用模板一致）。逐镜细节见 \`分镜表.md\`。

| 镜头 | 时间（秒） | 歌词 | 画面 | 机位 | 卡点 |
| --- | --- | --- | --- | --- | --- |
${shotRows}

## 八、卡点是怎么对的

- 音源：仓库根 \`${SONG.audioRepoPath}\`，${SONG.sampleRate} Hz 立体声 16 位，${SONG.samples} 采样 = ${SONG.duration} 秒。
- 节拍：频谱通量自相关测速得 **${BEAT.bpm} BPM**（拍长 ${BEAT.period} 秒），动态规划跟踪全曲 115 拍，线性拟合最大偏差 0.05 秒；第 k 拍 = ${BEAT.offset} + ${BEAT.period}·k 秒，小节从第 0 拍起每 4 拍一个。
- 结构（低频 < 120 Hz 能量逐 50 毫秒复核）：开头约八秒半没有底鼓（清唱感）；**底鼓在第 14 拍（${BEAT.kickIn} 秒）进来**；**${BEAT.stopFrom}–${BEAT.stopTo} 秒整段停拍**，第九句「如果没有」在静音里弱起；44.2 秒起鼓点加花；**终段副歌落在第 76 拍（${BEAT.finalFrom} 秒）**。
- 歌词：HPSS 谐波/打击分离后取 300–3000 Hz 能量分句，再用同一段旋律在三处出现的相对位置互相校核：第 1/17 句、第 3/19 句、第 4/20 句、第 8/24 句的相对起点偏差都在 0.15 秒以内。第 8、16、24 句后半是拖腔 / 尾句重复，歌词条保持显示，逐字染色先走完。
- 这是**拍点级**对齐：没有做人声分离，不是逐音节对齐。听感要人过一遍。

| 句 | 歌词 | 开口 | 收声 |
| --- | --- | --- | --- |
${lineRows}

## 九、画面红线自查

- 零水印、零角标、零「AI 生成」贴纸；不出现粉丝数、播放量、进度条、数据图表。
- 角色只用图集里的 Q 版像素造型，七头身立绘没用；缺动作直接报错（\`Actor.do\` 找不到动作就抛错，不顶替）。
- **没有新增生图**：背景全部是程序化 3D；超级棒棒糖、灯、积木、月亮都是代码现搭的体块，螺旋糖纹由 Canvas 现画。人物提示词只作参考，没有出图。
- 不画假手：道具和糖都放在手边略靠前，不画手指。
- 画面上的字只有片名和歌词，全部是常用汉字；用 fontTools 查过站酷快乐体的字表，${LINES.length} 句歌词与片名逐字都在。
- 歌词条上没有数字。

## 十、机器查过的 / 人看过听过的

**机器查过的**

- 图集 \`源码/public/mv/atlas.png\` 与 \`人物/atlas.png\` 逐字节一致（cmp）；字体与模板字体逐字节一致。
- 引擎启动时核对：${SHOTS.length} 个镜头都有编排函数；所有动作名都在 \`atlasData.ts\` 里。
- TypeScript 严格模式通过；审片台网页（Next.js）生产构建通过。
- zip 里的 \`源码/\` 单独解出后 \`npm install && npx tsc --noEmit && npx vite build\` 通过。
- 无头 Chromium（SwiftShader，与 \`tools/shoot_vite_mv.mjs\` 同一套启动参数）经 \`window.__mv.render\` 每 0.5 秒渲一帧，全片 146 帧无报错；缺动作会当场报错，开发中据此把群像动作改成各人图集里真有的那一个。
- 开发时逐镜抽帧拼成总览图检查过构图（遮挡、出画、过曝都按图改过）——这是看静帧，不等于有人带声音看过成片。
- 审片台「分镜表」页可以跑**全片逐帧预检**（每秒四帧把整片渲一遍，统计报错、空帧和每帧耗时）。

**人看过 / 听过的**

${reviews.length ? `- 审片记录 ${reviews.length} 条，带声音看过的镜头 ${heardShots} / ${SHOTS.length} 个；标「需要修改」的 ${fixes.length} 条${fixes.length ? `（${fixes.map((f) => f.shotId).join('、')}）` : ''}。详见 \`审片记录.md\`。` : '- **没有人整片看过、听过。** 导出时审片记录为空。'}
${heardShots < SHOTS.length ? '- 还没有人带着声音把整片从头到尾过一遍：动作顺不顺、卡点听着准不准，要人看。' : '- 所有镜头都有人带声音看过。'}

## 十一、没做的 / 公开发布前要自己确认的

- **没有出 mp4**：交付的是可复现的源码 + 文档。按第二节在仓库里出片（需要仓库自带的 chromium 出帧链与 ffmpeg）。
- 逐音节同步、响度母带、封面、发布文案都不在范围内。
- 角色形象源头是 ZipZipPipe《大AI和小AI们》（CC BY-NC-SA 4.0：署名、不商用、同协议共享），上游再分发许可仍未核（见 \`素材许可与来源.md\`）。
- 原曲录音没有授权记录，公开前自己核。字体为 SIL OFL 1.1。
- 片子里不放「AI 生成」角标，合规声明在发布页用平台自带功能补上。
`;
}

// ───────── Vite 源码工程（模板文件） ─────────
const VITE_FILES: Record<string, string> = {
  'package.json': JSON.stringify({
    name: 'chaoji-bangbangtang-mv', private: true, version: '0.0.0', type: 'module',
    scripts: { dev: 'vite', build: 'tsc --noEmit && vite build', preview: 'vite preview' },
    dependencies: { three: '0.180.0' },
    devDependencies: { '@types/three': '0.180.0', typescript: '5.9.3', vite: '7.3.7' },
  }, null, 2) + '\n',
  'index.html': `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>超级棒棒糖 · 童年治愈 3D 版</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
`,
  'vite.config.ts': `import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: { outDir: 'dist', assetsInlineLimit: 0, chunkSizeWarningLimit: 2000 },
});
`,
  'tsconfig.json': JSON.stringify({
    compilerOptions: { target: 'ES2020', module: 'ESNext', moduleResolution: 'bundler', lib: ['ES2020', 'DOM', 'DOM.Iterable'], strict: true, skipLibCheck: true, noEmit: true, isolatedModules: true, types: ['vite/client'] },
    include: ['src'],
  }, null, 2) + '\n',
  '.gitignore': 'node_modules/\ndist/\npublic/mv/*.wav\n',
  'src/style.css': `html, body { margin: 0; height: 100%; background: #1b1838; color: #fff; font-family: system-ui, sans-serif; }
#app { height: 100%; display: flex; flex-direction: column; }
.stage { flex: 1; display: grid; place-items: center; overflow: hidden; }
#mv { width: min(100vw, calc((100vh - 56px) * 16 / 9)); aspect-ratio: 16 / 9; display: block; }
.clean #mv { width: 100vw; height: 100vh; }
.bar { height: 56px; display: flex; gap: 12px; align-items: center; padding: 0 16px; background: rgba(255, 255, 255, 0.06); font-size: 14px; }
.bar input { flex: 1; accent-color: #ff8fb1; }
.bar button { border: 0; border-radius: 999px; padding: 8px 18px; background: #ff8fb1; color: #fff; font-size: 14px; cursor: pointer; }
`,
  'src/main.ts': `// 《超级棒棒糖》Vite 单页：预览 + 出帧钩子（tools/shoot_vite_mv.mjs 用）
import './style.css';
import { MvEngine } from './mv/engine';
import { SHOTS, SONG } from './mv/data';

declare global {
  interface Window {
    __mv?: { duration: number; shots: number; ready: () => boolean; render: (t: number, clean?: boolean, w?: number, h?: number) => string };
    __seek?: (t: number) => void;
  }
}

const clean = new URLSearchParams(location.search).has('clean');
if (clean) document.body.classList.add('clean');
const app = document.getElementById('app')!;
app.innerHTML = \`<div class="stage"><canvas id="mv" width="1280" height="720"></canvas></div>
<div class="bar"\${clean ? ' hidden' : ''}><button id="play">播放</button><input id="seek" type="range" min="0" max="\${SONG.duration}" step="0.01" value="0" /><span id="info"></span></div>\`;
const canvas = document.getElementById('mv') as HTMLCanvasElement;
const btn = document.getElementById('play') as HTMLButtonElement;
const seek = document.getElementById('seek') as HTMLInputElement;
const info = document.getElementById('info') as HTMLSpanElement;
const audio = new Audio('./mv/chaoji-bangbangtang.wav');
audio.preload = 'auto';

(async () => {
  const eng = new MvEngine(canvas, { atlasUrl: './mv/atlas.png', fontUrl: './mv/kuaile.otf' });
  await eng.load();
  eng.render(0);
  window.__mv = { duration: SONG.duration, shots: SHOTS.length, ready: () => eng.ready, render: (t, _clean, w = 1280, h = Math.round((w * 9) / 16)) => eng.snapshot(t, w, h, 0.94) };
  window.__seek = (t) => { audio.currentTime = t; eng.render(t); };
  let playing = false;
  const show = (t: number) => { seek.value = String(t); info.textContent = \`\${t.toFixed(2)} 秒 · \${SHOTS[eng.lastShot].id} \${SHOTS[eng.lastShot].title}\`; };
  btn.onclick = async () => { if (playing) { audio.pause(); playing = false; btn.textContent = '播放'; } else { await audio.play(); playing = true; btn.textContent = '暂停'; } };
  seek.oninput = () => { const t = Number(seek.value); audio.currentTime = t; eng.render(t); show(t); };
  window.addEventListener('keydown', (e) => { if (e.code === 'Space') { e.preventDefault(); btn.click(); } });
  audio.onended = () => { playing = false; btn.textContent = '播放'; };
  const loop = () => { if (playing) { const t = audio.currentTime; eng.render(t); show(t); } requestAnimationFrame(loop); };
  requestAnimationFrame(loop);
  show(0);
})().catch((e) => { console.error(e); app.insertAdjacentHTML('beforeend', \`<p style="padding:16px;color:#ff9a9a">\${String(e)}</p>\`); });
`,
};

const ENGINE_FILES = ['atlasData.ts', 'data.ts', 'kit.ts', 'world.ts', 'shots.ts', 'engine.ts'];
const ASSETS = ['atlas.png', 'kuaile.otf', 'OFL-ZCOOLKuaiLe.txt'];

export async function buildZip(reviews: ReviewLite[]) {
  const zip = new JSZip(); const files: string[] = [];
  const add = (p: string, c: string | Uint8Array) => { zip.file(`${ROOT}/${p}`, c); files.push(`${ROOT}/${p}`); };
  add('README.md', readme(reviews));
  add('分镜表.md', storyboardMd());
  add('歌词.srt', srt());
  add('卡点.json', cues());
  add('设定表_超级棒棒糖.md', castMd());
  add('审片记录.md', reviewMd(reviews));
  add('成片/.gitkeep', '');
  for (const [p, c] of Object.entries(VITE_FILES)) add(`源码/${p}`, c);
  const cwd = process.cwd();
  for (const f of ENGINE_FILES) add(`源码/src/mv/${f}`, await fs.readFile(path.join(cwd, 'src/mv', f), 'utf8'));
  for (const a of ASSETS) add(`源码/public/mv/${a}`, new Uint8Array(await fs.readFile(path.join(cwd, 'public/mv', a))));
  const buffer = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  return { buffer, files };
}

export const DELIVERY_TREE = [
  `${ROOT}/README.md`, `${ROOT}/分镜表.md`, `${ROOT}/歌词.srt`, `${ROOT}/卡点.json`, `${ROOT}/设定表_超级棒棒糖.md`, `${ROOT}/审片记录.md`, `${ROOT}/成片/.gitkeep`,
  ...Object.keys(VITE_FILES).map((p) => `${ROOT}/源码/${p}`), ...ENGINE_FILES.map((f) => `${ROOT}/源码/src/mv/${f}`), ...ASSETS.map((a) => `${ROOT}/源码/public/mv/${a}`),
];
