import Link from 'next/link';
import MvPlayer from '@/components/MvPlayer';
import { BEAT, LINES, READING, SECTIONS, SHOTS, SONG, STYLE_NOTES } from '@/mv/data';

export default async function HomePage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const sp = await searchParams;
  const startAt = Math.max(0, Math.min(SONG.duration - 0.1, Number(sp.t) || 0));
  const stats = [
    `${SHOTS.length} 镜`, `${LINES.length} 句歌词`, `1 分 ${(SONG.duration - 60).toFixed(1)} 秒`, `${BEAT.bpm} BPM 实测卡点`, '全程序化 3D 布景', '零张生成图',
  ];
  return (
    <main className="mx-auto max-w-7xl px-4 pb-8 pt-8 sm:px-6">
      <section className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-semibold tracking-widest text-pink-500">番外 MV · {SONG.subtitle}</p>
          <h1 className="font-display mt-1 text-5xl leading-tight sm:text-6xl"><span className="candy-text">超级棒棒糖</span></h1>
          <p className="mt-2 max-w-2xl text-violet-800/80">一支攥在手心就不怕黑的糖。魔法会失灵——失灵以后，还有自己、朋友和爱；最后那道光，是她自己的。</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {stats.map((s) => <span key={s} className="rounded-full bg-white/80 px-3 py-1 text-xs font-semibold text-violet-700 ring-1 ring-violet-100">{s}</span>)}
        </div>
      </section>

      <MvPlayer startAt={startAt} />

      <section className="mt-12">
        <h2 className="font-display text-3xl text-violet-950">歌词深读：同一句歌，唱了三遍，意思换了三次</h2>
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {READING.map((r, i) => (
            <article key={r.part} className="rounded-3xl bg-white/85 p-5 ring-1 ring-violet-100">
              <div className="mb-2 flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-full text-sm font-bold text-white" style={{ background: ['#b59cff', '#7cc8ff', '#a7adbb', '#8be0a4', '#ff8fb1'][i] }}>{i + 1}</span>
                <h3 className="font-display text-xl">{r.part}</h3><span className="text-xs text-violet-500">{r.lines}</span>
              </div>
              <p className="text-sm leading-relaxed text-violet-900/85">{r.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-12 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <div className="rounded-3xl bg-white/85 p-6 ring-1 ring-violet-100">
          <h2 className="font-display text-2xl">段落与实测节拍</h2>
          <ol className="mt-4 space-y-3">
            {SECTIONS.map((s) => (
              <li key={s.name} className="flex gap-3">
                <span className="mt-0.5 shrink-0 rounded-full bg-violet-100 px-2.5 py-0.5 font-mono text-xs text-violet-700">{s.s.toFixed(2)}–{s.e.toFixed(2)}s</span>
                <div><b className="text-violet-950">{s.name}</b><span className="ml-2 text-xs text-pink-500">{s.lines}</span><p className="text-sm text-violet-800/80">{s.mood}</p></div>
              </li>
            ))}
          </ol>
          <p className="mt-4 rounded-2xl bg-amber-50 p-3 text-xs text-amber-800">
            {BEAT.bpm} BPM（拍长 {BEAT.period} 秒）；底鼓第十四拍进入（{BEAT.kickIn} 秒）；{BEAT.stopFrom}–{BEAT.stopTo} 秒全曲唯一停拍，「如果没有」在静音里唱出，画面在这里失色、糖掉进小溪。拍点级对齐，未做逐音节对齐。
          </p>
        </div>
        <div className="rounded-3xl bg-white/85 p-6 ring-1 ring-violet-100">
          <h2 className="font-display text-2xl">和《童话镇》：只借做法，不借画面</h2>
          <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-violet-900/85">{STYLE_NOTES.map((s) => <li key={s}>{s}</li>)}</ul>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/storyboard" className="candy-btn rounded-full px-5 py-2 text-sm font-bold text-white shadow">看二十七镜分镜表</Link>
            <Link href="/delivery" className="rounded-full bg-violet-100 px-5 py-2 text-sm font-bold text-violet-800 ring-1 ring-violet-200 hover:bg-violet-200">下载 README 与 ZIP</Link>
          </div>
        </div>
      </section>
    </main>
  );
}
