import type { Metadata } from 'next';
import StoryboardThumbs from '@/components/StoryboardThumbs';
import { CAST, SHOTS } from '@/mv/data';

export const metadata: Metadata = { title: '分镜表 · 超级棒棒糖' };

export default function StoryboardPage() {
  return (
    <main className="mx-auto max-w-7xl px-4 pb-8 pt-8 sm:px-6">
      <h1 className="font-display text-4xl">分镜表 · {SHOTS.length} 镜</h1>
      <p className="mt-2 max-w-3xl text-violet-800/80">缩略图由同一个引擎现场渲染（取每个镜头 58% 处）。「六格」从头到尾抽六帧看走位；「在播放器里看」带声音从这一镜开始。</p>

      <section className="mt-8 rounded-3xl bg-white/85 p-6 ring-1 ring-violet-100">
        <h2 className="font-display text-2xl">选角（按 番外MV/设定表.md 第五节填写）</h2>
        <p className="mt-1 text-sm text-violet-700">一支 MV 一个人只演一个形象；性格靠动作兑现；群像里只做自己的招牌动作。</p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {CAST.map((c) => (
            <div key={c.key} className="rounded-2xl bg-violet-50/70 p-4 text-sm">
              <div className="flex items-baseline gap-2"><b className="font-display text-lg text-violet-950">{c.who}</b><code className="text-xs text-violet-500">{c.key}</code></div>
              <p className="mt-1 text-pink-600">{c.role}</p>
              <p className="mt-1 text-violet-900/85"><b>习性</b> {c.habit}</p>
              <p className="text-violet-900/85"><b>动作</b> {c.action}</p>
              <p className="text-rose-700/80"><b>不许写成</b> {c.never}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <StoryboardThumbs />
      </section>
    </main>
  );
}
