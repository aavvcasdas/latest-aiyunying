import type { Metadata } from 'next';
import Link from 'next/link';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: '超级棒棒糖 · 童年治愈 3D MV',
  description: '番外 MV《超级棒棒糖》：程序化 3D 软糖世界 + 项目自带像素角色，二十七镜按实测节拍卡点；附 README 与可放进仓库的 zip。',
};

const NAV = [
  { href: '/', label: '播放 MV' },
  { href: '/storyboard', label: '分镜表' },
  { href: '/delivery', label: '交付 README / ZIP' },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen text-violet-950 antialiased">
        <header className="sticky top-0 z-30 border-b border-white/60 bg-white/70 backdrop-blur">
          <nav className="mx-auto flex max-w-7xl items-center gap-2 px-4 py-3 sm:px-6">
            <Link href="/" className="mr-4 flex items-center gap-2">
              <span className="relative grid h-9 w-9 place-items-center rounded-full bg-[conic-gradient(#ff8fb1,#ffb36b,#ffe066,#8be0a4,#7cc8ff,#b59cff,#ff8fb1)] shadow-inner">
                <span className="h-3 w-3 rounded-full bg-white/90" />
              </span>
              <span className="font-display text-xl text-violet-950">超级棒棒糖</span>
            </Link>
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="rounded-full px-3 py-1.5 text-sm font-semibold text-violet-700 transition hover:bg-pink-100 hover:text-pink-700">{n.label}</Link>
            ))}
          </nav>
        </header>
        {children}
        <footer className="mx-auto max-w-7xl px-6 pb-10 pt-16 text-xs text-violet-500">
          角色形象源自 ZipZipPipe《大AI和小AI们》（CC BY-NC-SA 4.0），像素造型来自项目 人物/atlas.png；字体站酷快乐体（SIL OFL 1.1）。原曲录音授权未核，公开发布前请自行确认。
        </footer>
      </body>
    </html>
  );
}
