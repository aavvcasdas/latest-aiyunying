import type { Metadata } from 'next';
import { desc } from 'drizzle-orm';
import { db } from '@/db';
import { exportLogs, shotReviews } from '@/db/schema';
import Markdown from '@/components/Markdown';
import ReviewPanel from '@/components/ReviewPanel';
import { DELIVERY_TREE, readme } from '@/lib/deliver';
import { SONG } from '@/mv/data';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = { title: '交付 README / ZIP · 超级棒棒糖' };

export default async function DeliveryPage() {
  const reviews = await db.select().from(shotReviews).orderBy(desc(shotReviews.createdAt));
  const logs = await db.select().from(exportLogs).orderBy(desc(exportLogs.createdAt)).limit(8);
  const md = readme(reviews);
  const rows = reviews.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
  return (
    <main className="mx-auto max-w-7xl px-4 pb-8 pt-8 sm:px-6">
      <h1 className="font-display text-4xl">交付：README 与 ZIP</h1>
      <p className="mt-2 max-w-3xl text-violet-800/80">zip 解压到仓库根目录，得到 <code className="rounded bg-violet-100 px-1.5">番外MV/{SONG.dirName}/</code>：文档、歌词、卡点、选角补充、审片记录，以及可以直接 <code className="rounded bg-violet-100 px-1.5">vite build</code> 再交给 <code className="rounded bg-violet-100 px-1.5">tools/shoot_vite_mv.mjs</code> 出帧的源码工程。</p>

      <div className="mt-6 flex flex-wrap gap-3">
        <a href="/api/export" className="candy-btn rounded-full px-6 py-3 text-sm font-bold text-white shadow-lg">下载 ZIP（{SONG.dirName}.zip）</a>
        <a href="/api/readme" className="rounded-full bg-white px-6 py-3 text-sm font-bold text-violet-800 shadow ring-1 ring-violet-200 hover:bg-violet-50">下载 README.md</a>
        <a href="/api/readme?inline" target="_blank" className="rounded-full bg-white px-6 py-3 text-sm font-bold text-violet-800 shadow ring-1 ring-violet-200 hover:bg-violet-50">查看原始 Markdown</a>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <article className="rounded-3xl bg-white/90 p-6 ring-1 ring-violet-100 sm:p-8">
          <Markdown source={md} />
        </article>
        <aside className="space-y-6">
          <section className="rounded-3xl bg-white/90 p-5 ring-1 ring-violet-100">
            <h2 className="font-display text-xl">zip 里有什么（{DELIVERY_TREE.length} 个文件）</h2>
            <ul className="mt-3 max-h-80 space-y-1 overflow-auto font-mono text-[11px] text-violet-800">
              {DELIVERY_TREE.map((f) => <li key={f} className="truncate">{f.replace(`番外MV/${SONG.dirName}/`, '')}</li>)}
            </ul>
            <p className="mt-3 text-xs text-violet-500">音轨不随包：从仓库根拷 {SONG.audioRepoPath} 到 源码/public/mv/（README 第一节）。</p>
          </section>
          <section>
            <h2 className="font-display mb-3 text-xl">审片台（人看过 / 听过）</h2>
            <ReviewPanel initial={rows} />
          </section>
          <section className="rounded-3xl bg-white/90 p-5 ring-1 ring-violet-100">
            <h2 className="font-display text-xl">最近的导出</h2>
            <ul className="mt-2 space-y-1 text-xs text-violet-700">
              {logs.length === 0 && <li>还没有导出过。</li>}
              {logs.map((l) => <li key={l.id}>{l.createdAt.toLocaleString('zh-CN')} · {l.kind === 'zip' ? 'ZIP' : 'README'} · {l.files} 个文件 · {(l.bytes / 1024).toFixed(0)} KB</li>)}
            </ul>
          </section>
        </aside>
      </div>
    </main>
  );
}
