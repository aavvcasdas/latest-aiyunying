import { desc, eq } from 'drizzle-orm';
import { db } from '@/db';
import { shotReviews } from '@/db/schema';
import { SHOTS } from '@/mv/data';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const IDS = new Set(SHOTS.map((s) => s.id).concat('全片'));
const STATUSES = new Set(['ok', 'fix', 'note']);

export async function GET() {
  const rows = await db.select().from(shotReviews).orderBy(desc(shotReviews.createdAt));
  return Response.json({ ok: true, reviews: rows });
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return Response.json({ ok: false, error: '请求体不是 JSON' }, { status: 400 }); }
  const shotId = String(body.shotId ?? '');
  const status = String(body.status ?? 'ok');
  const note = String(body.note ?? '').trim().slice(0, 1000);
  const reviewer = String(body.reviewer ?? '').trim().slice(0, 40) || '审片人';
  const heard = body.heard ? 1 : 0;
  if (!IDS.has(shotId)) return Response.json({ ok: false, error: '没有这个镜头：' + shotId }, { status: 400 });
  if (!STATUSES.has(status)) return Response.json({ ok: false, error: '结论只能是 通过 / 需要修改 / 备注' }, { status: 400 });
  if (status === 'fix' && !note) return Response.json({ ok: false, error: '标「需要修改」时请写明改什么' }, { status: 400 });
  const [row] = await db.insert(shotReviews).values({ shotId, status, note, reviewer, heard }).returning();
  return Response.json({ ok: true, review: row });
}

export async function DELETE(req: Request) {
  const id = Number(new URL(req.url).searchParams.get('id'));
  if (!Number.isInteger(id) || id <= 0) return Response.json({ ok: false, error: 'id 不对' }, { status: 400 });
  await db.delete(shotReviews).where(eq(shotReviews.id, id));
  return Response.json({ ok: true });
}
