import { desc } from 'drizzle-orm';
import { db } from '@/db';
import { exportLogs, shotReviews } from '@/db/schema';
import { buildZip } from '@/lib/deliver';
import { SONG } from '@/mv/data';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    const reviews = await db.select().from(shotReviews).orderBy(desc(shotReviews.createdAt));
    const { buffer, files } = await buildZip(reviews);
    await db.insert(exportLogs).values({ kind: 'zip', bytes: buffer.byteLength, files: files.length });
    const name = `${SONG.dirName}.zip`;
    return new Response(Buffer.from(buffer), {
      headers: {
        'content-type': 'application/zip',
        'content-length': String(buffer.byteLength),
        'content-disposition': `attachment; filename="chaoji-bangbangtang-3d-mv.zip"; filename*=UTF-8''${encodeURIComponent(name)}`,
        'cache-control': 'no-store',
      },
    });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
