import { desc } from 'drizzle-orm';
import { db } from '@/db';
import { exportLogs, shotReviews } from '@/db/schema';
import { readme } from '@/lib/deliver';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(req: Request) {
  try {
    const reviews = await db.select().from(shotReviews).orderBy(desc(shotReviews.createdAt));
    const md = readme(reviews);
    const inline = new URL(req.url).searchParams.has('inline');
    if (!inline) await db.insert(exportLogs).values({ kind: 'readme', bytes: Buffer.byteLength(md), files: 1 });
    return new Response(md, {
      headers: {
        'content-type': 'text/markdown; charset=utf-8',
        'content-disposition': inline ? 'inline' : `attachment; filename="README.md"`,
        'cache-control': 'no-store',
      },
    });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
