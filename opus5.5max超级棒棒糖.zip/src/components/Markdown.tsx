import type { ReactNode } from 'react';

function inline(s: string, key: string): ReactNode[] {
  return s.split(/(`[^`]+`|\*\*[^*]+\*\*)/g).filter(Boolean).map((p, i) => {
    if (p.startsWith('`') && p.endsWith('`')) return <code key={`${key}-${i}`} className="rounded bg-violet-100 px-1.5 py-0.5 text-[0.85em] text-violet-800">{p.slice(1, -1)}</code>;
    if (p.startsWith('**') && p.endsWith('**')) return <strong key={`${key}-${i}`} className="text-violet-950">{p.slice(2, -2)}</strong>;
    return <span key={`${key}-${i}`}>{p}</span>;
  });
}
const cells = (row: string) => row.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());

/** 够用的 Markdown：标题 / 段落 / 列表 / 表格 / 代码块 / 引用 / 行内代码与加粗 */
export default function Markdown({ source }: { source: string }) {
  const lines = source.split('\n'); const out: ReactNode[] = []; let i = 0, k = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith('```')) {
      const buf: string[] = []; i++;
      while (i < lines.length && !lines[i].startsWith('```')) buf.push(lines[i++]);
      i++; out.push(<pre key={k++} className="overflow-x-auto rounded-2xl bg-[#231f45] p-4 text-xs leading-relaxed text-pink-100"><code>{buf.join('\n')}</code></pre>); continue;
    }
    const h = /^(#{1,3})\s+(.*)$/.exec(l);
    if (h) {
      const lv = h[1].length; const cls = lv === 1 ? 'text-3xl mt-2' : lv === 2 ? 'text-2xl mt-8 border-b border-pink-200 pb-1' : 'text-lg mt-5';
      out.push(lv === 1 ? <h1 key={k++} className={`font-display text-violet-950 ${cls}`}>{inline(h[2], `h${k}`)}</h1> : lv === 2 ? <h2 key={k++} className={`font-display text-violet-950 ${cls}`}>{inline(h[2], `h${k}`)}</h2> : <h3 key={k++} className={`font-display text-violet-950 ${cls}`}>{inline(h[2], `h${k}`)}</h3>);
      i++; continue;
    }
    if (l.startsWith('|')) {
      const rows: string[] = []; while (i < lines.length && lines[i].startsWith('|')) rows.push(lines[i++]);
      const head = cells(rows[0]); const body = rows.slice(2).map(cells);
      out.push(
        <div key={k++} className="overflow-x-auto rounded-2xl ring-1 ring-violet-100">
          <table className="w-full min-w-[640px] text-left text-xs">
            <thead className="bg-violet-100/70 text-violet-900"><tr>{head.map((c, j) => <th key={j} className="px-3 py-2 font-semibold">{inline(c, `th${k}${j}`)}</th>)}</tr></thead>
            <tbody>{body.map((r, ri) => <tr key={ri} className="border-t border-violet-100 align-top odd:bg-white even:bg-violet-50/40">{r.map((c, j) => <td key={j} className="px-3 py-2 text-violet-900/90">{inline(c, `td${k}${ri}${j}`)}</td>)}</tr>)}</tbody>
          </table>
        </div>,
      ); continue;
    }
    if (/^(-|\d+\.)\s/.test(l)) {
      const ordered = /^\d+\./.test(l); const items: string[] = [];
      while (i < lines.length && /^(-|\d+\.)\s/.test(lines[i])) items.push(lines[i++].replace(/^(-|\d+\.)\s/, ''));
      const Tag = ordered ? 'ol' : 'ul';
      out.push(<Tag key={k++} className={`${ordered ? 'list-decimal' : 'list-disc'} space-y-1 pl-6 text-sm text-violet-900/90`}>{items.map((it, j) => <li key={j}>{inline(it, `li${k}${j}`)}</li>)}</Tag>); continue;
    }
    if (l.startsWith('> ')) { out.push(<blockquote key={k++} className="rounded-r-2xl border-l-4 border-pink-300 bg-pink-50 px-4 py-2 text-sm text-pink-900">{inline(l.slice(2), `q${k}`)}</blockquote>); i++; continue; }
    if (!l.trim()) { i++; continue; }
    const para: string[] = []; while (i < lines.length && lines[i].trim() && !/^(#|\||-\s|\d+\.\s|```|> )/.test(lines[i])) para.push(lines[i++]);
    out.push(<p key={k++} className="text-sm leading-relaxed text-violet-900/90">{inline(para.join(' '), `p${k}`)}</p>);
  }
  return <div className="space-y-3">{out}</div>;
}
