'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { SHOTS } from '@/mv/data';

export interface ReviewRow { id: number; shotId: string; status: string; heard: number; note: string; reviewer: string; createdAt: string }
const LABEL: Record<string, string> = { ok: '通过', fix: '需要修改', note: '备注' };
const TONE: Record<string, string> = { ok: 'bg-emerald-100 text-emerald-700', fix: 'bg-rose-100 text-rose-700', note: 'bg-sky-100 text-sky-700' };

export default function ReviewPanel({ initial }: { initial: ReviewRow[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(initial);
  const [shotId, setShotId] = useState('全片');
  const [status, setStatus] = useState('ok');
  const [heard, setHeard] = useState(true);
  const [note, setNote] = useState('');
  const [reviewer, setReviewer] = useState('');
  const [msg, setMsg] = useState('');
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true); setMsg('');
    try {
      const r = await fetch('/api/reviews', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ shotId, status, heard, note, reviewer }) });
      const j = await r.json();
      if (!j.ok) { setMsg(j.error || '保存失败'); return; }
      setRows((x) => [{ ...j.review, createdAt: String(j.review.createdAt) }, ...x]); setNote(''); setMsg('已记下。README 与 zip 里的审片记录会带上这一条。'); router.refresh();
    } catch (x) { setMsg(String(x)); } finally { setSaving(false); }
  };
  const remove = async (id: number) => {
    const r = await fetch(`/api/reviews?id=${id}`, { method: 'DELETE' }); const j = await r.json();
    if (j.ok) { setRows((x) => x.filter((y) => y.id !== id)); router.refresh(); }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={submit} className="space-y-3 rounded-3xl bg-white/90 p-5 ring-1 ring-violet-100">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm text-violet-800">镜头
            <select value={shotId} onChange={(e) => setShotId(e.target.value)} className="mt-1 w-full rounded-xl border border-violet-200 bg-white px-3 py-2">
              <option value="全片">全片</option>
              {SHOTS.map((s) => <option key={s.id} value={s.id}>{s.id} · {s.title}</option>)}
            </select>
          </label>
          <label className="text-sm text-violet-800">审片人
            <input value={reviewer} onChange={(e) => setReviewer(e.target.value)} placeholder="署名（可空）" className="mt-1 w-full rounded-xl border border-violet-200 px-3 py-2" />
          </label>
        </div>
        <div className="flex flex-wrap gap-2">
          {(['ok', 'fix', 'note'] as const).map((s) => (
            <button type="button" key={s} onClick={() => setStatus(s)} className={`rounded-full px-4 py-1.5 text-sm font-semibold ring-1 ${status === s ? TONE[s] + ' ring-transparent' : 'bg-white text-violet-600 ring-violet-200'}`}>{LABEL[s]}</button>
          ))}
          <label className="ml-auto flex items-center gap-2 text-sm text-violet-800"><input type="checkbox" checked={heard} onChange={(e) => setHeard(e.target.checked)} className="accent-pink-500" />带声音从头到尾看过</label>
        </div>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder={status === 'fix' ? '要改什么（必填）：比如「S07 灯灭早了半拍」' : '意见（可空）'} className="w-full rounded-xl border border-violet-200 px-3 py-2 text-sm" />
        <div className="flex items-center gap-3">
          <button disabled={saving} className="candy-btn rounded-full px-5 py-2 text-sm font-bold text-white shadow disabled:opacity-50">{saving ? '保存中…' : '记一条审片意见'}</button>
          {msg && <span className="text-sm text-violet-700">{msg}</span>}
        </div>
      </form>
      <ul className="space-y-2">
        {rows.length === 0 && <li className="rounded-2xl bg-amber-50 p-4 text-sm text-amber-800">还没有审片记录：README 会如实写「没有人整片看过、听过」。</li>}
        {rows.map((r) => (
          <li key={r.id} className="flex items-start gap-3 rounded-2xl bg-white/90 p-3 text-sm ring-1 ring-violet-100">
            <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-bold ${TONE[r.status] ?? ''}`}>{LABEL[r.status] ?? r.status}</span>
            <div className="min-w-0 flex-1">
              <p className="text-violet-950"><b>{r.shotId}</b>{r.heard ? ' · 带声音看过' : ' · 只看画面'}{r.note ? ` · ${r.note}` : ''}</p>
              <p className="text-xs text-violet-500">{r.reviewer} · {new Date(r.createdAt).toLocaleString('zh-CN')}</p>
            </div>
            <button onClick={() => remove(r.id)} className="text-xs text-rose-500 hover:underline">删除</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
