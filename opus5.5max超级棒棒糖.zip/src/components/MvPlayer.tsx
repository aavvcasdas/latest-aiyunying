'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { LINES, SECTIONS, SHOTS, SONG } from '@/mv/data';
import type { MvEngine } from '@/mv/engine';

declare global {
  interface Window {
    __mv?: { duration: number; shots: number; ready: () => boolean; render: (t: number, clean?: boolean, w?: number, h?: number) => string };
    __seek?: (t: number) => void;
  }
}

const fmt = (t: number) => `${String(Math.floor(t / 60)).padStart(2, '0')}:${(t % 60).toFixed(1).padStart(4, '0')}`;
const SEC_COLORS = ['#b59cff', '#7cc8ff', '#c9ced8', '#8be0a4', '#ff8fb1'];

export default function MvPlayer({ startAt = 0 }: { startAt?: number }) {
  const wrap = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const audio = useRef<HTMLAudioElement>(null);
  const eng = useRef<MvEngine | null>(null);
  const playingRef = useRef(false);
  const scaleRef = useRef(1);
  const lastUi = useRef(0);
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState('');
  const [playing, setPlaying] = useState(false);
  const [started, setStarted] = useState(false);
  const [t, setT] = useState(startAt);
  const [hq, setHq] = useState(true);

  const fit = useCallback(() => {
    const e = eng.current, el = wrap.current; if (!e || !el) return;
    const r = el.getBoundingClientRect(); const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const w = Math.min(1920, Math.round(r.width * dpr * scaleRef.current)); e.resize(w, Math.round((w * 9) / 16));
  }, []);

  const draw = useCallback((time: number) => { const e = eng.current; if (e?.ready) e.render(time); }, []);

  useEffect(() => {
    let dead = false;
    (async () => {
      const { MvEngine } = await import('@/mv/engine');
      if (!canvas.current) return;
      const e = new MvEngine(canvas.current, { atlasUrl: '/mv/atlas.png', fontUrl: '/mv/kuaile.otf' });
      await e.load();
      if (dead) { e.dispose(); return; }
      eng.current = e; fit(); e.render(startAt); setReady(true);
      window.__mv = { duration: SONG.duration, shots: SHOTS.length, ready: () => e.ready, render: (time, _c, w = 1280, h = Math.round((w * 9) / 16)) => e.snapshot(time, w, h, 0.94) };
      window.__seek = (time) => { if (audio.current) audio.current.currentTime = time; e.render(time); setT(time); };
    })().catch((x) => { console.error(x); setErr(String(x?.message || x)); });
    return () => { dead = true; eng.current?.dispose(); eng.current = null; delete window.__mv; delete window.__seek; };
  }, [fit, startAt]);

  useEffect(() => {
    const el = wrap.current; if (!el) return;
    const ro = new ResizeObserver(() => { fit(); if (!playingRef.current) draw(audio.current?.currentTime ?? 0); });
    ro.observe(el); return () => ro.disconnect();
  }, [fit, draw]);

  useEffect(() => {
    let raf = 0;
    const loop = (now: number) => {
      if (playingRef.current && audio.current) {
        const time = audio.current.currentTime; draw(time);
        if (now - lastUi.current > 90) { lastUi.current = now; setT(time); }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop); return () => cancelAnimationFrame(raf);
  }, [draw]);

  const play = useCallback(async () => {
    const a = audio.current; if (!a || !ready) return;
    if (a.currentTime >= SONG.duration - 0.05) a.currentTime = 0;
    try { await a.play(); playingRef.current = true; setPlaying(true); setStarted(true); } catch (x) { setErr('浏览器拦截了播放：' + String(x)); }
  }, [ready]);
  const pause = useCallback(() => { audio.current?.pause(); playingRef.current = false; setPlaying(false); }, []);
  const toggle = useCallback(() => (playingRef.current ? pause() : play()), [play, pause]);
  const seekTo = useCallback((time: number) => {
    const v = Math.max(0, Math.min(SONG.duration - 0.01, time));
    if (audio.current) audio.current.currentTime = v; setT(v); draw(v); setStarted(true);
  }, [draw]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName; if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.code === 'Space') { e.preventDefault(); toggle(); }
      if (e.code === 'ArrowRight') seekTo((audio.current?.currentTime ?? 0) + 2);
      if (e.code === 'ArrowLeft') seekTo((audio.current?.currentTime ?? 0) - 2);
    };
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey);
  }, [toggle, seekTo]);

  const shotIdx = (() => { for (let i = SHOTS.length - 1; i >= 0; i--) if (t >= SHOTS[i].s) return i; return 0; })();
  const shot = SHOTS[shotIdx];
  const section = SECTIONS.find((s) => t >= s.s && t < s.e) ?? SECTIONS[SECTIONS.length - 1];
  const line = LINES.find((l) => t >= l.s - 0.1 && t <= l.e);

  return (
    <div className="w-full">
      <div ref={wrap} className="relative aspect-video w-full overflow-hidden rounded-[28px] bg-[#1b1838] shadow-[0_30px_80px_rgba(90,60,140,0.35)] ring-4 ring-white/70">
        <canvas ref={canvas} className="block h-full w-full" onClick={toggle} />
        <audio ref={audio} src={SONG.audioUrl} preload="auto" onEnded={() => { playingRef.current = false; setPlaying(false); }} />
        {!started && (
          <div className="absolute inset-0 grid place-items-center bg-gradient-to-b from-[#1b1838]/30 via-transparent to-[#1b1838]/50">
            <button onClick={play} disabled={!ready} className="candy-btn flex items-center gap-3 rounded-full px-8 py-4 text-lg font-bold text-white shadow-xl transition hover:scale-105 disabled:cursor-wait disabled:opacity-70">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-white/30">{ready ? '▶' : '…'}</span>
              {ready ? '播放 MV（带声音）' : err ? '加载失败' : '正在搭建软糖世界…'}
            </button>
          </div>
        )}
        {err && <div className="absolute inset-x-4 bottom-4 rounded-2xl bg-rose-600/90 p-3 text-sm text-white">{err}</div>}
      </div>

      <div className="mt-4 rounded-3xl bg-white/85 p-4 shadow-sm ring-1 ring-pink-100 backdrop-blur">
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={toggle} disabled={!ready} aria-label={playing ? '暂停' : '播放'} className="candy-btn grid h-11 w-11 place-items-center rounded-full text-white shadow disabled:opacity-50">{playing ? '❚❚' : '▶'}</button>
          <span className="font-mono text-sm tabular-nums text-violet-900">{fmt(t)} / {fmt(SONG.duration)}</span>
          <span className="rounded-full bg-pink-100 px-3 py-1 text-sm font-semibold text-pink-700">{shot.id} · {shot.title}</span>
          <span className="hidden rounded-full bg-violet-100 px-3 py-1 text-sm text-violet-700 sm:inline">{section.name}</span>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={() => { setHq((v) => { scaleRef.current = v ? 0.66 : 1; return !v; }); setTimeout(() => { fit(); draw(audio.current?.currentTime ?? 0); }, 0); }} className="rounded-full bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-700 ring-1 ring-violet-200 hover:bg-violet-100">{hq ? '高清' : '流畅'}</button>
            <button onClick={() => wrap.current?.requestFullscreen?.()} className="rounded-full bg-violet-50 px-3 py-1.5 text-xs font-semibold text-violet-700 ring-1 ring-violet-200 hover:bg-violet-100">全屏</button>
          </div>
        </div>
        <input type="range" min={0} max={SONG.duration} step={0.01} value={t} onChange={(e) => seekTo(Number(e.target.value))} className="mt-3 w-full accent-pink-400" aria-label="进度" />
        <div className="relative mt-2 h-9 w-full overflow-hidden rounded-xl bg-violet-50">
          {SECTIONS.map((s, i) => (
            <div key={s.name} title={s.name} className="absolute top-0 h-3" style={{ left: `${(s.s / SONG.duration) * 100}%`, width: `${((s.e - s.s) / SONG.duration) * 100}%`, background: SEC_COLORS[i % SEC_COLORS.length] }} />
          ))}
          {SHOTS.map((s, i) => (
            <button key={s.id} onClick={() => seekTo(s.s + 0.05)} title={`${s.id} ${s.title}`}
              className={`absolute bottom-0 top-3 border-l border-white/80 text-[10px] leading-6 transition hover:bg-pink-200/70 ${i === shotIdx ? 'bg-pink-300/70 text-pink-900' : 'text-violet-400'}`}
              style={{ left: `${(s.s / SONG.duration) * 100}%`, width: `${((s.e - s.s) / SONG.duration) * 100}%` }}>
              <span className="hidden lg:inline">{s.id.replace('S', '')}</span>
            </button>
          ))}
          <div className="pointer-events-none absolute bottom-0 top-0 w-0.5 bg-pink-600" style={{ left: `${(t / SONG.duration) * 100}%` }} />
        </div>
        <p className="mt-3 min-h-[1.5rem] text-sm text-violet-800/80">
          {line ? <>第 {line.i} 句「<b className="text-pink-600">{line.text}</b>」 · </> : null}{shot.desc}
        </p>
      </div>
    </div>
  );
}
