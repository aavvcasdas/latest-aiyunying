'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { LINES, SHOTS, SONG } from '@/mv/data';
import type { MvEngine } from '@/mv/engine';

interface Pre { frames: number; errors: { t: number; msg: string }[]; blanks: number[]; avgMs: number; done: boolean }
const ZONE: Record<string, string> = { room: '小卧室', park: '游乐场', hill: '黄昏山坡', sky: '星空', fest: '糖果灯会' };

export default function StoryboardThumbs() {
  const cv = useRef<HTMLCanvasElement>(null);
  const eng = useRef<MvEngine | null>(null);
  const busy = useRef(false);
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const [six, setSix] = useState<{ id: string; imgs: string[] } | null>(null);
  const [pre, setPre] = useState<Pre | null>(null);
  const [progress, setProgress] = useState(0);
  const [err, setErr] = useState('');

  useEffect(() => {
    let dead = false;
    (async () => {
      const { MvEngine } = await import('@/mv/engine');
      if (!cv.current) return;
      const e = new MvEngine(cv.current, { atlasUrl: '/mv/atlas.png', fontUrl: '/mv/kuaile.otf' });
      await e.load(); if (dead) { e.dispose(); return; }
      eng.current = e; e.resize(480, 270); busy.current = true;
      for (const s of SHOTS) {
        if (dead) return;
        const at = s.s + (s.e - s.s) * 0.58; e.render(at);
        const url = cv.current!.toDataURL('image/jpeg', 0.82);
        setThumbs((m) => ({ ...m, [s.id]: url }));
        await new Promise((r) => setTimeout(r, 0));
      }
      busy.current = false;
    })().catch((x) => setErr(String(x?.message || x)));
    return () => { dead = true; eng.current?.dispose(); eng.current = null; };
  }, []);

  const sixOf = async (id: string) => {
    const e = eng.current, c = cv.current; if (!e || !c || busy.current) return;
    busy.current = true; const s = SHOTS.find((x) => x.id === id)!; const imgs: string[] = [];
    for (let k = 0; k < 6; k++) { e.render(s.s + (s.e - s.s) * (0.04 + (k * 0.92) / 5)); imgs.push(c.toDataURL('image/jpeg', 0.8)); await new Promise((r) => setTimeout(r, 0)); }
    setSix({ id, imgs }); busy.current = false;
  };

  const precheck = async () => {
    const e = eng.current, c = cv.current; if (!e || !c || busy.current) return;
    busy.current = true; const probe = document.createElement('canvas'); probe.width = 32; probe.height = 18; const pg = probe.getContext('2d', { willReadFrequently: true })!;
    const n = Math.floor(SONG.duration * 4); const res: Pre = { frames: 0, errors: [], blanks: [], avgMs: 0, done: false }; let total = 0;
    for (let i = 0; i <= n; i++) {
      const t = Math.min(SONG.duration - 0.01, i / 4); const t0 = performance.now();
      try {
        e.render(t); total += performance.now() - t0; res.frames++;
        if (t > 0.7 && t < 71.3) {
          pg.drawImage(c, 0, 0, 32, 18); const d = pg.getImageData(0, 0, 32, 18).data; let m = 0, m2 = 0;
          for (let p = 0; p < d.length; p += 4) { const l = 0.2126 * d[p] + 0.7152 * d[p + 1] + 0.0722 * d[p + 2]; m += l; m2 += l * l; }
          const cnt = d.length / 4, sd = Math.sqrt(Math.max(0, m2 / cnt - (m / cnt) ** 2)); if (sd < 3) res.blanks.push(t);
        }
      } catch (x) { res.errors.push({ t, msg: String((x as Error)?.message || x) }); }
      if (i % 6 === 0) { setProgress(i / n); await new Promise((r) => setTimeout(r, 0)); }
    }
    res.avgMs = total / Math.max(1, res.frames); res.done = true; setPre(res); setProgress(1); busy.current = false;
  };

  return (
    <div>
      <canvas ref={cv} width={480} height={270} className="hidden" />
      {err && <p className="mb-4 rounded-2xl bg-rose-100 p-3 text-sm text-rose-700">{err}</p>}
      <div className="mb-6 flex flex-wrap items-center gap-3 rounded-3xl bg-white/85 p-4 ring-1 ring-violet-100">
        <button onClick={precheck} className="candy-btn rounded-full px-5 py-2 text-sm font-bold text-white shadow disabled:opacity-50" disabled={Object.keys(thumbs).length < SHOTS.length}>运行全片逐帧预检（每秒四帧）</button>
        <span className="text-sm text-violet-700">机器预检只证明「没坏」：报错、空帧、每帧耗时。好不好看要人看。</span>
        {progress > 0 && progress < 1 && <span className="font-mono text-sm text-pink-600">{Math.round(progress * 100)}%</span>}
        {pre?.done && (
          <span className={`rounded-full px-3 py-1 text-sm font-semibold ${pre.errors.length || pre.blanks.length ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
            {pre.frames} 帧 · 报错 {pre.errors.length} · 空帧 {pre.blanks.length} · 平均 {pre.avgMs.toFixed(1)} 毫秒/帧
          </span>
        )}
      </div>
      {pre?.errors.length ? <pre className="mb-6 max-h-40 overflow-auto rounded-2xl bg-rose-50 p-3 text-xs text-rose-700">{pre.errors.slice(0, 20).map((x) => `${x.t.toFixed(2)}s ${x.msg}`).join('\n')}</pre> : null}

      {six && (
        <div className="mb-8 rounded-3xl bg-white/90 p-4 ring-1 ring-pink-100">
          <div className="mb-3 flex items-center justify-between"><b className="text-violet-900">{six.id} 从头到尾六格</b><button onClick={() => setSix(null)} className="text-sm text-pink-600">收起</button></div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-6">{six.imgs.map((u, i) => <img key={i} src={u} alt={`${six.id} 第 ${i + 1} 格`} className="w-full rounded-xl" />)}</div>
        </div>
      )}

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {SHOTS.map((s) => (
          <article key={s.id} className="overflow-hidden rounded-3xl bg-white/90 shadow-sm ring-1 ring-violet-100 transition hover:-translate-y-0.5 hover:shadow-lg">
            <div className="relative aspect-video bg-gradient-to-br from-violet-200 via-pink-100 to-amber-100">
              {thumbs[s.id] ? <img src={thumbs[s.id]} alt={`${s.id} ${s.title}`} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-sm text-violet-500">渲染中…</div>}
              <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-0.5 text-xs font-bold text-pink-600">{s.id}</span>
              <span className="absolute right-3 top-3 rounded-full bg-violet-900/70 px-2.5 py-0.5 text-xs text-white">{ZONE[s.zone]}</span>
            </div>
            <div className="space-y-2 p-4 text-sm">
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="font-display text-lg text-violet-950">{s.title}</h3>
                <span className="shrink-0 font-mono text-xs text-violet-500">{s.s.toFixed(2)}–{s.e.toFixed(2)}s</span>
              </div>
              <p className="text-pink-600">{s.line ? `第 ${s.line} 句「${LINES[s.line - 1].text}」` : '（器乐）'}</p>
              <p className="text-violet-900/90">{s.desc}</p>
              <p className="text-xs text-violet-600"><b>角色</b> {s.cast}　<b>机位</b> {s.camera}</p>
              <p className="text-xs text-violet-600"><b>卡点</b> {s.beat}</p>
              <p className="rounded-xl bg-amber-50 p-2 text-xs text-amber-800">{s.meaning}</p>
              <div className="flex gap-2 pt-1">
                <Link href={`/?t=${s.s.toFixed(2)}`} className="rounded-full bg-pink-50 px-3 py-1 text-xs font-semibold text-pink-700 ring-1 ring-pink-200 hover:bg-pink-100">在播放器里看</Link>
                <button onClick={() => sixOf(s.id)} className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700 ring-1 ring-violet-200 hover:bg-violet-100">六格</button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
