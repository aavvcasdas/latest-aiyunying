import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

/** 审片记录：人看过 / 听过之后留下的意见（和机器预检分开记） */
export const shotReviews = pgTable('shot_reviews', {
  id: serial('id').primaryKey(),
  shotId: text('shot_id').notNull(),
  /** ok = 通过，fix = 需要修改，note = 只是备注 */
  status: text('status').notNull().default('ok'),
  /** 1 = 带着声音从头到尾看过这个镜头 */
  heard: integer('heard').notNull().default(0),
  note: text('note').notNull().default(''),
  reviewer: text('reviewer').notNull().default('审片人'),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

/** 交付记录：每次下载 zip / README 记一笔 */
export const exportLogs = pgTable('export_logs', {
  id: serial('id').primaryKey(),
  kind: text('kind').notNull(),
  bytes: integer('bytes').notNull(),
  files: integer('files').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

export type ShotReview = typeof shotReviews.$inferSelect;
export type ExportLog = typeof exportLogs.$inferSelect;
