import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createFilm, DUR, H, LINES, SHOTS, W } from "./mv/engine";

const MP4 = "bad-girl-3d.mp4";
const MP4_NAME = "坏女孩_3D复刻版_鲸鱼娘.mp4";
const SRT = "bad-girl.srt";

type Line = { start: number; end: number; text: string };
type Shot = { start: number; end: number; name: string; set: string };
const lines = LINES as Line[];
const shotList = SHOTS as Shot[];
const SET_NAME: Record<string, string> = {
  river: "黄昏河堤", rain: "雨夜街口", neon: "霓虹大街", nameless: "无名大街", spring: "春日小镇", summer: "夏日小镇",
  autumn: "秋日小镇", winter: "冬日小镇", room: "深夜房间", bar: "夜光酒吧", bridge: "烟花长桥", ferris: "摩天轮广场",
};
const CAST: [string, string, string][] = [
  ["鲸鱼娘", "主角 · 坏女孩", "从单纯的她，到酒吧里画着黑眼线的她"],
  ["Claude", "配角 · “我”", "放手的人，后来一直在看、在想、在追"],
  ["Zai", "陌生的肩", "酒吧里被她靠着的黑裙女孩"],
  ["Gemini / 千问 / Kimi", "舞池", "跟着鼓点跳舞的人群"],
  ["豆包", "DJ 台", "站在酒吧打碟台后"],
  ["GPT 龙娘", "吧台客人", "最后一段副歌出现在吧台边"],
];
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const filmRef = useRef<{ render: (g: CanvasRenderingContext2D, t: number, o: object) => unknown } | null>(null);
  const orbit = useRef({ yaw: 0, pitch: 0, zoom: 1 });
  const drag = useRef<{ x: number; y: number } | null>(null);
  const opts = useRef({ subs: true, free: false });
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState("");
  const [playing, setPlaying] = useState(false);
  const [now, setNow] = useState(0);
  const [subs, setSubs] = useState(true);
  const [free, setFree] = useState(false);
  const [copied, setCopied] = useState(false);
  const fullUrl = useMemo(() => new URL(MP4, window.location.href).href, []);

  // 载入图集与字体，建好影片
  useEffect(() => {
    let dead = false;
    const img = new Image();
    const font = new FontFace("BG", "url(./ZCOOL.ttf)");
    Promise.all([
      new Promise<void>((res, rej) => { img.onload = () => res(); img.onerror = () => rej(new Error("角色图集 atlas.png 加载失败")); img.src = "./atlas.png"; }),
      font.load().then((f) => { document.fonts.add(f); }).catch(() => undefined),
    ]).then(() => {
      if (dead) return;
      filmRef.current = createFilm({ atlas: img, makeCanvas: (w: number, h: number) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; } });
      setReady(true);
    }).catch((e: Error) => setErr(e.message));
    return () => { dead = true; };
  }, []);

  // 实时渲染循环：时间取自音频，机位叠加观众拖拽的环绕偏移
  useEffect(() => {
    if (!ready) return;
    let raf = 0, n = 0;
    const g = canvasRef.current!.getContext("2d")!;
    const loop = () => {
      const a = audioRef.current, t = a ? Math.min(a.currentTime, DUR - 0.05) : 0, o = orbit.current;
      if (!opts.current.free && !drag.current) { o.yaw *= 0.9; o.pitch *= 0.9; o.zoom += (1 - o.zoom) * 0.1; }
      filmRef.current!.render(g, t, { orbit: o, subtitles: opts.current.subs });
      if (n++ % 6 === 0) setNow(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [ready]);

  useEffect(() => { opts.current = { subs, free }; }, [subs, free]);

  useEffect(() => {
    const c = canvasRef.current; if (!c) return;
    const wheel = (e: WheelEvent) => { e.preventDefault(); orbit.current.zoom = Math.max(0.45, Math.min(1.9, orbit.current.zoom * Math.exp(e.deltaY * 0.0012))); };
    c.addEventListener("wheel", wheel, { passive: false });
    return () => c.removeEventListener("wheel", wheel);
  }, [ready]);

  const toggle = useCallback(() => { const a = audioRef.current; if (!a) return; if (a.paused) void a.play(); else a.pause(); }, []);
  const seek = useCallback((t: number, play = true) => { const a = audioRef.current; if (!a) return; a.currentTime = Math.max(0, Math.min(DUR - 0.1, t)); if (play) void a.play(); }, []);
  const copy = async () => { try { await navigator.clipboard.writeText(fullUrl); setCopied(true); window.setTimeout(() => setCopied(false), 1800); } catch { window.prompt("复制下载链接", fullUrl); } };

  const active = useMemo(() => { let i = -1; lines.forEach((l, k) => { if (now >= l.start - 0.2) i = k; }); return i; }, [now]);
  const curShot = useMemo(() => shotList.find((s) => now >= s.start && now < s.end), [now]);

  return (
    <div className="min-h-screen bg-[#0d0716] text-[#f6eefc]">
      <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-5">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-pink-500 to-violet-500 text-lg font-black">坏</span>
          <div>
            <div className="text-sm font-semibold tracking-wide">坏女孩 · 3D 复刻 MV</div>
            <div className="text-[11px] text-white/45">鲸鱼娘 × Claude · 低多边形 3D 场景 + 像素角色纸片人</div>
          </div>
        </div>
        <a href={`./${MP4}`} download={MP4_NAME} className="rounded-full bg-gradient-to-r from-pink-500 to-fuchsia-500 px-5 py-2 text-sm font-bold shadow-lg shadow-pink-500/30 transition hover:brightness-110">⬇ 导出 MP4</a>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-20">
        <section className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-black shadow-2xl shadow-fuchsia-900/30">
              <div className="relative">
                <canvas
                  ref={canvasRef}
                  width={W}
                  height={H}
                  className="block aspect-video w-full cursor-grab touch-none select-none active:cursor-grabbing"
                  onPointerDown={(e) => { drag.current = { x: e.clientX, y: e.clientY }; e.currentTarget.setPointerCapture(e.pointerId); }}
                  onPointerMove={(e) => { const d = drag.current; if (!d) return; orbit.current.yaw -= (e.clientX - d.x) * 0.006; orbit.current.pitch = Math.max(-0.5, Math.min(1.1, orbit.current.pitch + (e.clientY - d.y) * 0.004)); drag.current = { x: e.clientX, y: e.clientY }; }}
                  onPointerUp={() => { drag.current = null; }}
                  onPointerCancel={() => { drag.current = null; }}
                  onDoubleClick={() => { orbit.current = { yaw: 0, pitch: 0, zoom: 1 }; }}
                />
                {!ready && (
                  <div className="absolute inset-0 grid place-items-center bg-black/70 text-sm text-white/70">{err || "正在载入 3D 场景与角色…"}</div>
                )}
                {ready && !playing && now < 0.05 && (
                  <button onClick={toggle} className="absolute inset-0 grid place-items-center bg-black/35 transition hover:bg-black/20" aria-label="播放">
                    <span className="grid h-20 w-20 place-items-center rounded-full bg-pink-500 text-3xl shadow-xl shadow-pink-500/40">▶</span>
                  </button>
                )}
                <div className="pointer-events-none absolute left-3 top-3 rounded-md bg-black/55 px-2 py-1 text-[11px] text-white/80">
                  实时 3D · 拖拽旋转机位 · 滚轮缩放 · 双击复位
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 border-t border-white/10 bg-[#150c22] px-4 py-3">
                <button onClick={toggle} disabled={!ready} className="grid h-9 w-9 place-items-center rounded-full bg-pink-500 text-sm font-bold disabled:opacity-40" aria-label={playing ? "暂停" : "播放"}>{playing ? "❚❚" : "▶"}</button>
                <span className="w-[86px] font-mono text-xs text-white/70">{fmt(now)} / {fmt(DUR)}</span>
                <input type="range" min={0} max={DUR} step={0.05} value={now} onChange={(e) => seek(Number(e.target.value), false)} className="h-1 min-w-[140px] flex-1 accent-pink-500" aria-label="进度" />
                <label className="flex cursor-pointer items-center gap-1.5 text-xs text-white/75"><input type="checkbox" checked={subs} onChange={(e) => setSubs(e.target.checked)} className="accent-pink-500" />歌词字幕</label>
                <label className="flex cursor-pointer items-center gap-1.5 text-xs text-white/75"><input type="checkbox" checked={free} onChange={(e) => setFree(e.target.checked)} className="accent-pink-500" />锁定我的视角</label>
              </div>
            </div>
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 px-1 text-xs text-white/50">
              <span>当前镜头：<b className="text-white/85">{curShot ? `${curShot.name} · ${SET_NAME[curShot.set] || curShot.set}` : "—"}</b></span>
              <span>不勾选“锁定我的视角”时，松手后机位会回到导演机位</span>
            </div>
            <audio ref={audioRef} src="./song.mp3" preload="auto" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)} />

            <div className="mt-5 rounded-xl border border-pink-400/20 bg-white/[0.04] p-4">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-pink-300">完整下载链接</div>
              <div className="mt-2 break-all rounded-lg bg-black/40 px-3 py-2 font-mono text-xs text-white/80">{fullUrl}</div>
              <div className="mt-3 flex flex-wrap gap-2">
                <a href={`./${MP4}`} download={MP4_NAME} className="rounded-lg bg-pink-500 px-4 py-2 text-sm font-bold text-white hover:bg-pink-400">⬇ 下载 MP4（1280×720 · 3:15）</a>
                <a href={`./${SRT}`} download="坏女孩_歌词字幕.srt" className="rounded-lg border border-white/15 px-4 py-2 text-sm hover:bg-white/10">下载字幕 SRT</a>
                <button onClick={copy} className="rounded-lg border border-white/15 px-4 py-2 text-sm hover:bg-white/10">{copied ? "已复制 ✓" : "复制链接"}</button>
              </div>
              <p className="mt-3 text-xs leading-5 text-white/45">
                MP4 与上面的实时画面由同一套 3D 引擎逐帧渲染（导演机位、字幕烧录在画面里），音轨为原曲去掉 20 秒前奏后的部分。链接按当前页面地址自动生成；{MP4}、song.mp3、atlas.png、ZCOOL.ttf 需与页面放在同一目录。
              </p>
            </div>
          </div>

          <aside className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-bold">歌词字幕（点击跳转）</h2>
              <span className="text-[11px] text-white/40">{lines.length} 句</span>
            </div>
            <ol className="max-h-[640px] space-y-1 overflow-y-auto pr-1">
              {lines.map((l, i) => (
                <li key={i}>
                  <button onClick={() => seek(l.start)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-1.5 text-left text-sm transition ${i === active ? "bg-pink-500/25 text-white" : "text-white/60 hover:bg-white/5"}`}>
                    <span className="w-10 shrink-0 font-mono text-[11px] text-pink-300/80">{fmt(l.start)}</span>
                    {l.text}
                  </button>
                </li>
              ))}
            </ol>
          </aside>
        </section>

        <section className="mt-10 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <h2 className="text-base font-bold">这一版怎么做的</h2>
            <ul className="mt-3 space-y-2 text-sm leading-6 text-white/70">
              <li>• <b className="text-white">3D 背景</b>：按项目通用模板的画面语法——低多边形卡通 3D 世界里放像素角色纸片人。12 套场景都是真实的三维几何体，镜头有推、摇、跟拍和视差。</li>
              <li>• <b className="text-white">互动</b>：上面的画面是实时渲染的，可以边播边拖拽环绕、缩放、关字幕、点歌词或镜头跳转。</li>
              <li>• <b className="text-white">跟着歌词走的风格</b>：不沿用参考视频的像素 RPG 界面，每句歌词一个镜头、一个意象——红线松开、掉在地上的爱心、走进长街消失、“来电 0”的手机、黑色眼线特写、改变清单、裂开的玻璃墙。</li>
              <li>• <b className="text-white">走路修复</b>：使用模板图集里的 8 帧步态，帧号由“实际走过的距离”决定，脚步与位移同步不打滑；朝向按屏幕上的移动方向自动翻转。</li>
              <li>• <b className="text-white">卡点</b>：全曲每句 3.75 秒（6 拍），镜头在每句歌词前两帧切换；舞池地砖、灯束、烟花、人物跳动取自原曲低频鼓点。</li>
              <li>• <b className="text-white">字幕</b>：模板同款金边字幕条，逐字变黄；另附 SRT 文件。</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <h2 className="text-base font-bold">角色分配</h2>
            <table className="mt-3 w-full text-left text-sm">
              <tbody>
                {CAST.map(([who, role, note]) => (
                  <tr key={who} className="border-t border-white/10 align-top">
                    <td className="py-2 pr-3 font-semibold text-pink-200">{who}</td>
                    <td className="py-2 pr-3 text-white/80">{role}</td>
                    <td className="py-2 text-white/50">{note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-3 text-xs leading-5 text-white/45">角色全部取自项目图集（《童话镇》同一套像素立绘与步态），不改脸、不改服饰。</p>
          </div>
        </section>

        <section className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
          <h2 className="text-base font-bold">分镜（{shotList.length} 个镜头，点击跳转）</h2>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {shotList.map((s, i) => (
              <button key={i} onClick={() => seek(s.start)} className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition ${curShot === s ? "border-pink-400/60 bg-pink-500/10" : "border-white/10 bg-black/20 hover:border-pink-400/40"}`}>
                <span className="w-9 shrink-0 font-mono text-[11px] text-pink-300">{fmt(s.start)}</span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold">{s.name}</span>
                  <span className="block text-[11px] text-white/45">{SET_NAME[s.set] || s.set}</span>
                </span>
              </button>
            ))}
          </div>
        </section>

        <p className="mt-8 rounded-xl border border-amber-300/20 bg-amber-300/5 p-4 text-xs leading-6 text-amber-100/80">
          说明：模板原本用 three.js 在浏览器里截图出片，这次的制作环境跑不了无头浏览器的 WebGL，所以我按模板的画面风格写了一个轻量 3D 渲染器，网页预览和 MP4 导出共用它；没有直接调用模板的 three.js 引擎。
          歌词时间轴是按原曲鼓点网格与参考视频的镜头切点推算的（没有逐字对齐工具），个别句子可能有零点几秒偏差；逐字变色在每句内均匀铺开。
          参考视频第二遍主歌重复了第一遍的歌词，这里字幕照此重复。角色立绘没有多表情，情绪用姿态、泪滴、爱心等特效表现。
        </p>
      </main>
    </div>
  );
}
