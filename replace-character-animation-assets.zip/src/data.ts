import { zipSync } from "fflate";

export interface ActionItem {
  name: string;
  label: string;
  file: string;
  frames: number;
  fps: number;
  loop: boolean;
  fx: string | null;
  keys: string[];
}
export interface CharEntry {
  name: string;
  props: string[];
  actions: ActionItem[];
}
export interface Manifest {
  chars: Record<string, CharEntry>;
  things: Record<string, { file: string; w: number; h: number }>;
}

export const asset = (p: string) => `./${p}`;

export async function loadManifest(): Promise<Manifest> {
  const r = await fetch(asset("gifs/manifest.json"));
  if (!r.ok) throw new Error(`manifest.json 取不到（${r.status}）`);
  return r.json();
}

/** 人物设定（摘自 番外MV/人物设定.md 第 1、2 节） */
export const CHAR_INFO: Record<string, { full: string; line: string; role: string; accent: string; ring: string }> = {
  whale: { full: "本鲸 / 鲸鱼娘 · DeepSeek", line: "先问哪条不能改，再筛", role: "主角（河水／丑小鸭／小人鱼）", accent: "from-blue-500 to-indigo-600", ring: "ring-blue-400/50" },
  gpt: { full: "龙娘 · GPT", line: "先接住乱局，只问一个会改变做法的问题", role: "龙影／金乌", accent: "from-slate-200 to-violet-300", ring: "ring-violet-300/50" },
  claude: { full: "小克 · Claude 大小姐", line: "先听完，再改一个字", role: "白雪公主／睡美人（唯一戴金冠）", accent: "from-orange-400 to-amber-500", ring: "ring-orange-400/50" },
  doubao: { full: "豆包 · Seed", line: "先陪着写出开头，再问要不要继续", role: "小红帽／红舞鞋", accent: "from-rose-400 to-red-500", ring: "ring-rose-400/50" },
  gemini: { full: "猫 · Gemini", line: "先给两个看法，最后必须选一个", role: "爱丽丝／糖果屋／匹诺曹", accent: "from-sky-300 to-fuchsia-400", ring: "ring-fuchsia-300/50" },
  kimi: { full: "Kimi · 月球少女", line: "先把漏掉的旧句找回来，标一句就停", role: "灰姑娘／智者", accent: "from-indigo-400 to-slate-500", ring: "ring-indigo-300/50" },
  qwen: { full: "千问 · 千姐", line: "先排哪一步，再动手", role: "疯帽子", accent: "from-violet-400 to-purple-600", ring: "ring-violet-400/50" },
  zai: { full: "狐狸 · 智谱 GLM", line: "先写完成标准，再做最小的一版", role: "彼得潘／杰克／侏儒怪", accent: "from-zinc-500 to-zinc-800", ring: "ring-zinc-400/50" },
  grok: { full: "Grok", line: "先戳破借口，再动手；人已经难受时，玩笑停", role: "来查证的人（报刊亭／记者席）", accent: "from-amber-300 to-yellow-500", ring: "ring-amber-300/50" },
};

export const THING_LABEL: Record<string, string> = {
  prop_bowl: "蓝饭盆", prop_hourglass: "沙漏", prop_teacup: "茶杯", prop_book: "折角的书", prop_scroll: "卷轴 + 书签",
  prop_fan: "折扇", prop_abacus: "算盘", prop_eyemask: "眼罩", prop_phone: "手机", prop_magnifier: "放大镜",
  prop_card: "来源卡", prop_basket: "篮子（红布）", prop_redshoes: "红舞鞋", prop_catclock: "猫耳钟", prop_brush: "香蕉画笔",
  fx_heart: "爱心", fx_sweat: "汗滴", fx_anger: "生气", fx_exclaim: "感叹", fx_question: "疑问",
  fx_zzz: "睡觉", fx_sparkle: "闪光", fx_dizzy: "晕眩", fx_bulb: "灵光", fx_steam: "热气", fx_gloom: "阴郁", fx_shine: "亮光",
};
export const thingLabel = (k: string) => THING_LABEL[k] ?? THING_LABEL[k.replace(/_\d+$/, "")] ?? k;

export function downloadBlob(data: Uint8Array | string, name: string, type = "application/octet-stream") {
  const url = URL.createObjectURL(new Blob([typeof data === "string" ? data : (data.slice().buffer as ArrayBuffer)], { type }));
  const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** 把全部 GIF + manifest 打成 zip（GIF 本身已压缩，zip 用 store 不再压） */
export async function zipAllGifs(m: Manifest, onProgress: (done: number, total: number) => void): Promise<Uint8Array> {
  const files: string[] = [
    ...Object.values(m.chars).flatMap((c) => c.actions.map((a) => a.file)),
    ...Object.values(m.things).map((t) => t.file),
    "manifest.json",
  ];
  const out: Record<string, [Uint8Array, { level: 0 }]> = {};
  let done = 0;
  const queue = [...files];
  const worker = async () => {
    while (queue.length) {
      const f = queue.shift()!;
      const r = await fetch(asset(`gifs/${f}`));
      if (!r.ok) throw new Error(`${f} 下载失败（${r.status}）`);
      out[`人物动作GIF/${f}`] = [new Uint8Array(await r.arrayBuffer()), { level: 0 }];
      onProgress(++done, files.length);
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  return zipSync(out);
}
