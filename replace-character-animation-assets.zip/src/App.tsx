import { useEffect, useMemo, useState } from "react";
import { ActionCard } from "./components/ActionCard";
import { Compare } from "./components/Compare";
import { DocViewer, MD_URL } from "./components/DocViewer";
import { CHAR_INFO, asset, downloadBlob, loadManifest, thingLabel, zipAllGifs, type Manifest } from "./data";

const ORDER = ["whale", "gpt", "claude", "doubao", "gemini", "kimi", "qwen", "zai", "grok"];
const PATCH_URL = asset("dl/latest-aiyunying-motion-fix.patch");

function Stat({ n, label }: { n: string | number; label: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur">
      <div className="text-2xl font-bold text-white">{n}</div>
      <div className="text-xs text-slate-400">{label}</div>
    </div>
  );
}

export default function App() {
  const [m, setM] = useState<Manifest | null>(null);
  const [err, setErr] = useState("");
  const [cur, setCur] = useState("whale");
  const [bg, setBg] = useState<"dark" | "light" | "check">("check");
  const [zip, setZip] = useState<{ busy: boolean; done: number; total: number; msg?: string }>({ busy: false, done: 0, total: 0 });
  const [tab, setTab] = useState<"actions" | "things" | "compare" | "doc">("actions");

  useEffect(() => { loadManifest().then(setM).catch((e) => setErr(e.message)); }, []);

  const stats = useMemo(() => {
    if (!m) return null;
    const acts = Object.values(m.chars).flatMap((c) => c.actions);
    const things = Object.keys(m.things);
    return {
      actions: acts.length,
      cells: acts.reduce((n, a) => n + a.frames, 0),
      props: things.filter((k) => k.startsWith("prop_")).length,
      fx: things.filter((k) => k.startsWith("fx_")).length,
    };
  }, [m]);

  const doZip = async () => {
    if (!m || zip.busy) return;
    setZip({ busy: true, done: 0, total: 1 });
    try {
      const data = await zipAllGifs(m, (done, total) => setZip({ busy: true, done, total }));
      downloadBlob(new Uint8Array(data), "人物动作GIF.zip", "application/zip");
      setZip({ busy: false, done: 0, total: 0, msg: "已打包下载" });
    } catch (e) {
      setZip({ busy: false, done: 0, total: 0, msg: `打包失败：${(e as Error).message}` });
    }
  };

  const c = m?.chars[cur];
  const info = CHAR_INFO[cur];

  return (
    <div className="min-h-screen bg-[#0b1020] text-slate-200">
      {/* Hero */}
      <header className="relative overflow-hidden border-b border-white/10">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(56,189,248,0.18),transparent_55%),radial-gradient(ellipse_at_bottom_right,rgba(139,92,246,0.18),transparent_50%)]" />
        <div className="relative mx-auto max-w-7xl px-5 py-10 md:py-14">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-3 py-1 text-xs text-cyan-200">
                latest-aiyunying · arena/25fbb036 · 补丁基于提交 2779ffd
              </p>
              <h1 className="text-3xl font-black tracking-tight text-white md:text-5xl">
                人物动作工坊
                <span className="block bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">九位像素角色 · 新动作 GIF 与补丁</span>
              </h1>
              <p className="mt-4 text-sm leading-relaxed text-slate-400 md:text-base">
                原来每人只有 4–8 格造型，大多是站着不动。新的动作全部由<b className="text-slate-200">原有像素格派生</b>（Scale2x 放大 → 反向形变 → 最近邻），
                每个像素都是原调色板里的颜色，<b className="text-slate-200">没有新增生图、不换画风</b>，守住仓库 AGENTS.md 的画面红线。
                顺手修了 Grok 的脏格和龙娘施法的坏帧。
              </p>
            </div>
            {stats && (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:w-[30rem]">
                <Stat n={stats.actions} label="个派生动作" />
                <Stat n={stats.cells} label="格新动作帧" />
                <Stat n={stats.props} label="件像素道具" />
                <Stat n={stats.fx} label="格表情贴" />
              </div>
            )}
          </div>

          {/* Downloads */}
          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <a href={PATCH_URL} download="latest-aiyunying-动作修复.patch" className="group rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 p-4 text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:brightness-110">
              <div className="text-sm font-bold">下载补丁 .patch</div>
              <div className="text-xs opacity-80">git apply 即可 · 含图集 PNG（6.8 MB）</div>
            </a>
            <button onClick={doZip} disabled={!m || zip.busy} className="rounded-2xl bg-gradient-to-br from-violet-400 to-fuchsia-600 p-4 text-left text-slate-950 shadow-lg shadow-violet-500/20 transition hover:brightness-110 disabled:opacity-70">
              <div className="text-sm font-bold">{zip.busy ? `打包中 ${zip.done}/${zip.total}` : "下载全部 GIF（zip）"}</div>
              <div className="text-xs opacity-80">{zip.msg ?? "82 个动作 + 36 张道具 / 表情贴 + manifest"}</div>
              {zip.busy && <div className="mt-2 h-1 overflow-hidden rounded bg-black/20"><div className="h-full bg-slate-950/70" style={{ width: `${(zip.done / Math.max(1, zip.total)) * 100}%` }} /></div>}
            </button>
            <a href={MD_URL} download="人物动作替换.md" className="rounded-2xl border border-white/15 bg-white/5 p-4 transition hover:bg-white/10">
              <div className="text-sm font-bold text-white">下载替换说明 .md</div>
              <div className="text-xs text-slate-400">下载 GIF / 打补丁 / 重烘图集 / 镜头用法</div>
            </a>
            <div className="flex gap-2">
              <a href={asset("dl/cast_atlas.png")} download className="flex-1 rounded-2xl border border-white/15 bg-white/5 p-4 transition hover:bg-white/10">
                <div className="text-sm font-bold text-white">新图集 PNG</div>
                <div className="text-xs text-slate-400">2048×3439</div>
              </a>
              <div className="flex flex-col gap-2">
                <a href={asset("dl/cast_atlas.json")} download className="rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10">atlas.json</a>
                <a href={asset("dl/cast_actions.json")} download className="rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10">actions.json</a>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <nav className="sticky top-0 z-20 border-b border-white/10 bg-[#0b1020]/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-5 py-2">
          {([["actions", "人物动作"], ["things", "道具与表情贴"], ["compare", "修复前后对比"], ["doc", "替换说明（md）"]] as const).map(([k, t]) => (
            <button key={k} onClick={() => setTab(k)} className={`whitespace-nowrap rounded-xl px-4 py-2 text-sm font-medium transition ${tab === k ? "bg-white text-slate-900" : "text-slate-400 hover:bg-white/5 hover:text-white"}`}>
              {t}
            </button>
          ))}
        </div>
      </nav>

      <main className="mx-auto max-w-7xl px-5 py-8">
        {err && <div className="rounded-xl border border-rose-400/40 bg-rose-500/10 p-4 text-rose-200">载入失败：{err}</div>}
        {!m && !err && <div className="py-20 text-center text-slate-500">载入 GIF 清单…</div>}

        {m && tab === "actions" && c && (
          <section>
            <div className="mb-6 flex flex-wrap gap-2">
              {ORDER.map((id) => (
                <button key={id} onClick={() => setCur(id)} className={`flex items-center gap-2 rounded-2xl border px-3 py-2 text-sm transition ${cur === id ? "border-cyan-300/60 bg-cyan-300/10 text-white" : "border-white/10 bg-white/5 text-slate-400 hover:text-white"}`}>
                  <span className={`h-3 w-3 rounded-full bg-gradient-to-br ${CHAR_INFO[id].accent}`} />
                  {m.chars[id].name}
                  <span className="text-xs text-slate-500">{m.chars[id].actions.length}</span>
                </button>
              ))}
            </div>

            <div className={`mb-6 flex flex-col gap-4 rounded-3xl border border-white/10 bg-gradient-to-br from-slate-800/80 to-slate-900/80 p-5 ring-1 ${info.ring} md:flex-row md:items-center md:justify-between`}>
              <div>
                <div className="flex items-center gap-3">
                  <h2 className="text-2xl font-bold text-white">{info.full}</h2>
                  <code className="rounded bg-slate-950/60 px-2 py-0.5 text-xs text-cyan-200">k.actor('{cur}')</code>
                </div>
                <p className="mt-1 text-sm text-slate-300">「{info.line}」</p>
                <p className="mt-1 text-xs text-slate-500">《童话镇》位置：{info.role}</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs text-slate-500">推荐道具</span>
                {c.props.map((p) => (
                  <figure key={p} className="flex flex-col items-center rounded-xl bg-slate-950/50 px-2 py-1">
                    <img src={asset(`gifs/${m.things[p].file}`)} alt={p} className="pixelated h-10 object-contain" />
                    <figcaption className="text-[10px] text-slate-400">{thingLabel(p)}</figcaption>
                  </figure>
                ))}
                <div className="ml-2 flex overflow-hidden rounded-lg border border-white/10 text-xs">
                  {([["check", "棋盘"], ["dark", "深"], ["light", "浅"]] as const).map(([k, t]) => (
                    <button key={k} onClick={() => setBg(k)} className={`px-2 py-1 ${bg === k ? "bg-white/15 text-white" : "text-slate-400"}`}>{t}</button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {c.actions.map((a) => <ActionCard key={a.name} id={cur} a={a} bg={bg} />)}
            </div>
            <p className="mt-6 text-xs text-slate-500">
              GIF 放大 3 倍、叠了推荐的表情贴，只供预览；片子里用的是图集 cast_atlas.png 里的格子（act_{cur}_动作名_帧号），表情贴由 .emote() 单独叠。
            </p>
          </section>
        )}

        {m && tab === "things" && (
          <section className="space-y-8">
            {(["prop_", "fx_"] as const).map((pre) => (
              <div key={pre}>
                <h3 className="mb-1 text-xl font-bold text-white">{pre === "prop_" ? "像素道具（k.thing('prop_…')）" : "表情贴（actor.emote('fx_…', T)）"}</h3>
                <p className="mb-4 text-sm text-slate-400">
                  {pre === "prop_" ? "按人物设定.md 每张卡的「道具」一格画：几何笔画 + 自动墨线，颜色只取 px.js 调色板。不画假手——要「拿着」就摆在手边。" : "多格的（睡觉、闪光、晕眩、热气）由 emote() 按时间自动轮播。"}
                </p>
                <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-8">
                  {Object.entries(m.things).filter(([k]) => k.startsWith(pre)).map(([k, t]) => (
                    <a key={k} href={asset(`gifs/${t.file}`)} download={t.file} className="group flex flex-col items-center gap-2 rounded-2xl border border-white/10 bg-slate-800/50 p-3 transition hover:border-cyan-300/40">
                      <div className="checker flex h-20 w-full items-center justify-center rounded-xl">
                        <img src={asset(`gifs/${t.file}`)} alt={k} className="pixelated max-h-16 object-contain" />
                      </div>
                      <div className="text-xs font-medium text-white">{thingLabel(k)}</div>
                      <div className="font-mono text-[10px] text-slate-500">{k} · {t.w}×{t.h}</div>
                    </a>
                  ))}
                </div>
              </div>
            ))}
          </section>
        )}

        {tab === "compare" && (
          <section>
            <h3 className="mb-1 text-xl font-bold text-white">修复前后</h3>
            <p className="mb-5 text-sm text-slate-400">左边取自原提交 2779ffd 的精灵数据，右边是打完补丁后的结果。</p>
            <Compare />
          </section>
        )}

        {tab === "doc" && (
          <section className="rounded-3xl border border-white/10 bg-slate-900/60 p-6 md:p-10">
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
              <span className="text-sm text-slate-400">仓库根目录 / 人物动作替换.md（补丁里已带）</span>
              <a href={MD_URL} download="人物动作替换.md" className="rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-900">下载 .md</a>
            </div>
            <DocViewer />
          </section>
        )}
      </main>

      <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500">
        机器查过：npm test 52 项全过 · typecheck · atlas:check · 重跑烘焙零差异。没有人在成片里整片看过这些动作。
      </footer>
    </div>
  );
}
