import { useState } from "react";
import { asset, thingLabel, type ActionItem } from "../data";

export function ActionCard({ id, a, bg }: { id: string; a: ActionItem; bg: "dark" | "light" | "check" }) {
  const [copied, setCopied] = useState(false);
  const code = id === "gpt" && a.name === "float" ? `.idle(T)  // 或 .act('float', T)` : a.name === "idle" ? `.idle(T)` : `.act('${a.name}', T${a.loop ? "" : ", t0"})`;
  const bgCls = bg === "dark" ? "bg-slate-900" : bg === "light" ? "bg-slate-100" : "checker";
  return (
    <div className="group flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-slate-800/60 shadow-lg shadow-black/20 transition hover:-translate-y-0.5 hover:border-cyan-300/40">
      <div className={`relative flex h-52 items-end justify-center ${bgCls}`}>
        <img src={asset(`gifs/${a.file}`)} alt={`${id} ${a.label}`} loading="lazy" className="pixelated max-h-48 max-w-full object-contain" />
        <span className={`absolute left-2 top-2 rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${a.loop ? "bg-emerald-500/90 text-emerald-950" : "bg-amber-400/90 text-amber-950"}`}>
          {a.loop ? "循环" : "播完定格"}
        </span>
        {a.fx && (
          <span className="absolute right-2 top-2 rounded-md bg-slate-950/70 px-1.5 py-0.5 text-[10px] text-cyan-200">
            表情贴 · {thingLabel(a.fx)}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-3">
        <div className="flex items-baseline justify-between gap-2">
          <h4 className="font-semibold text-white">{a.label}</h4>
          <span className="font-mono text-xs text-slate-400">{a.name}</span>
        </div>
        <p className="text-xs text-slate-400">
          {a.frames} 格 · {a.fps} fps · {(a.frames / a.fps).toFixed(2)} 秒/轮
        </p>
        <button
          onClick={() => { navigator.clipboard?.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1200); }}
          className="truncate rounded-lg bg-slate-950/70 px-2 py-1.5 text-left font-mono text-[11px] text-cyan-200 hover:bg-slate-950"
          title="复制调用代码"
        >
          {copied ? "已复制 ✓" : code}
        </button>
        <a href={asset(`gifs/${a.file}`)} download={a.file} className="mt-auto rounded-lg border border-cyan-300/30 py-1.5 text-center text-xs font-medium text-cyan-200 transition hover:bg-cyan-300/10">
          下载 GIF
        </a>
      </div>
    </div>
  );
}
