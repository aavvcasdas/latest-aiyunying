import { asset } from "../data";

const PAIRS = [
  { title: "Grok 正面 + 眨眼", before: "compare/old_grok_front.gif", after: "compare/new_grok_front.gif", note: "头发里的黑斑收回金发；闭眼格脸边那块没换色的淡紫清掉（bake_grok.mjs 第 5 步）" },
  { title: "Grok 走路", before: "compare/old_grok_walk.gif", after: "compare/new_grok_walk.gif", note: "八格步态同一套清理，发丝里的黑块明显变少" },
  { title: "本鲸待机", before: "compare/old_whale_front.gif", after: "gifs/whale_idle.gif", note: "front(T) 只会眨眼、整个人钉在原地 → idle(T) 八格呼吸，头和躯干一起起伏" },
  { title: "龙娘施法", before: "compare/old_gpt_cast.gif", after: "gifs/gpt_cast.gif", note: "原图 cast1 的小腿是坏的（白色硬块），来回硬切很扎眼 → 只用 cast0，加起伏与前倾" },
];

export function Compare() {
  return (
    <div className="grid gap-5 md:grid-cols-2">
      {PAIRS.map((p) => (
        <div key={p.title} className="rounded-2xl border border-white/10 bg-slate-800/50 p-4">
          <h4 className="mb-3 font-semibold text-white">{p.title}</h4>
          <div className="grid grid-cols-2 gap-3">
            {[["修复前", p.before, "text-rose-300 border-rose-400/30"], ["修复后", p.after, "text-emerald-300 border-emerald-400/30"]].map(([t, src, c]) => (
              <figure key={t} className={`flex flex-col items-center rounded-xl border ${c.split(" ").slice(1).join(" ")} checker p-2`}>
                <img src={asset(src)} alt={`${p.title} ${t}`} loading="lazy" className="pixelated h-44 object-contain" />
                <figcaption className={`mt-1 text-xs font-semibold ${c.split(" ")[0]}`}>{t}</figcaption>
              </figure>
            ))}
          </div>
          <p className="mt-3 text-xs leading-relaxed text-slate-400">{p.note}</p>
        </div>
      ))}
    </div>
  );
}
