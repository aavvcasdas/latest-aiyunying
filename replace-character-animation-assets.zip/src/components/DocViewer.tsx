import { useEffect, useState } from "react";
import { marked } from "marked";
import { asset } from "../data";

export const MD_URL = asset(`dl/${encodeURIComponent("人物动作替换.md")}`);

export function DocViewer() {
  const [html, setHtml] = useState<string>("");
  const [err, setErr] = useState("");
  useEffect(() => {
    fetch(MD_URL)
      .then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.text(); })
      .then((t) => setHtml(marked.parse(t, { async: false }) as string))
      .catch((e) => setErr(`读取失败：${e.message}`));
  }, []);
  if (err) return <p className="text-rose-300">{err}</p>;
  return <article className="md max-w-none" dangerouslySetInnerHTML={{ __html: html || "<p>加载中…</p>" }} />;
}
