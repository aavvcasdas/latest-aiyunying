// 像素角色 / 道具 / 特效的取帧与绘制。坐标表来自项目图集（atlasData.ts，原样拷贝，不手改）。
import atlasUrl from "../assets/atlas.png";
import genUrl from "../assets/gen_props.png";
import { RECTS, ACTIONS, THINGS } from "./atlasData";
import genJson from "../assets/gen_props.json";

export type Char = "whale" | "claude" | "gpt" | "gemini" | "kimi" | "qwen" | "zai" | "doubao";

const atlas = new Image();
atlas.src = atlasUrl;
const gen = new Image();
gen.src = genUrl;
const GEN = (genJson as unknown as { rects: Record<string, [number, number, number, number]> }).rects;

export function spritesReady(): Promise<void> {
  const one = (im: HTMLImageElement) =>
    im.complete && im.naturalWidth ? Promise.resolve() : new Promise<void>((r) => { im.onload = () => r(); im.onerror = () => r(); });
  return Promise.all([one(atlas), one(gen)]).then(() => undefined);
}

type DrawOpt = { flip?: boolean; alpha?: number; rot?: number; anchor?: "foot" | "center"; sx?: number; sy?: number };

/** 画单帧：x 为水平中心，y 默认为脚底（anchor=foot）。 */
export function frame(ctx: CanvasRenderingContext2D, name: string, x: number, y: number, s = 1, o: DrawOpt = {}) {
  let src: HTMLImageElement = atlas;
  let r = RECTS[name];
  if (!r && GEN[name]) { r = GEN[name]; src = gen; }
  if (!r) throw new Error("缺素材: " + name);
  const [fx, fy, fw, fh] = r;
  const w = fw * s * (o.sx ?? 1), h = fh * s * (o.sy ?? 1);
  ctx.save();
  ctx.globalAlpha *= o.alpha ?? 1;
  ctx.translate(Math.round(x), Math.round(y));
  if (o.rot) ctx.rotate(o.rot);
  if (o.flip) ctx.scale(-1, 1);
  const oy = o.anchor === "center" ? -h / 2 : -h;
  ctx.drawImage(src, fx, fy, fw, fh, Math.round(-w / 2), Math.round(oy), Math.round(w), Math.round(h));
  ctx.restore();
}

export function frameSize(name: string): [number, number] {
  const r = RECTS[name] || GEN[name];
  return r ? [r[2], r[3]] : [0, 0];
}

/** 角色动作：t 为动作已播放的秒数。 */
export function act(
  ctx: CanvasRenderingContext2D, c: Char, action: string, t: number,
  x: number, y: number, s = 1, o: DrawOpt & { speed?: number } = {},
) {
  const a = ACTIONS[c]?.[action];
  if (!a) throw new Error(`缺动作: ${c}.${action}`);
  const n = a.frames.length;
  let i = Math.floor(Math.max(0, t) * a.fps * (o.speed ?? 1));
  i = a.loop ? i % n : Math.min(i, n - 1);
  frame(ctx, a.frames[i], x, y, s, o);
}

export const prop = (ctx: CanvasRenderingContext2D, name: string, x: number, y: number, s = 1, o: DrawOpt = {}) =>
  frame(ctx, name, x, y, s, { anchor: "center", ...o });

export function fx(ctx: CanvasRenderingContext2D, name: string, t: number, x: number, y: number, s = 1, alpha = 1) {
  const list: string[] = (THINGS as Record<string, string[]>)[name] ?? [name];
  const f = list[Math.floor(t * 6) % list.length];
  frame(ctx, f, x, y, s, { anchor: "center", alpha });
}

export const CHAR_COLOR: Record<Char, string> = {
  whale: "#3b6fd8", claude: "#f28c3c", gpt: "#efe9ff", gemini: "#8a7bff",
  kimi: "#c7b8f0", qwen: "#7d5cf2", zai: "#f4f1ea", doubao: "#5cc8ff",
};
export const CHAR_NAME: Record<Char, string> = {
  whale: "本鲸", claude: "小克", gpt: "龙娘", gemini: "猫", kimi: "Kimi", qwen: "千问", zai: "狐狸", doubao: "豆包",
};
