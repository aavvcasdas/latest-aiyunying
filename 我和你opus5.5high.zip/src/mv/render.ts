// 帧渲染：低分辨率场景 → 最近邻放大 → 高分辨率歌词层。
import { SHOTS, LINES, BAR, DURATION, END_VOCAL } from "./data";
import { SHOT_FNS } from "./shots";
import { W, H, clamp, easeOut } from "./paint";

export const OUT_W = 1280;
export const OUT_H = 720;
export const FONT = "KuaiLe, 'PingFang SC', 'Microsoft YaHei', sans-serif";

export function shotAt(T: number) {
  let i = SHOTS.findIndex((s) => T >= s.start && T < s.end);
  if (i < 0) i = T < 0 ? 0 : SHOTS.length - 1;
  return i;
}

export function renderFrame(low: CanvasRenderingContext2D, hi: CanvasRenderingContext2D, T: number, showLyrics = true) {
  const i = shotAt(T);
  const s = SHOTS[i];
  const t = T - s.start, d = s.end - s.start;
  low.canvas.width = W; // 重置画布状态，避免任何镜头残留的 clip / transform
  low.save();
  low.imageSmoothingEnabled = false;
  try { SHOT_FNS[s.id](low, t, d, T); }
  catch (e) { low.fillStyle = "#300"; low.fillRect(0, 0, W, H); low.fillStyle = "#fff"; low.fillText(String(e), 10, 20); }
  low.restore();

  hi.imageSmoothingEnabled = false;
  hi.drawImage(low.canvas, 0, 0, W, H, 0, 0, OUT_W, OUT_H);

  if (s.id === "S01") title(hi, "我和你", clamp((t - 0.5) / 0.4) * (1 - clamp((t - 1.9) / 0.35)), 250, 92);
  if (s.id === "S33") {
    const a = clamp((t - 0.4) / 0.6) * (1 - clamp((t - (d - 1.3)) / 1.0));
    title(hi, "我和你", a, 200, 104);
    hi.save(); hi.globalAlpha = a * 0.95; hi.font = `28px ${FONT}`; hi.textAlign = "center";
    stroked(hi, "主演：本鲸 × 小克　友情出演：龙娘 猫 Kimi 千问 狐狸 豆包", 640, 292, "#fff", "#3a2a6a", 7);
    hi.font = `20px ${FONT}`;
    stroked(hi, "角色形象：ZipZipPipe《大AI和小AI们》CC BY-NC-SA 4.0 · 非商用二创", 640, 330, "#fff", "#3a2a6a", 6);
    hi.restore();
  }
  if (showLyrics) lyrics(hi, T);
}

function stroked(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, fill: string, stroke: string, w: number) {
  ctx.lineJoin = "round"; ctx.lineWidth = w; ctx.strokeStyle = stroke; ctx.strokeText(s, x, y);
  ctx.fillStyle = fill; ctx.fillText(s, x, y);
}

function title(ctx: CanvasRenderingContext2D, s: string, a: number, y: number, size: number) {
  if (a <= 0) return;
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(640, y);
  const k = 0.7 + 0.3 * easeOut(a);
  ctx.scale(k, k);
  ctx.font = `${size}px ${FONT}`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.lineJoin = "round";
  ctx.lineWidth = size * 0.28; ctx.strokeStyle = "#ffffff"; ctx.strokeText(s, 0, 0);
  ctx.lineWidth = size * 0.16; ctx.strokeStyle = "#3b6fd8"; ctx.strokeText(s, 0, 0);
  const g = ctx.createLinearGradient(0, -size / 2, 0, size / 2);
  g.addColorStop(0, "#fff6a8"); g.addColorStop(1, "#ffb43a");
  ctx.fillStyle = g; ctx.fillText(s, 0, 0);
  ctx.restore();
}

/** 卡拉 OK 歌词：每个词一个色块，正在唱的词放大。 */
function lyrics(ctx: CanvasRenderingContext2D, T: number) {
  if (T > END_VOCAL + 0.4 || T > DURATION) return;
  const L = LINES.find((l) => T >= l.start && T < l.end);
  if (!L) return;
  const lt = T - L.start;
  const half = Math.min(BAR, (L.end - L.start) / 2);
  const size = 46;
  ctx.save();
  ctx.font = `${size}px ${FONT}`; ctx.textBaseline = "alphabetic"; ctx.textAlign = "left";
  const gap = 26;
  const widths = L.words.map((w) => ctx.measureText(w).width);
  const total = widths.reduce((a, b) => a + b, 0) + gap * (L.words.length - 1);
  let x = 640 - total / 2;
  const y = 668;
  const appear = easeOut(lt / 0.18);
  ctx.globalAlpha = appear;
  L.words.forEach((w, wi) => {
    const ws = wi === 0 ? 0 : half;
    const we = wi === 0 ? half : (L.end - L.start) * 0.92;
    const p = clamp((lt - ws) / (we - ws) * 1.15);
    const active = lt >= ws && lt < we;
    const sc = active ? 1 + 0.08 * (1 - clamp((lt - ws) / 0.2)) + 0.04 : 1;
    ctx.save();
    ctx.translate(x + widths[wi] / 2, y);
    ctx.scale(sc, sc);
    ctx.translate(-widths[wi] / 2, 0);
    ctx.lineJoin = "round";
    ctx.lineWidth = 12; ctx.strokeStyle = "#2a1f55"; ctx.strokeText(w, 0, 0);
    ctx.fillStyle = "#ffffff"; ctx.fillText(w, 0, 0);
    if (p > 0) {
      ctx.save(); ctx.beginPath(); ctx.rect(-4, -size, widths[wi] * p + 4, size * 1.4); ctx.clip();
      const g = ctx.createLinearGradient(0, -size, 0, 6);
      g.addColorStop(0, "#fff38a"); g.addColorStop(1, "#ff9f2e");
      ctx.fillStyle = g; ctx.fillText(w, 0, 0);
      ctx.restore();
    }
    ctx.restore();
    x += widths[wi] + gap;
  });
  ctx.restore();
}
