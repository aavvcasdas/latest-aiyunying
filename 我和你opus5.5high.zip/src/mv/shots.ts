// 33 个镜头的绘制函数。每镜签名 (ctx, t 镜内秒数, d 镜长, T 全局秒数)。
import { act, frame, prop, fx, CHAR_COLOR, type Char } from "./sprites";
import { BEAT, T0 } from "./data";
import {
  W, H, clamp, lerp, ease, easeOut, easeIn, backOut, rnd, pop, mix,
  sky, circle, sun, moon, cloud, hills, hillY, grassTufts, flower, starfield, burst, lightShaft,
  vignette, fade, shadow, swingTree, tv, noise, clockFace, globe, motes, heartPath, speedLines, star,
} from "./paint";

type C2 = CanvasRenderingContext2D;
export type ShotFn = (ctx: C2, t: number, d: number, T: number) => void;

const beatPhase = (T: number) => { const b = (T - T0) / BEAT; return b - Math.floor(b); };
const pulse = (T: number, k = 7) => Math.exp(-beatPhase(T) * k);
const bi = (t: number) => Math.floor(t / BEAT + 0.001);

function cam(ctx: C2, z: number, cx: number, cy: number, f: () => void) {
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.scale(z, z); ctx.translate(-cx, -cy); f(); ctx.restore();
}

const ALL: Char[] = ["gemini", "kimi", "whale", "claude", "gpt", "qwen", "zai", "doubao"];
const FRIENDS: Char[] = ["gemini", "kimi", "qwen", "zai", "doubao"];
const happyAct: Record<Char, string> = { whale: "hop", claude: "hop", gpt: "float", gemini: "hop", kimi: "hop", qwen: "hop", zai: "hop", doubao: "hop" };
const idleAct: Record<Char, string> = { whale: "idle", claude: "idle", gpt: "hover", gemini: "idle", kimi: "idle", qwen: "idle", zai: "idle", doubao: "idle" };

// ———— 共用场景 ————
function meadow(ctx: C2, t: number, warm = 0, grey = 0) {
  sky(ctx, mix(mix("#7fc8ff", "#ffb88a", warm), "#a9b4c4", grey), mix(mix("#d8f1ff", "#ffe6b0", warm), "#dfe3ea", grey));
  cloud(ctx, 120 + t * 6, 70, 1.1); cloud(ctx, 470 - t * 4, 50, 0.8);
  hills(ctx, 250, mix("#7cc576", "#9aa69a", grey), 14, 0.01, 1.3);
  hills(ctx, 290, mix("#5db466", "#8a978b", grey), 10, 0.016, 0.2, mix("#73c96f", "#97a297", grey));
  grassTufts(ctx, 290, 360, 70, mix("#3f9a4c", "#7c877c", grey), 2, t * 2);
}

function swingScene(ctx: C2, t: number, both: boolean, ang: number, warm: number, grey: number) {
  meadow(ctx, t, warm, grey);
  sun(ctx, 520, 70, 22 + warm * 6, t, true, mix("#ffe36a", "#ffd04a", warm));
  if (both) { shadow(ctx, 330 + Math.sin(ang) * 30, 318, 64, 0.25); }
  else shadow(ctx, 308 + Math.sin(ang) * 30, 318, 26, 0.25);
  swingTree(ctx, 320, 318, 1, ang, (i, sx, sy) => {
    if (i === 0) act(ctx, "whale", both ? "sway" : "sad", t, sx, sy + 16, 0.62);
    else if (both) act(ctx, "claude", "idle", t, sx, sy + 16, 0.62);
  });
}

function room(ctx: C2, dark = 0) {
  sky(ctx, mix("#ffe9c9", "#2a2a4a", dark), mix("#ffd8a8", "#1e1e36", dark), 0, 240);
  ctx.fillStyle = mix("#ffd2a0", "#26263e", dark);
  for (let x = 0; x < W; x += 32) ctx.fillRect(x, 0, 12, 240);
  ctx.fillStyle = mix("#c98a5a", "#2b2230", dark); ctx.fillRect(0, 240, W, 120);
  ctx.fillStyle = mix("#b37648", "#241c28", dark); for (let y = 248; y < H; y += 16) ctx.fillRect(0, y, W, 2);
  ctx.fillStyle = mix("#8a5a3a", "#1a141e", dark); ctx.fillRect(0, 236, W, 6);
}

function rug(ctx: C2, grey = 0) {
  ctx.fillStyle = mix("#e86a7a", "#9a9a9a", grey); ctx.beginPath(); ctx.ellipse(320, 300, 250, 52, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = mix("#ffd36a", "#c0c0c0", grey); ctx.beginPath(); ctx.ellipse(320, 300, 200, 40, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = mix("#6ac0e8", "#a8a8a8", grey); ctx.beginPath(); ctx.ellipse(320, 300, 150, 28, 0, 0, Math.PI * 2); ctx.fill();
}

const TOYS: [string, number, number][] = [["gen_toy_robot", 200, 296], ["gen_toy_blocks", 285, 290], ["gen_toy_ball", 365, 300], ["gen_toy_bear", 445, 294]];

function lonelyMini(ctx: C2, t: number) {
  // 电视里的重播：缩小版第二镜
  swingScene(ctx, t, false, Math.sin(t * 1.6) * 0.12, 0, 0.15);
}

function cloudSea(ctx: C2, t: number, y: number, glow: number) {
  const g = ctx.createLinearGradient(0, y - 30, 0, y + 10);
  g.addColorStop(0, `rgba(255,250,220,0)`); g.addColorStop(1, `rgba(255,248,210,${0.6 + glow * 0.4})`);
  ctx.fillStyle = g; ctx.fillRect(0, y - 30, W, 40);
  ctx.fillStyle = `rgba(255,255,240,${0.7 + glow * 0.3})`; ctx.fillRect(0, y - 1, W, 2);
  for (let i = 0; i < 18; i++) {
    const x = ((i * 47 - t * 60) % (W + 120) + W + 120) % (W + 120) - 60;
    cloud(ctx, x, y + 26 + (i % 3) * 14, 1.2 + (i % 2) * 0.4, "#ffffff", "rgba(180,200,255,0.7)");
  }
  ctx.fillStyle = "#eef4ff"; ctx.fillRect(0, y + 60, W, H);
}

function ringPositions(n: number, r: number, rot: number, cx = W / 2, cy = 190) {
  return Array.from({ length: n }, (_, i) => {
    const a = rot + (i / n) * Math.PI * 2 - Math.PI / 2;
    return [cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.62, a] as const;
  });
}

function nightLine(ctx: C2, t: number) {
  sky(ctx, "#0e1230", "#3a2f6e");
  starfield(ctx, 80, t, 11);
  moon(ctx, 540, 60, 18, "#141838");
  hills(ctx, 300, "#1c2348", 8, 0.012, 2, "#242c5a");
}
const LINE_X = (i: number) => 76 + i * 70;

// ———— 镜头 ————
export const SHOT_FNS: Record<string, ShotFn> = {
  S01(ctx, t, d) { // 晴天
    const k = ease(t / d);
    sky(ctx, mix("#ffb3a0", "#6cc0ff", k), mix("#ffe2b8", "#d6f0ff", k));
    sun(ctx, 320, lerp(300, 120, easeOut(t / d * 1.1)), lerp(26, 36, k), t);
    cloud(ctx, 220 - k * 90, 110, 1.3); cloud(ctx, 430 + k * 90, 90, 1.1);
    hills(ctx, 270, "#6cc070", 22, 0.009, 0.6, "#86d47e");
    hills(ctx, 310, "#4fae5e", 12, 0.017, 2.2);
    grassTufts(ctx, 312, 360, 50, "#3c934a", 5, t * 2);
    fade(ctx, "#000", 1 - t / 0.45);
  },
  S02(ctx, t, d) { // 有点孤单
    const z = lerp(1.6, 1.0, ease(t / d));
    cam(ctx, z, lerp(300, 320, t / d), lerp(240, 180, ease(t / d)), () => {
      swingScene(ctx, t, false, Math.sin(t * 1.4) * 0.05, 0, 0.35);
      fx(ctx, "fx_gloom", t, 296, 214, 1.2, 0.9);
      // 一片落叶
      const ly = 140 + t * 70, lx = 360 + Math.sin(t * 3) * 18;
      ctx.fillStyle = "#c7a24a"; ctx.fillRect(lx, ly, 4, 2);
    });
    vignette(ctx, 0.35);
  },
  S03(ctx, t, _d, T) { // 玩具
    room(ctx); rug(ctx);
    TOYS.forEach(([n, x, y], i) => {
      const lt = t - i * BEAT; if (lt < 0) return;
      const s = 1.5 * pop(lt);
      const hop = Math.abs(Math.sin(lt * 7)) * 10 * Math.exp(-lt * 2);
      prop(ctx, n, x, y - 24 - hop, s);
      if (lt < 0.25) fx(ctx, "fx_sparkle", lt, x + 20, y - 50, 1.2);
    });
    act(ctx, "whale", "idle", t, 320, H + 110 - easeOut(t / 0.5) * 30, 2.2);
    vignette(ctx, 0.25 + pulse(T) * 0.05);
  },
  S04(ctx, t, d) { // 丢在旁边
    const k = easeOut(t / (d * 0.55));
    const g = clamp((t - d * 0.35) / (d * 0.5));
    room(ctx, g * 0.25); rug(ctx, g);
    ctx.save();
    ctx.filter = `grayscale(${g}) brightness(${1 - g * 0.15})`;
    TOYS.forEach(([n, x, y], i) => {
      const tx = 40 + i * 26, ty = 330 - (i % 2) * 8;
      const px = lerp(x, tx, k), py = lerp(y - 24, ty - 18, k);
      const rot = n === "gen_toy_bear" ? -Math.PI / 2 * easeOut((t - d * 0.4) / 0.3) : (n === "gen_toy_ball" ? -k * 6 : 0);
      prop(ctx, n, px, py, 1.3, { rot });
    });
    ctx.restore();
    for (let i = 0; i < 6; i++) { // 灰尘
      const lt = t - d * 0.45; if (lt < 0) break;
      circle(ctx, 70 + i * 14 + lt * 20 * (i - 3), 330 - lt * 30 - i * 2, 6 * (1 - clamp(lt / 0.8)), "rgba(200,190,180,0.6)");
    }
    act(ctx, "whale", "shake", t, 380, 318, 1.8);
    vignette(ctx, 0.3);
  },
  S05(ctx, t) { // 电视
    room(ctx, 0.85);
    const on = clamp((t - 0.25) / 0.35);
    // 屏幕照到地上的光
    ctx.fillStyle = `rgba(160,190,255,${on * 0.18})`; ctx.beginPath(); ctx.ellipse(300, 320, 220, 30, 0, 0, Math.PI * 2); ctx.fill();
    tv(ctx, 200, 80, 200, 150, (x, y, w, h) => {
      if (on < 1) { const hh = Math.max(2, h * on * on); ctx.fillStyle = "#fff"; ctx.fillRect(x, y + h / 2 - hh / 2, w, hh); }
      else noise(ctx, x, y, w, h, t);
    }, t > 0.25 ? 1 : 0);
    if (t < 0.3 && t > 0.2) fade(ctx, "#fff", 0.3);
  },
  S06(ctx, t, _d, T) { // 里没有新鲜
    room(ctx, 0.85);
    const b = bi(t);
    cam(ctx, 1.25, 300, 170, () => {
      tv(ctx, 200, 80, 200, 150, (x, y, w, h) => {
        const ph = beatPhase(T);
        if (ph < 0.18) { noise(ctx, x, y, w, h, t); return; }
        ctx.save(); ctx.translate(x, y); ctx.scale(w / W, h / H); lonelyMini(ctx, t); ctx.restore();
        ctx.fillStyle = "#3fff6a"; ctx.font = "bold 12px monospace"; ctx.fillText(`CH ${String(b + 2).padStart(2, "0")}`, x + w - 50, y + 16);
        ctx.fillStyle = "rgba(230,40,40,0.9)"; ctx.fillRect(x + 6, y + 6, 30, 13);
        ctx.fillStyle = "#fff"; ctx.font = "bold 10px sans-serif"; ctx.fillText("重播", x + 10, y + 16);
      });
    });
    ctx.fillStyle = "rgba(140,170,255,0.12)"; ctx.fillRect(0, 0, W, H);
    act(ctx, "whale", "idle", t, 110, 372, 1.7, { speed: 0.5 });
    fx(ctx, "fx_zzz", t, 160, 220, 1.4);
    vignette(ctx, 0.5);
  },
  S07(ctx, t, _d, T) { // 球鞋
    sky(ctx, "#fff6d8", "#ffe7a8", 0, 200);
    // 门框和门外的光
    ctx.fillStyle = "#fffef0"; ctx.fillRect(170, 0, 300, 230);
    lightShaft(ctx, 320, 300, 520, 0.35, "255,250,220", 0);
    ctx.fillStyle = "#9a6a44"; ctx.fillRect(150, 0, 20, 240); ctx.fillRect(470, 0, 20, 240);
    ctx.fillStyle = "#b9875a"; ctx.fillRect(0, 230, W, 130);
    ctx.fillStyle = "#a47548"; for (let y = 240; y < H; y += 18) ctx.fillRect(0, y, W, 2);
    ctx.fillStyle = "#8c5e3a"; ctx.fillRect(100, 262, 440, 10);
    const p = pulse(T, 9);
    shadow(ctx, 320, 300, 120, 0.25);
    prop(ctx, "gen_sneakers", 320, 262 - p * 10, 3.2 + p * 0.1, { sy: 1 - p * 0.06 });
    if (bi(t) % 2 === 1) fx(ctx, "fx_shine", t, 410, 200, 2, 1 - beatPhase(T));
    fx(ctx, "fx_sparkle", t, 220, 210, 1.5, 0.8);
  },
  S08(ctx, t, d) { // 跑不过时间
    const k = t / d;
    sky(ctx, mix(mix("#7fc8ff", "#ff9a5a", k * 1.4), "#7a5ab8", clamp(k * 2 - 1)), mix("#e0f4ff", "#ffd28a", k));
    sun(ctx, lerp(560, 80, k), lerp(60, 230, k), 20, t, false, mix("#ffe36a", "#ff7a3a", k));
    // 大钟在天上滚着往前跑
    const cx = lerp(380, 700, easeIn(k)), cy = 150;
    clockFace(ctx, cx, cy, 62, t * 22, t * 3, t * 40);
    hills(ctx, 260, mix("#6cbf6c", "#4a6a5a", k), 12, 0.02, t * 4);
    ctx.fillStyle = mix("#d9b98a", "#9a7a6a", k); ctx.fillRect(0, 300, W, 60);
    ctx.fillStyle = mix("#c4a272", "#86685a", k);
    for (let i = 0; i < 12; i++) ctx.fillRect(((i * 70 - t * 420) % (W + 70) + W + 70) % (W + 70) - 70, 322, 36, 4);
    speedLines(ctx, t, 24, "rgba(255,255,255,0.55)", -1);
    const wx = lerp(300, 190, ease(k));
    shadow(ctx, wx, 304, 22);
    act(ctx, "whale", "walk", t, wx, 304, 1.4, { speed: 2.4 });
    fx(ctx, "fx_sweat", t, wx + 30, 200, 1.4);
  },
  S09(ctx, t, d, T) { // 我要
    sky(ctx, "#4aa8ff", "#c8ecff");
    cloud(ctx, 120, 80 - t * 6, 1.4); cloud(ctx, 520, 120 - t * 4, 1);
    // 仰拍：山顶占画面下部
    ctx.fillStyle = "#4fae5e"; ctx.beginPath(); ctx.ellipse(320, 470, 420, 170, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#6cc76e"; ctx.beginPath(); ctx.ellipse(320, 470, 400, 160, 0, Math.PI, Math.PI * 2); ctx.fill();
    grassTufts(ctx, 312, 360, 40, "#3c934a", 9, t * 6);
    ctx.fillStyle = "rgba(255,255,255,0.7)"; // 风
    for (let i = 0; i < 6; i++) { const x = ((i * 130 + t * 300) % (W + 100)) - 50; ctx.fillRect(x, 120 + i * 30, 50, 2); }
    act(ctx, "whale", "point", t, 320, 318, 2.4);
    if (t > BEAT * 2) { const s = pop(t - BEAT * 2) * 2.4; fx(ctx, "fx_exclaim", t, 380, 120, s); }
    vignette(ctx, 0.15 + pulse(T) * 0.05);
    void d;
  },
  S10(ctx, t, d) { // 更大的世界
    const e = ease(t / d);
    const R = lerp(2400, 105, Math.pow(e, 0.55));
    const topY = lerp(300, 168, e);
    sky(ctx, mix("#4aa8ff", "#0b0f2e", clamp(e * 1.3)), mix("#c8ecff", "#2a2266", clamp(e * 1.2)));
    starfield(ctx, 90, t, 21, clamp((e - 0.35) * 2));
    const cy = topY + R;
    globe(ctx, W / 2, cy, R, 0.2 + t * 0.05, 1);
    ctx.save(); ctx.beginPath(); ctx.arc(W / 2, cy, R, 0, Math.PI * 2); ctx.clip();
    circle(ctx, W / 2, topY + R * 0.3, R * 0.42, "#58bf5f"); circle(ctx, W / 2, topY + R * 0.22, R * 0.3, "#72cf6c");
    ctx.restore();
    act(ctx, "whale", "wave", t, W / 2, topY + 2, lerp(2.2, 0.38, Math.pow(e, 0.5)));
  },
  S11(ctx, t, _d, T) { // 装满
    burst(ctx, 320, 220, 18, t * 0.3, "#ffe08a", "#fff1c2");
    const items = ["gen_map", "gen_compass", "gen_telescope", "gen_paper_plane", "prop_magnifier", "prop_book"];
    const slot = BEAT * 0.5;
    const landed: string[] = [];
    let squash = 0;
    items.forEach((n, i) => {
      const lt = t - i * slot - 0.05; const dur = 0.42;
      if (lt < 0) return;
      if (lt >= dur) { landed.push(n); squash = Math.max(squash, Math.exp(-(lt - dur) * 10)); return; }
      const k = lt / dur; const fromL = i % 2 === 0;
      const x = lerp(fromL ? -40 : W + 40, 300 + (i - 2.5) * 14, k);
      const y = lerp(120, 225, k) - Math.sin(k * Math.PI) * 120;
      const s = n.startsWith("prop_") ? 3 : 1.3;
      prop(ctx, n, x, y, s, { rot: k * 6 * (fromL ? 1 : -1) });
    });
    landed.forEach((n, i) => {
      const s = n.startsWith("prop_") ? 2.6 : 1.1;
      prop(ctx, n, 260 + i * 17, 222 - (i % 2) * 12, s, { rot: (i - 2.5) * 0.18 });
    });
    shadow(ctx, 320, 312, 90, 0.25);
    frame(ctx, "prop_basket", 320, 312, 7, { sx: 1 + squash * 0.12, sy: 1 - squash * 0.12 });
    if (landed.length >= items.length) fx(ctx, "fx_sparkle", t, 420, 170, 2);
    vignette(ctx, 0.15 + pulse(T) * 0.06);
  },
  S12(ctx, t) { // 不同的探险
    ctx.fillStyle = "#fff8e6"; ctx.fillRect(0, 0, W, H);
    const pw = 312, ph = 172;
    const pos = [[6, 6], [322, 6], [6, 182], [322, 182]];
    const panels: ((lt: number) => void)[] = [
      (lt) => { // 大海
        sky(ctx, "#5ec4ff", "#c8f0ff", 0, ph); sun(ctx, 260, 40, 14, lt, false);
        const wy = 110;
        const by = wy - 4 + Math.sin(lt * 4) * 4;
        act(ctx, "whale", "hop", lt, 150, by + 30, 0.9);
        ctx.fillStyle = "#2a8ce0"; ctx.beginPath(); ctx.moveTo(0, ph);
        for (let x = 0; x <= pw; x += 4) ctx.lineTo(x, wy + Math.sin(x * 0.05 + lt * 4) * 5);
        ctx.lineTo(pw, ph); ctx.fill();
        ctx.fillStyle = "#bfe8ff"; for (let x = 0; x < pw; x += 24) ctx.fillRect(x + (lt * 30) % 24, wy + 16, 10, 2);
      },
      (lt) => { // 雪山
        sky(ctx, "#a8d8ff", "#eaf6ff", 0, ph);
        for (const [x, h, c] of [[60, 120, "#7a8fb8"], [180, 150, "#8aa0c8"], [280, 110, "#7a8fb8"]] as const) {
          ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(x - 90, ph); ctx.lineTo(x, ph - h); ctx.lineTo(x + 90, ph); ctx.fill();
          ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.moveTo(x - 26, ph - h + 34); ctx.lineTo(x, ph - h); ctx.lineTo(x + 26, ph - h + 34); ctx.fill();
        }
        for (let i = 0; i < 30; i++) ctx.fillRect((rnd(i) * pw + lt * 10) % pw, (rnd(i + 3) * ph + lt * 30) % ph, 2, 2);
        act(ctx, "whale", "point", lt, 120, 160, 0.9); prop(ctx, "gen_telescope", 160, 130, 0.9, { rot: -0.4 });
      },
      (lt) => { // 森林
        sky(ctx, "#bfeab0", "#eaffd8", 0, ph);
        for (let i = 0; i < 9; i++) {
          const x = i * 38 + 10, h = 90 + rnd(i) * 50;
          ctx.fillStyle = "#6a4a2a"; ctx.fillRect(x - 3, ph - 30, 6, 30);
          ctx.fillStyle = i % 2 ? "#2f8a44" : "#3fa354"; ctx.beginPath(); ctx.moveTo(x - 24, ph - 26); ctx.lineTo(x, ph - h); ctx.lineTo(x + 24, ph - 26); ctx.fill();
        }
        ctx.fillStyle = "#5aa64a"; ctx.fillRect(0, ph - 24, pw, 24);
        act(ctx, "whale", "walk", lt, 60 + lt * 40, ph - 6, 0.9);
        for (let i = 0; i < 8; i++) { ctx.fillStyle = "rgba(255,255,140,0.9)"; ctx.fillRect(40 + rnd(i) * 240 + Math.sin(lt * 3 + i) * 6, 30 + rnd(i * 2) * 90, 2, 2); }
      },
      (lt) => { // 星空
        sky(ctx, "#101848", "#3a2a7a", 0, ph);
        for (let i = 0; i < 40; i++) star(ctx, rnd(i * 1.1) * pw, rnd(i * 2.2) * ph, rnd(i) < 0.2 ? 2 : 0.5, 0.5 + 0.5 * Math.sin(lt * 4 + i));
        moon(ctx, 250, 40, 16, "#18205a");
        act(ctx, "whale", "spin", lt, 140, 130 + Math.sin(lt * 3) * 6, 0.9);
        prop(ctx, "gen_paper_plane", 200 + lt * 30, 70 - lt * 10, 0.9);
      },
    ];
    panels.forEach((fn, i) => {
      const lt = t - i * BEAT * 0.9; if (lt < 0) return;
      const k = easeOut(lt / 0.3);
      const [px, py] = pos[i];
      const ox = (1 - k) * (i % 2 ? 360 : -360);
      ctx.save(); ctx.translate(px + ox, py);
      ctx.fillStyle = "#2a2440"; ctx.fillRect(-3, -3, pw + 6, ph + 6);
      ctx.beginPath(); ctx.rect(0, 0, pw, ph); ctx.clip();
      fn(lt);
      ctx.restore();
    });
  },
  S13(ctx, t, d) { // 当然
    meadow(ctx, t, 0.15);
    // 路口和指路牌
    ctx.fillStyle = "#e8cf9a"; ctx.beginPath(); ctx.moveTo(250, H); ctx.lineTo(300, 290); ctx.lineTo(340, 290); ctx.lineTo(420, H); ctx.fill();
    ctx.fillStyle = "#7a4a2a"; ctx.fillRect(160, 200, 6, 110);
    ctx.fillStyle = "#c98a4b"; ctx.fillRect(132, 206, 60, 14); ctx.fillRect(142, 228, 56, 14);
    const cupIn = easeOut((t - 0.15) / 0.4);
    const clX = lerp(700, 430, easeOut((t - BEAT) / (BEAT * 2)));
    shadow(ctx, 260, 318, 26); act(ctx, "whale", t > BEAT * 2.6 ? "surprise" : "idle", t > BEAT * 2.6 ? t - BEAT * 2.6 : t, 260, 318, 1.5);
    prop(ctx, "prop_teacup", lerp(W + 30, clX - 34, cupIn), 300, 3);
    if (t > BEAT) {
      shadow(ctx, clX, 318, 26);
      if (t < BEAT * 3) act(ctx, "claude", "walk", t, clX, 318, 1.5, { flip: true });
      else act(ctx, "claude", "curtsy", t - BEAT * 3, clX, 318, 1.5);
    }
    if (t > BEAT * 2.6) fx(ctx, "fx_exclaim", t, 290, 170, 2 * pop(t - BEAT * 2.6));
    void d;
  },
  S14(ctx, t, d, T) { // 你陪在身边
    const z = lerp(1.0, 1.15, ease(t / d));
    cam(ctx, z, 320, 210, () => {
      swingScene(ctx, t, true, Math.sin(t * 2.4) * 0.28, 0.35, 0);
      for (let i = 0; i < 4; i++) {
        const lt = (t + i * 0.45) % 1.8;
        fx(ctx, "fx_heart", t, 300 + i * 18 + Math.sin(lt * 4) * 6, 200 - lt * 50, 1.1, 1 - lt / 1.8);
      }
    });
    vignette(ctx, 0.2 + pulse(T) * 0.04);
  },
  S15(ctx, t, _d, T) { // 每秒
    const b = bi(t);
    const cols = ["#ffd9e6", "#d9f0ff", "#e6ffd9", "#fff0c8"];
    ctx.fillStyle = cols[b % 4]; ctx.fillRect(0, 0, W, H);
    const tick = Math.min(1, beatPhase(T) * 8);
    clockFace(ctx, 320, 170, 150, 0.4, -0.6, ((b - 1 + tick) / 60) * Math.PI * 2 * 5, 60);
    const poses: [string, string][] = [["eat", "read"], ["hop", "hop"], ["nod", "nod"], ["wave", "curtsy"]];
    const [wa, ca] = poses[b % 4];
    const lt = t - b * BEAT;
    ctx.fillStyle = "rgba(255,255,255,0.65)"; ctx.beginPath(); ctx.ellipse(320, 330, 150, 18, 0, 0, Math.PI * 2); ctx.fill();
    act(ctx, "whale", wa, lt, 255, 334, 1.8);
    act(ctx, "claude", ca, lt, 390, 334, 1.8);
    if (wa === "eat") prop(ctx, "prop_bowl", 290, 300, 2.4);
    if (ca === "read") prop(ctx, "prop_book", 360, 290, 2.4);
    fade(ctx, "#fff", (1 - tick) * 0.35);
  },
  S16(ctx, t, d) { // 每天
    const ph = (t / d) * 2.2; // 两天多
    const cyc = ph % 1;
    const dayK = Math.sin(cyc * Math.PI * 2 - Math.PI / 2) * 0.5 + 0.5; // 0 夜 1 午
    const isDay = cyc < 0.5;
    sky(ctx, mix("#141a44", "#5ab4ff", 1 - Math.abs(cyc - 0.25) * 2.2), mix("#3a2f6e", "#ffd6a0", clamp(1 - Math.abs(cyc - 0.25) * 2)));
    starfield(ctx, 60, t, 31, clamp(1 - dayK * 1.6));
    const ang = (cyc % 0.5) / 0.5 * Math.PI;
    const ox = 320 - Math.cos(ang) * 280, oy = 260 - Math.sin(ang) * 200;
    if (isDay) sun(ctx, ox, oy, 20, t, true); else moon(ctx, ox, oy, 16, "#1c2250");
    hills(ctx, 270, mix("#1a2a3a", "#3f8a4a", dayK), 26, 0.008, 1.5);
    const hy = hillY(320, 270, 26, 0.008, 1.5);
    act(ctx, "whale", "sway", t, 300, hy + 6, 1);
    act(ctx, "claude", "idle", t, 342, hy + 6, 1);
    for (let i = 0; i < 5; i++) { // 日历纸飞走
      const lt = t - i * BEAT * 0.8; if (lt < 0 || lt > 1.2) continue;
      const x = 90 + lt * 160, y = 90 - lt * 70 + Math.sin(lt * 6) * 6;
      ctx.save(); ctx.translate(x, y); ctx.rotate(lt * 2);
      ctx.fillStyle = "#fff"; ctx.fillRect(-14, -16, 28, 32); ctx.fillStyle = "#e84a4a"; ctx.fillRect(-14, -16, 28, 9);
      ctx.fillStyle = "#333"; ctx.font = "bold 12px monospace"; ctx.fillText(String(i + 1), i + 1 > 9 ? -8 : -4, 10);
      ctx.restore();
    }
  },
  S17(ctx, t, _d, T) { // 我和你
    burst(ctx, 320, 200, 20, t * 0.6, "#8fd3ff", "#c9ecff");
    circle(ctx, 320, 200, 120 + pulse(T) * 10, "rgba(255,255,255,0.35)");
    shadow(ctx, 250, 320, 34); shadow(ctx, 390, 320, 34);
    act(ctx, "whale", "hop", t, 250, 320, 2.2);
    act(ctx, "claude", "hop", t + 0.1, 390, 320, 2.2);
    for (let i = 0; i < 6; i++) fx(ctx, "fx_sparkle", t + i * 0.2, 320 + Math.cos(i + t * 2) * 190, 170 + Math.sin(i * 1.7 + t * 2) * 110, 1.4);
    fx(ctx, "fx_heart", t, 320, 150 - Math.sin(t * 4) * 6, 2 * pop(t - 0.2));
    fade(ctx, "#fff", 1 - t / 0.25);
  },
  S18(ctx, t, d) { // 飞到蓝蓝的天边
    const k = t / d;
    sky(ctx, mix("#8fd3ff", "#1d5fd6", k), mix("#e8f7ff", "#7ec4ff", k));
    if (k < 0.55) {
      // 往上穿云：云往下掉
      for (let i = 0; i < 9; i++) {
        const y = ((rnd(i) * H + t * 520) % (H + 120)) - 60;
        cloud(ctx, rnd(i * 2) * W, y, 1.4 + rnd(i * 3), "#ffffff", "rgba(190,215,255,0.6)");
      }
      const y = lerp(380, 210, easeOut(k / 0.55));
      act(ctx, "gpt", "fly", t, 320, y + 40, 1.8);
      act(ctx, "whale", "spin", t, 250, y + 10, 1.3);
      act(ctx, "claude", "hop", t, 395, y + 10, 1.3);
      speedLines(ctx, t, 14, "rgba(255,255,255,0.5)");
    } else {
      const k2 = (k - 0.55) / 0.45;
      cloudSea(ctx, t, 250, k2);
      const s = lerp(1.6, 0.7, ease(k2)), y = lerp(230, 225, k2);
      const x = lerp(320, 360, k2);
      act(ctx, "gpt", "fly", t, x, y, s);
      act(ctx, "whale", "spin", t, x - 50 * s, y - 20 * s, s * 0.8);
      act(ctx, "claude", "hop", t, x + 48 * s, y - 20 * s, s * 0.8);
      // 天边亮线
      ctx.fillStyle = `rgba(255,255,230,${0.5 + k2 * 0.5})`; ctx.fillRect(0, 248, W, 3);
    }
  },
  S19(ctx, t, _d, T) { // 我和你（种）
    sky(ctx, "#9fdcff", "#eaffff");
    sun(ctx, 560, 60, 18, t, true);
    ctx.fillStyle = "#7cc576"; ctx.fillRect(0, 220, W, 30);
    ctx.fillStyle = "#8a5a3a"; ctx.fillRect(0, 250, W, 110);
    ctx.fillStyle = "#6e4428"; for (let y = 268; y < H; y += 24) { ctx.beginPath(); ctx.ellipse(320, y, 300, 6, 0, 0, Math.PI * 2); ctx.fill(); }
    act(ctx, "whale", "nod", t % 0.8, 220, 300, 1.7);
    prop(ctx, "gen_trowel", 262, 268 + Math.sin(t * 10) * 3, 1.1, { rot: 0.8 });
    act(ctx, "claude", "nod", (t + 0.3) % 0.8, 430, 300, 1.7);
    prop(ctx, "gen_watering_can", 380, 230, 1.1, { rot: -0.45, flip: true });
    for (let i = 0; i < 10; i++) { // 水滴
      const lt = (t * 1.6 + i / 10) % 1;
      ctx.fillStyle = "#7fd0ff"; ctx.fillRect(352 - lt * 14 + (i % 3) * 3, 236 + lt * 60, 2, 3);
    }
    prop(ctx, "gen_seed_packet", 320, 120 + Math.sin(t * 3) * 4, 1.3, { rot: 0.5 });
    for (let i = 0; i < 12; i++) {
      const lt = (t * 1.2 + i / 12) % 1;
      ctx.fillStyle = "#4a2a1a"; ctx.fillRect(322 + Math.sin(i * 2) * 8 * lt, 140 + lt * 140, 2, 2);
    }
    vignette(ctx, 0.15 + pulse(T) * 0.04);
  },
  S20(ctx, t, d, T) { // 种下满满的花园
    sky(ctx, "#8fd3ff", "#e8fbff");
    sun(ctx, 560, 56, 18, t, true);
    hills(ctx, 200, "#7cc576", 10, 0.01, 0.4);
    ctx.fillStyle = "#6cbd68"; ctx.fillRect(0, 210, W, H);
    const cols = ["#ff8fb1", "#ffd84a", "#ffffff", "#c79bff", "#ff9a5a", "#7fd0ff"];
    const rows = 7, colsN = 15;
    for (let r = 0; r < rows; r++) for (let c = 0; c < colsN; c++) {
      const x = (c + 0.5 + (r % 2) * 0.5) * (W / colsN) - 10, y = 220 + r * 21;
      const dist = Math.hypot((x - 320) / 320, (y - 300) / 80);
      const st = dist * d * 0.45 + rnd(r * 31 + c) * 0.15;
      flower(ctx, x, y, 0.8 + r * 0.12, cols[(r * 7 + c) % cols.length], (t - st) / 0.5);
    }
    FRIENDS.forEach((c, i) => {
      const lt = t - 0.3 - i * BEAT * 0.55; if (lt < 0) return;
      const x = [90, 190, 450, 550, 620][i] - (i === 4 ? 40 : 0);
      const y = [270, 240, 240, 272, 300][i];
      act(ctx, c, "hop", lt, x, y - 26 * (1 - easeOut(lt / 0.3)) + 26 * 0, 1.0 * pop(lt));
    });
    act(ctx, "whale", "wave", t, 290, 340, 1.3);
    act(ctx, "claude", "hop", t, 360, 340, 1.3);
    vignette(ctx, 0.12 + pulse(T) * 0.05);
  },
  S21(ctx, t) { // 我和你（光）
    sky(ctx, "#ffb46a", "#ffe9b0");
    hills(ctx, 280, "#8aa04a", 10, 0.012, 1, "#a6b85a");
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < 5; i++) lightShaft(ctx, 120 + i * 110 + Math.sin(t + i) * 6, 30, 90, 0.25 + 0.1 * Math.sin(t * 2 + i), "255,220,140", 60);
    ctx.restore();
    // 前景树冠
    for (let i = 0; i < 12; i++) circle(ctx, i * 60 - 10, 10 + (i % 3) * 14, 50, i % 2 ? "#3b6a2e" : "#4a7d36");
    ctx.fillStyle = "#4a2e1e"; ctx.fillRect(40, 0, 26, 300);
    shadow(ctx, 290, 312, 26); shadow(ctx, 360, 312, 26);
    act(ctx, "whale", "idle", t, 290, 312, 1.6);
    act(ctx, "claude", "idle", t, 360, 312, 1.6);
    motes(ctx, t, 30, "#fff2c0");
  },
  S22(ctx, t, d) { // 分享暖暖的光线
    const k = t / d;
    sky(ctx, "#ffb46a", "#ffe9b0");
    hills(ctx, 290, "#8aa04a", 10, 0.012, 1, "#a6b85a");
    for (let i = 0; i < 10; i++) circle(ctx, i * 70, 0, 48, "#4a7d36");
    const bx = 245, by = 175, cx = 420, cy = 215;
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    lightShaft(ctx, bx - 40, 24, 40, 0.5, "255,220,140", 40);
    const g1 = clamp(k * 2.2);
    circle(ctx, bx, by, 34 * g1, "rgba(255,210,110,0.35)");
    // 光从饭盆流向茶杯
    const flow = clamp((k - 0.35) / 0.4);
    for (let i = 0; i < 20; i++) {
      const p = ((i / 20 + t * 1.2) % 1) * flow;
      if (p <= 0) continue;
      const x = lerp(bx, cx, p), y = lerp(by, cy, p) - Math.sin(p * Math.PI) * 60;
      circle(ctx, x, y, 3, "rgba(255,230,150,0.9)");
    }
    const g2 = clamp((k - 0.6) / 0.3);
    circle(ctx, cx, cy, 30 * g2, "rgba(255,210,110,0.35)");
    const both = clamp((k - 0.75) / 0.25);
    circle(ctx, 210, 250, 90 * both, "rgba(255,190,90,0.18)"); circle(ctx, 450, 250, 90 * both, "rgba(255,190,90,0.18)");
    ctx.restore();
    act(ctx, "whale", "point", t, 210, 330, 2.1);
    prop(ctx, "prop_bowl", bx, by + 10, 4, { rot: -0.25 * flow });
    act(ctx, "claude", k > 0.7 ? "curtsy" : "idle", k > 0.7 ? t - d * 0.7 : t, 460, 330, 2.1, { flip: true });
    prop(ctx, "prop_teacup", cx, cy + 10, 4);
    motes(ctx, t, 30, "#fff2c0");
  },
  S23(ctx, t, d) { // 再靠近一点（特写）
    sky(ctx, "#ffd1e3", "#fff0f6");
    for (let i = 0; i < 14; i++) circle(ctx, rnd(i) * W, rnd(i + 5) * H, 10 + rnd(i * 3) * 24, `rgba(255,255,255,${0.25 + 0.2 * Math.sin(t * 2 + i)})`);
    const step = Math.min(2, bi(t) / 2 | 0) + easeOut((t % (BEAT * 2)) / 0.25) - 1;
    const gap = lerp(190, 100, clamp(step / 1.6));
    act(ctx, "whale", "idle", t, 320 - gap / 2, 380, 2.6);
    act(ctx, "claude", "idle", t, 320 + gap / 2, 380, 2.6);
    fx(ctx, "fx_heart", t, 320, 120, 1.8 * pop(t - d * 0.5));
    const hs = lerp(560, 190, ease(t / d));
    ctx.fillStyle = "#1b1030"; ctx.beginPath(); ctx.rect(0, 0, W, H); heartPath(ctx, 320, 230, hs); ctx.fill("evenodd");
  },
  S24(ctx, t, d, T) { // 再靠近一点（全员合照）
    meadow(ctx, t, 0.1);
    const squeeze = clamp(bi(t) / 3 + easeOut((t % BEAT) / 0.2) / 3);
    ALL.forEach((c, i) => {
      const spread = lerp(78, 46, squeeze);
      const x = 320 + (i - 3.5) * spread, y = 320 - (i % 2) * 6;
      shadow(ctx, x, y, 20);
      act(ctx, c, c === "gpt" ? "hover" : (i % 2 ? "hop" : "idle"), t + i * 0.1, x, y, 1.1, { flip: i > 3 && c !== "gpt" });
    });
    if (t > d - 0.42) {
      const lt = t - (d - 0.42);
      fade(ctx, "#fff", 1 - lt / 0.3);
      // 拍立得边框
      ctx.fillStyle = "#fffdf6"; ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.rect(26, 18, W - 52, H - 70); ctx.fill("evenodd");
      ctx.fillStyle = "#3a3050"; ctx.font = "bold 18px sans-serif"; ctx.fillText("我们 ♡", 40, H - 22);
    }
    void T;
  },
  S25(ctx, t, d) { // 我和你（从照片起飞）
    sky(ctx, "#8fd3ff", "#e8fbff");
    cloud(ctx, 100, 70, 1.2); cloud(ctx, 520, 100, 1);
    const k = ease(t / d);
    const ps = lerp(1, 0.55, k), py = lerp(180, 270, k);
    ctx.save(); ctx.translate(320, py); ctx.scale(ps, ps); ctx.rotate(-0.06 * k);
    ctx.fillStyle = "rgba(0,0,0,0.2)"; ctx.fillRect(-294 + 8, -171 + 8, 588, 342);
    ctx.fillStyle = "#fffdf6"; ctx.fillRect(-294, -171, 588, 342);
    ctx.save(); ctx.beginPath(); ctx.rect(-268, -153, 536, 272); ctx.clip();
    ctx.translate(-320, -180 + 20);
    meadow(ctx, 0, 0.1);
    ALL.forEach((c, i) => { if (c === "whale" || c === "claude") return; act(ctx, c, idleAct[c], 0, 320 + (i - 3.5) * 46, 320 - (i % 2) * 6, 1.1, { flip: i > 3 && c !== "gpt" }); });
    ctx.restore();
    ctx.fillStyle = "#3a3050"; ctx.font = "bold 18px sans-serif"; ctx.fillText("我们 ♡", -278, 158);
    ctx.restore();
    // 两人跳出相框
    const out = easeOut(t / d);
    act(ctx, "whale", "spin", t, lerp(320 - 0.5 * 46, 260, out), lerp(320, 170, out), lerp(1.1, 1.6, out));
    act(ctx, "claude", "hop", t, lerp(320 + 0.5 * 46, 380, out), lerp(314, 165, out), lerp(1.1, 1.6, out));
    for (let i = 0; i < 5; i++) fx(ctx, "fx_sparkle", t + i * 0.3, 320 + Math.cos(i * 1.3) * 120 * out, 200 - out * 60 + Math.sin(i) * 40, 1.3);
  },
  S26(ctx, t, d) { // 飞到蓝蓝的天边（全员编队）
    const k = t / d;
    sky(ctx, mix("#3a8cff", "#1a4fc8", k), "#bfe6ff");
    cloudSea(ctx, t * 2, 262, k);
    const order: Char[] = ["gpt", "whale", "claude", "gemini", "kimi", "qwen", "zai", "doubao"];
    order.forEach((c, i) => {
      const row = Math.ceil(i / 2), side = i === 0 ? 0 : (i % 2 ? -1 : 1);
      const x = 420 - row * 62 + Math.sin(t * 3 + i) * 3 + k * 40;
      const y = 215 + side * row * 18 + Math.sin(t * 2.4 + i) * 5;
      ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.fillRect(x - 70, y - 30, 40, 2);
      act(ctx, c, c === "gpt" ? "fly" : (["whale", "qwen", "doubao", "gemini"].includes(c) && i % 2 ? "spin" : "hop"), t + i * 0.07, x, y, c === "gpt" ? 1.3 : 0.95);
    });
    speedLines(ctx, t, 10, "rgba(255,255,255,0.45)");
  },
  S27(ctx, t) { // 我和你就像（围圈）
    ctx.fillStyle = "#74c46e"; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 160; i++) { ctx.fillStyle = i % 3 ? "#62b25e" : "#8ad482"; ctx.fillRect(rnd(i) * W, rnd(i + 9) * H, 3, 2); }
    const pts = ringPositions(8, 150, t * 0.35);
    ctx.strokeStyle = "rgba(255,250,220,0.85)"; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(320, 190, 150, 93, 0, 0, Math.PI * 2); ctx.stroke();
    [...pts.map((p, i) => [p, i] as const)].sort((a, b) => a[0][1] - b[0][1]).forEach(([[x, y], i]) => {
      act(ctx, ALL[i], idleAct[ALL[i]], t + i * 0.1, x, y + 40, 1);
    });
    vignette(ctx, 0.25);
  },
  S28(ctx, t, d, T) { // 满满的花园（每人一朵花）
    ctx.fillStyle = "#74c46e"; ctx.fillRect(0, 0, W, H);
    for (let i = 0; i < 160; i++) { ctx.fillStyle = i % 3 ? "#62b25e" : "#8ad482"; ctx.fillRect(rnd(i) * W, rnd(i + 9) * H, 3, 2); }
    const rot = (t + d) * 0.35 * 0 + 0.35 * (BEAT * 4) ;
    const pts = ringPositions(8, 150, rot + t * 0.12);
    pts.forEach(([x, y, a], i) => {
      const b = clamp((t - i * BEAT * 0.45) / 0.35);
      if (b <= 0) return;
      const r = 95 * backOut(b);
      ctx.save(); ctx.translate(320, 190); ctx.scale(1, 0.62); ctx.rotate(a);
      ctx.fillStyle = CHAR_COLOR[ALL[i]]; ctx.beginPath(); ctx.ellipse(110, 0, r, r * 0.55, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.ellipse(110, 0, r * 0.6, r * 0.18, 0, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      void x; void y;
    });
    const cg = clamp((t - BEAT * 3.6) / 0.4);
    circle(ctx, 320, 190, 70 * backOut(cg), "#ffcf3a"); circle(ctx, 320, 190, 50 * backOut(cg), "#ffe27a");
    for (let i = 0; i < 12 && cg > 0; i++) circle(ctx, 320 + Math.cos(i) * 34 * cg, 190 + Math.sin(i * 2.1) * 22 * cg, 3, "#e8a92a");
    [...pts.map((p, i) => [p, i] as const)].sort((a, b) => a[0][1] - b[0][1]).forEach(([[x, y], i]) => {
      act(ctx, ALL[i], happyAct[ALL[i]], t + i * 0.1, x, y + 40, 1);
    });
    fade(ctx, "#fff", pulse(T, 10) * 0.12);
  },
  S29(ctx, t, d) { // 我和你就像（夜，各自亮起）
    nightLine(ctx, t);
    ALL.forEach((c, i) => {
      const x = LINE_X(i), y = 306;
      const on = clamp((t - (i / 8) * d * 0.8) / 0.25);
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      circle(ctx, x, y - 44, 36 * on, `rgba(255,220,150,${0.18 * on})`);
      circle(ctx, x, y - 44, 6 * on, CHAR_COLOR[c]);
      ctx.restore();
      act(ctx, c, idleAct[c], t + i * 0.1, x, y, 0.95);
    });
  },
  S30(ctx, t, d) { // 暖暖的光线（八道光汇成一束）
    nightLine(ctx, t);
    const k = t / d;
    const top = [320, 40] as const;
    ctx.save(); ctx.globalCompositeOperation = "lighter";
    ALL.forEach((c, i) => {
      const x = LINE_X(i), y = 262;
      const p = clamp((k - i * 0.04) / 0.55);
      const ex = lerp(x, top[0], p), ey = lerp(y, top[1], p);
      ctx.strokeStyle = CHAR_COLOR[c]; ctx.globalAlpha = 0.85; ctx.lineWidth = 6; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.globalAlpha = 1;
      circle(ctx, x, y, 10, "rgba(255,220,150,0.5)");
    });
    const g = clamp((k - 0.55) / 0.35);
    circle(ctx, top[0], top[1], 80 * g, "rgba(255,230,170,0.35)");
    circle(ctx, top[0], top[1], 30 * g, "rgba(255,250,230,0.9)");
    ctx.restore();
    ALL.forEach((c, i) => act(ctx, c, happyAct[c], t + i * 0.1, LINE_X(i), 306, 0.95));
    fade(ctx, "#fff7e0", clamp((k - 0.85) / 0.15) * 0.6);
  },
  S31(ctx, t, d) { // 把地球
    ctx.fillStyle = "#070a22"; ctx.fillRect(0, 0, W, H);
    starfield(ctx, 120, t, 41);
    const z = lerp(1, 1.12, ease(t / d));
    cam(ctx, z, 320, 200, () => {
      globe(ctx, 320, 240, 120, t * 0.04, 0, 0, t);
      ALL.forEach((c, i) => act(ctx, c, idleAct[c], t + i * 0.1, 320 + (i - 3.5) * 13, 122 + Math.abs(i - 3.5) * 0.9, 0.36));
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      const g = ctx.createLinearGradient(0, -40, 0, 120);
      g.addColorStop(0, "rgba(255,240,200,0)"); g.addColorStop(1, `rgba(255,240,200,${0.5 * ease(t / 0.6)})`);
      ctx.fillStyle = g; ctx.fillRect(296, -40, 48, 160);
      ctx.restore();
    });
    fade(ctx, "#fff7e0", 0.6 - t / 0.3);
  },
  S32(ctx, t, d) { // 照亮
    const k = t / d;
    ctx.fillStyle = mix("#070a22", "#1a2a6a", k); ctx.fillRect(0, 0, W, H);
    starfield(ctx, 120, t, 41, 1 - k * 0.6);
    cam(ctx, 1.12, 320, 200, () => {
      const sr = ease(clamp((k - 0.45) / 0.55));
      ctx.save(); ctx.globalCompositeOperation = "lighter";
      if (sr > 0) {
        const sg = ctx.createRadialGradient(470, 330, 0, 470, 330, 200 * sr);
        sg.addColorStop(0, "rgba(255,250,220,1)"); sg.addColorStop(0.25, "rgba(255,200,110,0.8)"); sg.addColorStop(1, "rgba(255,140,60,0)");
        ctx.fillStyle = sg; ctx.fillRect(220, 80, 500, 500);
      }
      ctx.restore();
      globe(ctx, 320, 240, 120, (t + 1.74) * 0.04, ease(k * 1.1), ease(k), t);
      ALL.forEach((c, i) => act(ctx, c, happyAct[c], t + i * 0.1, 320 + (i - 3.5) * 13, 122 + Math.abs(i - 3.5) * 0.9, 0.36));
    });
    for (let i = 0; i < 16; i++) fx(ctx, "fx_sparkle", t + i * 0.13, 320 + Math.cos(i * 2.4) * (40 + k * 200), 200 + Math.sin(i * 1.9) * (30 + k * 130), 1.2, clamp(k * 2));
    fade(ctx, "#fffaf0", clamp((k - 0.88) / 0.12));
  },
  S33(ctx, t, d) { // 尾奏
    swingScene(ctx, t, true, Math.sin(t * 2) * 0.22, 0.25, 0);
    fade(ctx, "#fffaf0", 1 - t / 0.5);
    fade(ctx, "#000", clamp((t - (d - 1.4)) / 1.3));
  },
};
