// 程序化场景绘制（不使用任何背景图片）。画在 640×360 的低分辨率画布上，再最近邻放大，和像素角色同一个颗粒感。
export const W = 640;
export const H = 360;
type C2 = CanvasRenderingContext2D;

export const clamp = (x: number, a = 0, b = 1) => Math.max(a, Math.min(b, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const ease = (t: number) => { t = clamp(t); return t * t * (3 - 2 * t); };
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
export const easeIn = (t: number) => Math.pow(clamp(t), 3);
export const backOut = (t: number) => { t = clamp(t); const c = 1.9; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };
export const rnd = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const pop = (t: number) => (t <= 0 ? 0 : backOut(t * 3.2)); // 弹出缩放

function hexToRgb(h: string): [number, number, number] {
  if (h.startsWith("rgb")) { const m = h.match(/[\d.]+/g)!.map(Number); return [m[0], m[1], m[2]]; }
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function mix(a: string, b: string, t: number) {
  const A = hexToRgb(a), B = hexToRgb(b); t = clamp(t);
  return `rgb(${Math.round(lerp(A[0], B[0], t))},${Math.round(lerp(A[1], B[1], t))},${Math.round(lerp(A[2], B[2], t))})`;
}

export function sky(ctx: C2, top: string, bottom: string, y0 = 0, y1 = H) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, top); g.addColorStop(1, bottom);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

export function circle(ctx: C2, x: number, y: number, r: number, color: string) {
  ctx.fillStyle = color; ctx.beginPath(); ctx.arc(x, y, Math.max(0, r), 0, Math.PI * 2); ctx.fill();
}

/** 卡通太阳：会眨眼的小脸 + 旋转光芒。 */
export function sun(ctx: C2, x: number, y: number, r: number, t: number, face = true, color = "#ffd84a") {
  ctx.save(); ctx.translate(x, y);
  const glow = ctx.createRadialGradient(0, 0, r * 0.6, 0, 0, r * 2.6);
  glow.addColorStop(0, "rgba(255,240,170,0.55)"); glow.addColorStop(1, "rgba(255,240,170,0)");
  ctx.fillStyle = glow; ctx.fillRect(-r * 3, -r * 3, r * 6, r * 6);
  ctx.rotate(t * 0.6);
  ctx.fillStyle = "#ffb43a";
  for (let i = 0; i < 12; i++) {
    ctx.rotate(Math.PI / 6);
    const L = r * (i % 2 ? 1.45 : 1.7);
    ctx.beginPath(); ctx.moveTo(-r * 0.16, -r * 1.08); ctx.lineTo(0, -L); ctx.lineTo(r * 0.16, -r * 1.08); ctx.fill();
  }
  ctx.rotate(-t * 0.6 - Math.PI * 2);
  circle(ctx, 0, 0, r * 1.06, "#ff9f2e");
  circle(ctx, 0, 0, r, color);
  if (face) {
    const blink = (t % 3.2) < 0.15;
    ctx.fillStyle = "#6b3b12";
    if (blink) { ctx.fillRect(-r * 0.42, -r * 0.12, r * 0.24, r * 0.06); ctx.fillRect(r * 0.18, -r * 0.12, r * 0.24, r * 0.06); }
    else { circle(ctx, -r * 0.3, -r * 0.1, r * 0.1, "#6b3b12"); circle(ctx, r * 0.3, -r * 0.1, r * 0.1, "#6b3b12"); }
    circle(ctx, -r * 0.55, r * 0.18, r * 0.13, "rgba(255,120,90,0.55)");
    circle(ctx, r * 0.55, r * 0.18, r * 0.13, "rgba(255,120,90,0.55)");
    ctx.strokeStyle = "#6b3b12"; ctx.lineWidth = Math.max(1, r * 0.07);
    ctx.beginPath(); ctx.arc(0, r * 0.12, r * 0.24, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke();
  }
  ctx.restore();
}

export function moon(ctx: C2, x: number, y: number, r: number, bg: string) {
  circle(ctx, x, y, r * 1.8, "rgba(255,250,210,0.12)");
  circle(ctx, x, y, r, "#fff6c8");
  circle(ctx, x + r * 0.45, y - r * 0.25, r * 0.9, bg);
}

export function cloud(ctx: C2, x: number, y: number, s: number, color = "#ffffff", shade = "rgba(170,200,240,0.6)") {
  const parts: [number, number, number][] = [[-22, 4, 14], [-6, -6, 18], [14, -2, 15], [28, 6, 11], [0, 8, 14]];
  for (const [dx, dy, r] of parts) circle(ctx, x + dx * s, y + dy * s + 3 * s, r * s, shade);
  for (const [dx, dy, r] of parts) circle(ctx, x + dx * s, y + dy * s, r * s, color);
}

/** 起伏的山坡：baseY 基线，amp 振幅。 */
export function hills(ctx: C2, baseY: number, color: string, amp = 18, freq = 0.012, phase = 0, top?: string) {
  ctx.beginPath(); ctx.moveTo(0, H);
  for (let x = 0; x <= W; x += 4) ctx.lineTo(x, baseY - Math.sin(x * freq + phase) * amp - Math.sin(x * freq * 2.3 + phase * 1.7) * amp * 0.35);
  ctx.lineTo(W, H); ctx.closePath();
  if (top) { const g = ctx.createLinearGradient(0, baseY - amp, 0, H); g.addColorStop(0, top); g.addColorStop(1, color); ctx.fillStyle = g; }
  else ctx.fillStyle = color;
  ctx.fill();
}
export const hillY = (x: number, baseY: number, amp = 18, freq = 0.012, phase = 0) =>
  baseY - Math.sin(x * freq + phase) * amp - Math.sin(x * freq * 2.3 + phase * 1.7) * amp * 0.35;

export function grassTufts(ctx: C2, y0: number, y1: number, n: number, color: string, seed = 1, sway = 0) {
  ctx.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const x = rnd(i + seed) * W, y = lerp(y0, y1, rnd(i * 3 + seed));
    const k = Math.sin(sway + i) * 1.5;
    ctx.fillRect(x, y - 4, 1, 4); ctx.fillRect(x + 2 + k * 0.3, y - 6, 1, 6); ctx.fillRect(x + 4, y - 3, 1, 3);
  }
}

/** 小花：bloom 0..1 从苗长到开放。 */
export function flower(ctx: C2, x: number, y: number, s: number, color: string, bloom = 1, center = "#ffd84a") {
  const b = clamp(bloom);
  if (b <= 0) return;
  const stem = 14 * s * Math.min(1, b * 1.6);
  ctx.fillStyle = "#3e9a4a"; ctx.fillRect(x - Math.max(1, s * 0.7) / 2, y - stem, Math.max(1, s * 0.9), stem);
  if (b > 0.35) { ctx.fillStyle = "#57b85e"; ctx.fillRect(x, y - stem * 0.5, 4 * s, 2 * s); ctx.fillRect(x - 4 * s, y - stem * 0.35, 4 * s, 2 * s); }
  const pb = clamp((b - 0.45) / 0.55);
  if (pb > 0) {
    const r = 5 * s * backOut(pb);
    for (let i = 0; i < 5; i++) { const a = (i / 5) * Math.PI * 2 - Math.PI / 2; circle(ctx, x + Math.cos(a) * r * 0.8, y - stem + Math.sin(a) * r * 0.8, r * 0.62, color); }
    circle(ctx, x, y - stem, r * 0.45, center);
  } else circle(ctx, x, y - stem, 2 * s, "#7ccf6f");
}

export function star(ctx: C2, x: number, y: number, r: number, a = 1, color = "#fff8d0") {
  ctx.save(); ctx.globalAlpha *= a; ctx.fillStyle = color;
  ctx.fillRect(x - r, y - 0.5, r * 2 + 1, 1); ctx.fillRect(x - 0.5, y - r, 1, r * 2 + 1);
  ctx.fillRect(x - 1, y - 1, 2, 2); ctx.restore();
}
export function starfield(ctx: C2, n: number, t: number, seed = 7, a = 1) {
  for (let i = 0; i < n; i++) {
    const tw = 0.5 + 0.5 * Math.sin(t * 3 + i * 1.7);
    star(ctx, rnd(i + seed) * W, rnd(i * 2.3 + seed) * H, rnd(i * 5 + seed) < 0.15 ? 2 : 0.6, a * (0.35 + 0.65 * tw));
  }
}

/** 放射光：副歌爆点用。 */
export function burst(ctx: C2, x: number, y: number, n: number, rot: number, c1: string, c2: string, R = 900) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = i % 2 ? c1 : c2;
    const a0 = (i / n) * Math.PI * 2, a1 = ((i + 1) / n) * Math.PI * 2;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a0) * R, Math.sin(a0) * R); ctx.lineTo(Math.cos(a1) * R, Math.sin(a1) * R); ctx.fill();
  }
  ctx.restore();
}

export function lightShaft(ctx: C2, x: number, w0: number, w1: number, a: number, color = "255,236,170", skew = 40) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, `rgba(${color},${a})`); g.addColorStop(1, `rgba(${color},0)`);
  ctx.fillStyle = g; ctx.beginPath();
  ctx.moveTo(x - w0 / 2, 0); ctx.lineTo(x + w0 / 2, 0); ctx.lineTo(x + skew + w1 / 2, H); ctx.lineTo(x + skew - w1 / 2, H); ctx.fill();
}

export function vignette(ctx: C2, a = 0.35) {
  const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.35, W / 2, H / 2, H * 0.95);
  g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, `rgba(20,10,40,${a})`);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
}

export function fade(ctx: C2, color: string, a: number) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = clamp(a); ctx.fillStyle = color; ctx.fillRect(0, 0, W, H); ctx.restore();
}

export function shadow(ctx: C2, x: number, y: number, w: number, a = 0.22) {
  ctx.fillStyle = `rgba(30,40,70,${a})`; ctx.beginPath(); ctx.ellipse(x, y, w, w * 0.25, 0, 0, Math.PI * 2); ctx.fill();
}

/** 双人秋千（树 + 秋千）。swing 为摆角，seats: 回调在两块座板上画角色。 */
export function swingTree(ctx: C2, x: number, groundY: number, s: number, ang: number, seat: (i: 0 | 1, sx: number, sy: number) => void) {
  // 树干
  ctx.fillStyle = "#7a4a2a"; ctx.fillRect(x - 70 * s, groundY - 150 * s, 14 * s, 150 * s);
  ctx.fillStyle = "#5e3820"; ctx.fillRect(x - 70 * s, groundY - 150 * s, 4 * s, 150 * s);
  // 横枝
  ctx.fillStyle = "#7a4a2a"; ctx.fillRect(x - 70 * s, groundY - 128 * s, 150 * s, 8 * s);
  // 树冠
  for (const [dx, dy, r] of [[-60, -170, 46], [-10, -185, 50], [40, -165, 42], [-95, -145, 32], [70, -140, 30]] as const)
    circle(ctx, x + dx * s, groundY + dy * s, r * s, "#3f9a52");
  for (const [dx, dy, r] of [[-50, -185, 30], [0, -200, 30], [45, -180, 24]] as const) circle(ctx, x + dx * s, groundY + dy * s, r * s, "#5cbf63");
  // 秋千
  const px = x + 15 * s, py = groundY - 120 * s, L = 92 * s;
  const sx = px + Math.sin(ang) * L, sy = py + Math.cos(ang) * L;
  ctx.strokeStyle = "#5b3b25"; ctx.lineWidth = Math.max(1, 1.5 * s);
  ctx.beginPath();
  ctx.moveTo(px - 40 * s, py); ctx.lineTo(sx - 40 * s, sy);
  ctx.moveTo(px + 40 * s, py); ctx.lineTo(sx + 40 * s, sy);
  ctx.moveTo(px, py); ctx.lineTo(sx, sy);
  ctx.stroke();
  ctx.fillStyle = "#c98a4b"; ctx.fillRect(sx - 46 * s, sy - 2 * s, 92 * s, 5 * s);
  seat(0, sx - 22 * s, sy + 2 * s);
  seat(1, sx + 22 * s, sy + 2 * s);
}

/** 圆角老电视。 */
export function tv(ctx: C2, x: number, y: number, w: number, h: number, screen: (sx: number, sy: number, sw: number, sh: number) => void, on = 1) {
  ctx.fillStyle = "#4a3326"; ctx.fillRect(x - 6, y + h + 2, 6, 18); ctx.fillRect(x + w, y + h + 2, 6, 18);
  ctx.fillStyle = "#8a5a3a"; roundRect(ctx, x - 14, y - 14, w + 70, h + 28, 14); ctx.fill();
  ctx.fillStyle = "#6e452c"; roundRect(ctx, x - 14, y + h + 4, w + 70, 10, 4); ctx.fill();
  ctx.fillStyle = "#1a1a24"; roundRect(ctx, x - 4, y - 4, w + 8, h + 8, 12); ctx.fill();
  ctx.save(); roundRect(ctx, x, y, w, h, 10); ctx.clip();
  ctx.fillStyle = "#101018"; ctx.fillRect(x, y, w, h);
  if (on > 0) screen(x, y, w, h);
  // 扫描线 + 玻璃反光
  ctx.fillStyle = "rgba(0,0,0,0.18)"; for (let yy = y; yy < y + h; yy += 3) ctx.fillRect(x, yy, w, 1);
  ctx.fillStyle = "rgba(255,255,255,0.08)"; ctx.beginPath(); ctx.ellipse(x + w * 0.3, y + h * 0.2, w * 0.35, h * 0.12, -0.3, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
  // 旋钮
  circle(ctx, x + w + 30, y + 20, 9, "#d9b36a"); circle(ctx, x + w + 30, y + 20, 4, "#8a6a2a");
  circle(ctx, x + w + 30, y + 50, 9, "#d9b36a"); circle(ctx, x + w + 30, y + 50, 4, "#8a6a2a");
  ctx.fillStyle = "#3c2618"; for (let i = 0; i < 5; i++) ctx.fillRect(x + w + 18, y + 72 + i * 6, 24, 2);
  // 天线
  ctx.strokeStyle = "#555"; ctx.lineWidth = 2; ctx.beginPath();
  ctx.moveTo(x + w / 2, y - 14); ctx.lineTo(x + w / 2 - 40, y - 60); ctx.moveTo(x + w / 2, y - 14); ctx.lineTo(x + w / 2 + 34, y - 64); ctx.stroke();
}

export function roundRect(ctx: C2, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

export function noise(ctx: C2, x: number, y: number, w: number, h: number, t: number) {
  const k = Math.floor(t * 24);
  for (let yy = 0; yy < h; yy += 3) for (let xx = 0; xx < w; xx += 3) {
    const v = rnd(xx * 0.13 + yy * 7.1 + k * 3.3) * 255 | 0;
    ctx.fillStyle = `rgb(${v},${v},${v})`; ctx.fillRect(x + xx, y + yy, 3, 3);
  }
}

/** 钟：angle 为分针角度（弧度），sec 为秒针角度。 */
export function clockFace(ctx: C2, x: number, y: number, r: number, minAng: number, hourAng: number, secAng?: number, ticks = 12) {
  circle(ctx, x, y + 3, r + 6, "rgba(40,30,80,0.25)");
  circle(ctx, x, y, r + 6, "#e86a5a"); circle(ctx, x, y, r, "#fffaf0");
  ctx.fillStyle = "#4a3a6a";
  for (let i = 0; i < ticks; i++) {
    const a = (i / ticks) * Math.PI * 2; const big = ticks === 12 || i % 5 === 0;
    const rr = big ? 3 : 1.5;
    ctx.fillRect(x + Math.sin(a) * r * 0.85 - rr / 2, y - Math.cos(a) * r * 0.85 - rr / 2, rr, rr);
  }
  const hand = (a: number, L: number, w: number, c: string) => {
    ctx.strokeStyle = c; ctx.lineWidth = w; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.sin(a) * L, y - Math.cos(a) * L); ctx.stroke();
  };
  hand(hourAng, r * 0.5, Math.max(2, r * 0.08), "#3a2a5a");
  hand(minAng, r * 0.75, Math.max(1.5, r * 0.05), "#3a2a5a");
  if (secAng !== undefined) hand(secAng, r * 0.85, 1.5, "#e84a4a");
  circle(ctx, x, y, Math.max(2, r * 0.06), "#e84a4a");
}

/** 地球：light 0..1 白昼覆盖比例，rot 自转偏移。 */
export function globe(ctx: C2, x: number, y: number, r: number, rot: number, light: number, flowers = 0, t = 0) {
  ctx.save();
  // 大气光
  const g = ctx.createRadialGradient(x, y, r * 0.9, x, y, r * 1.25);
  g.addColorStop(0, `rgba(140,200,255,${0.25 + light * 0.4})`); g.addColorStop(1, "rgba(140,200,255,0)");
  ctx.fillStyle = g; ctx.fillRect(x - r * 1.4, y - r * 1.4, r * 2.8, r * 2.8);
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.clip();
  ctx.fillStyle = "#2f7fd9"; ctx.fillRect(x - r, y - r, r * 2, r * 2);
  // 大陆：几块像素团，随 rot 平移
  for (let i = 0; i < 14; i++) {
    const cx = x + ((rnd(i) * 3 * r + rot * r) % (3 * r)) - 1.5 * r;
    const cy = y + (rnd(i + 9) - 0.5) * r * 1.6;
    const rr = r * (0.12 + rnd(i + 4) * 0.22);
    circle(ctx, cx, cy, rr, "#4fb85a"); circle(ctx, cx + rr * 0.5, cy - rr * 0.3, rr * 0.7, "#6fcf6a");
    if (flowers > 0) for (let k = 0; k < 4; k++) {
      const f = clamp(flowers * 1.4 - rnd(i * 4 + k) * 0.6);
      if (f > 0) circle(ctx, cx + (rnd(i * 7 + k) - 0.5) * rr * 1.4, cy + (rnd(i * 5 + k) - 0.5) * rr * 1.2, 1.5 * f + 0.5, ["#ff8fb1", "#ffd84a", "#fff", "#c79bff"][k]);
    }
  }
  circle(ctx, x, y - r * 0.92, r * 0.35, "rgba(255,255,255,0.85)"); // 北极
  // 夜面：从下往上被照亮
  const nightA = 1 - light;
  if (nightA > 0) {
    const ng = ctx.createLinearGradient(x, y - r, x, y + r);
    const edge = clamp(light * 1.15);
    ng.addColorStop(0, `rgba(10,16,48,${nightA * 0.1})`);
    ng.addColorStop(Math.max(0.001, edge * 0.95), `rgba(10,16,48,${nightA * 0.25})`);
    ng.addColorStop(Math.min(0.999, edge + 0.05), `rgba(10,16,48,${0.78 * Math.min(1, nightA * 2)})`);
    ng.addColorStop(1, `rgba(10,16,48,${0.85 * Math.min(1, nightA * 2)})`);
    ctx.fillStyle = ng; ctx.fillRect(x - r, y - r, r * 2, r * 2);
    // 夜面城市灯
    for (let i = 0; i < 40; i++) {
      const lx = x + (rnd(i * 3.1) - 0.5) * r * 1.6, ly = y + (rnd(i * 1.7) - 0.2) * r;
      if ((ly - (y - r)) / (2 * r) > edge) star(ctx, lx, ly, 0.5, 0.6 + 0.4 * Math.sin(t * 4 + i));
    }
  }
  // 高光
  circle(ctx, x - r * 0.35, y - r * 0.4, r * 0.35, "rgba(255,255,255,0.08)");
  ctx.restore();
}

/** 漂浮光点。 */
export function motes(ctx: C2, t: number, n: number, color: string, seed = 3, up = 18) {
  for (let i = 0; i < n; i++) {
    const x = (rnd(i + seed) * W + Math.sin(t + i) * 8) % W;
    const y = (rnd(i * 2 + seed) * H - t * up * (0.5 + rnd(i * 3)) + H * 10) % H;
    const a = 0.4 + 0.6 * Math.sin(t * 2 + i);
    ctx.fillStyle = color; ctx.globalAlpha = clamp(a); ctx.fillRect(x, y, 2, 2); ctx.globalAlpha = 1;
  }
}

/** 爱心路径（用于遮罩/图形）。 */
export function heartPath(ctx: C2, x: number, y: number, s: number) {
  ctx.moveTo(x, y + s * 0.35);
  ctx.bezierCurveTo(x - s * 1.2, y - s * 0.45, x - s * 0.55, y - s * 1.25, x, y - s * 0.55);
  ctx.bezierCurveTo(x + s * 0.55, y - s * 1.25, x + s * 1.2, y - s * 0.45, x, y + s * 0.35);
}

export function speedLines(ctx: C2, t: number, n: number, color = "rgba(255,255,255,0.6)", dir = -1) {
  ctx.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const y = rnd(i * 1.3) * H; const L = 30 + rnd(i) * 80;
    const x = ((rnd(i * 2.7) * W * 1.5 + dir * t * (500 + rnd(i) * 400)) % (W * 1.5) + W * 1.5) % (W * 1.5) - W * 0.25;
    ctx.fillRect(x, y, L, 1);
  }
}
