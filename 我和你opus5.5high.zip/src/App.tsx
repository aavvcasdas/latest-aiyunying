import { useCallback, useEffect, useRef, useState } from "react";
import songUrl from "./assets/wohe_ni.mp3";
import fontUrl from "./assets/kuaile.woff";
import genSheetUrl from "./assets/gen_props.png";
import { SHOTS, DURATION, LINES } from "./mv/data";
import { renderFrame, OUT_W, OUT_H, shotAt } from "./mv/render";
import { W, H } from "./mv/paint";
import { spritesReady } from "./mv/sprites";

const fmt = (t: number) => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, "0")}.${String(Math.floor((t % 1) * 10))}`;

const GEN_LIST = [
  ["球鞋", "gen_sneakers", "S07 球鞋"], ["发条机器人", "gen_toy_robot", "S03/S04 玩具"], ["字母积木", "gen_toy_blocks", "S03/S04 玩具"],
  ["皮球", "gen_toy_ball", "S03/S04 玩具"], ["小熊", "gen_toy_bear", "S03/S04 玩具"], ["喷壶", "gen_watering_can", "S19 种花"],
  ["种子包", "gen_seed_packet", "S19 种花"], ["小苗盆栽", "gen_sprout_pot", "备用"], ["小铲子", "gen_trowel", "S19 种花"],
  ["藏宝图", "gen_map", "S11 装满"], ["指南针", "gen_compass", "S11 装满"], ["望远镜", "gen_telescope", "S11/S12"], ["纸飞机", "gen_paper_plane", "S11/S12"],
];

export default function App() {
  const hiRef = useRef<HTMLCanvasElement>(null);
  const lowRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [started, setStarted] = useState(false);
  const [showLyrics, setShowLyrics] = useState(true);
  const [offset, setOffset] = useState(0);
  const [thumbs, setThumbs] = useState<string[]>([]);
  const offsetRef = useRef(0);
  const lyricRef = useRef(true);
  const scrubRef = useRef<number | null>(null);
  offsetRef.current = offset;
  lyricRef.current = showLyrics;

  // 资源就绪：图集、生成道具、字体
  useEffect(() => {
    const ff = new FontFace("KuaiLe", `url(${fontUrl})`);
    Promise.all([spritesReady(), ff.load().then((f) => { document.fonts.add(f); }).catch(() => undefined)]).then(() => {
      const low = document.createElement("canvas"); low.width = W; low.height = H; lowRef.current = low;
      setReady(true);
      // 分镜缩略图：每镜取中点渲一帧
      const hi = document.createElement("canvas"); hi.width = OUT_W; hi.height = OUT_H;
      const th = document.createElement("canvas"); th.width = 320; th.height = 180;
      const lc = low.getContext("2d")!, hc = hi.getContext("2d")!, tc = th.getContext("2d")!;
      const list = SHOTS.map((s) => {
        const T = s.id === "S01" ? 1.6 : s.id === "S24" ? s.end - 0.2 : s.id === "S33" ? s.start + 1.6 : (s.start + s.end) / 2 + 0.15;
        renderFrame(lc, hc, T, true);
        tc.drawImage(hi, 0, 0, 320, 180);
        return th.toDataURL("image/jpeg", 0.82);
      });
      setThumbs(list);
    });
  }, []);

  // 主循环
  useEffect(() => {
    if (!ready) return;
    let raf = 0;
    const loop = () => {
      const a = audioRef.current, hi = hiRef.current, low = lowRef.current;
      if (a && hi && low) {
        const T = scrubRef.current ?? a.currentTime + offsetRef.current;
        renderFrame(low.getContext("2d")!, hi.getContext("2d")!, Math.max(0, T), lyricRef.current);
        setTime(scrubRef.current ?? a.currentTime);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [ready]);

  const toggle = useCallback(() => {
    const a = audioRef.current; if (!a) return;
    setStarted(true);
    if (a.paused) { if (a.ended || a.currentTime >= DURATION - 0.05) a.currentTime = 0; a.play(); } else a.pause();
  }, []);

  const seek = (t: number) => {
    const a = audioRef.current; if (!a) return;
    a.currentTime = Math.max(0, Math.min(DURATION - 0.01, t));
    setTime(a.currentTime);
  };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === "INPUT") return;
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      if (e.code === "ArrowRight") seek((audioRef.current?.currentTime ?? 0) + 2);
      if (e.code === "ArrowLeft") seek((audioRef.current?.currentTime ?? 0) - 2);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [toggle]);

  const cur = shotAt(time + offset);
  const curShot = SHOTS[cur];
  const fullscreen = () => wrapRef.current?.requestFullscreen?.();

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,#2b3a8f_0%,#171b45_45%,#0d0f26_100%)] text-white">
      <audio ref={audioRef} src={songUrl} preload="auto" onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)} />

      <header className="mx-auto max-w-6xl px-4 pt-8 pb-4 text-center">
        <p className="text-sm tracking-[0.3em] text-sky-300/80">番外MV · 童年动画片主题曲</p>
        <h1 className="mt-2 text-4xl md:text-5xl font-black" style={{ fontFamily: "KuaiLe, sans-serif" }}>
          <span className="bg-gradient-to-b from-yellow-200 to-orange-400 bg-clip-text text-transparent">《我和你》</span>
        </h1>
        <p className="mt-2 text-sm text-indigo-200/80">本鲸 × 小克 · 八位像素 AI 娘 · 33 镜 / 一词一镜 / 60.4 秒 · 全程序化场景，无背景图</p>
      </header>

      <main className="mx-auto max-w-6xl px-4">
        <div ref={wrapRef} className="relative mx-auto aspect-video w-full overflow-hidden rounded-2xl bg-black shadow-[0_20px_80px_-20px_rgba(80,140,255,0.6)] ring-1 ring-white/10">
          <canvas ref={hiRef} width={OUT_W} height={OUT_H} className="h-full w-full [image-rendering:pixelated] cursor-pointer" onClick={toggle} />
          {!started && (
            <button onClick={toggle} disabled={!ready}
              className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-[#0d0f26]/55 backdrop-blur-[2px] transition hover:bg-[#0d0f26]/40">
              <span className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-b from-yellow-300 to-orange-500 text-4xl text-white shadow-xl ring-4 ring-white/70">
                {ready ? "▶" : "…"}
              </span>
              <span className="text-lg font-bold drop-shadow" style={{ fontFamily: "KuaiLe, sans-serif" }}>{ready ? "点击播放 MV（带音乐）" : "加载图集中…"}</span>
            </button>
          )}
        </div>

        {/* 控制条：在画面外，不进画面 */}
        <div className="mx-auto mt-3 flex flex-wrap items-center gap-3 rounded-xl bg-white/5 px-4 py-3 ring-1 ring-white/10">
          <button onClick={toggle} className="rounded-lg bg-gradient-to-b from-yellow-300 to-orange-500 px-4 py-1.5 font-bold text-[#2a1f55]">{playing ? "❚❚ 暂停" : "▶ 播放"}</button>
          <span className="w-28 font-mono text-sm text-indigo-100">{fmt(time)} / {fmt(DURATION)}</span>
          <input type="range" min={0} max={DURATION} step={0.01} value={time} className="min-w-[160px] flex-1 accent-orange-400"
            onChange={(e) => { scrubRef.current = +e.target.value; seek(+e.target.value); }}
            onPointerUp={() => { scrubRef.current = null; }} onKeyUp={() => { scrubRef.current = null; }} />
          <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={showLyrics} onChange={(e) => setShowLyrics(e.target.checked)} /> 歌词</label>
          <label className="flex items-center gap-1 text-sm" title="若觉得画面和歌声没对齐，可微调">
            卡点微调
            <input type="number" step={0.05} value={offset} onChange={(e) => setOffset(+e.target.value)} className="w-16 rounded bg-white/10 px-1 text-right" />s
          </label>
          <button onClick={fullscreen} className="rounded-lg bg-white/10 px-3 py-1.5 text-sm hover:bg-white/20">⛶ 全屏</button>
        </div>

        <div className="mt-3 rounded-xl bg-white/5 px-4 py-3 text-sm ring-1 ring-white/10">
          <span className="mr-2 rounded bg-orange-400 px-2 py-0.5 font-mono text-xs font-bold text-[#2a1f55]">{curShot.id}</span>
          <b className="text-yellow-200">「{curShot.word}」</b> <span className="text-indigo-100">{curShot.title}</span>
          <span className="ml-2 text-indigo-300/80">— {curShot.desc}</span>
        </div>

        {/* 歌词理解 */}
        <section className="mt-10 grid gap-4 md:grid-cols-3">
          {[
            ["主歌 · 一个人的晴天", "天气很好，可心里空。玩具、电视、球鞋——童年的三件宝贝都留不住她：玩具被冷落、电视在重播、跑也跑不过时间。孤单不是哭，是一张双人秋千只坐了一个。"],
            ["转折 · 我要 / 当然", "「我要」是第一次主动开口，世界被镜头一路拉大成一颗星球；「当然你陪在身边」是不用问的答案——小克走进画面，那半边秋千终于坐满。每秒每天，是陪伴被时间计数。"],
            ["副歌 · 从「做」到「是」", "第一段副歌是动词：飞、种、分享——两个人一起做事；第二段换成比喻：「就像」花园、「就像」光线——大家本身就是花、就是光。最后八道光汇成一束，把地球照亮，回到开头那个晴天。"],
          ].map(([h, p]) => (
            <div key={h} className="rounded-2xl bg-gradient-to-b from-white/10 to-white/5 p-5 ring-1 ring-white/10">
              <h3 className="text-lg font-bold text-yellow-200" style={{ fontFamily: "KuaiLe, sans-serif" }}>{h}</h3>
              <p className="mt-2 text-sm leading-relaxed text-indigo-100/90">{p}</p>
            </div>
          ))}
        </section>

        {/* 分镜表 */}
        <section className="mt-12">
          <h2 className="text-2xl font-bold" style={{ fontFamily: "KuaiLe, sans-serif" }}>分镜表 · 一词一镜（点击跳转）</h2>
          <p className="mt-1 text-sm text-indigo-300/80">卡点按 我和你.WAV 实测：138 BPM（拍长 0.4346 s），首拍 0.56 s，每句 8 拍。每个镜头按该词本身的意思重造画面。</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SHOTS.map((s, i) => (
              <button key={s.id} onClick={() => { seek(s.start + 0.02 - offset); setStarted(true); }}
                className={`group overflow-hidden rounded-2xl text-left ring-1 transition hover:-translate-y-0.5 ${i === cur ? "bg-orange-400/15 ring-orange-300" : "bg-white/5 ring-white/10 hover:ring-white/30"}`}>
                <div className="relative aspect-video bg-black/40">
                  {thumbs[i] ? <img src={thumbs[i]} alt={s.word} className="h-full w-full object-cover [image-rendering:pixelated]" /> :
                    <div className="flex h-full items-center justify-center text-xs text-white/40">渲染中…</div>}
                  <span className="absolute left-2 top-2 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[11px]">{s.id} · {s.start.toFixed(2)}–{s.end.toFixed(2)}s</span>
                </div>
                <div className="p-4">
                  <div className="flex items-baseline gap-2">
                    <b className="text-lg text-yellow-200" style={{ fontFamily: "KuaiLe, sans-serif" }}>「{s.word}」</b>
                    <span className="text-sm text-indigo-100">{s.title}</span>
                  </div>
                  <p className="mt-1 text-[11px] text-sky-300/80">登场：{s.cast}</p>
                  <p className="mt-2 text-sm leading-relaxed text-indigo-100/90">{s.desc}</p>
                  <p className="mt-2 border-l-2 border-orange-300/60 pl-2 text-xs leading-relaxed text-orange-100/80">为什么这样拍：{s.why}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* 歌词时间轴 */}
        <section className="mt-12 rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
          <h2 className="text-xl font-bold" style={{ fontFamily: "KuaiLe, sans-serif" }}>歌词卡点</h2>
          <div className="mt-3 grid gap-x-6 gap-y-1 font-mono text-sm sm:grid-cols-2">
            {LINES.map((l, i) => (
              <div key={i} className="flex gap-3 text-indigo-100/90"><span className="w-28 text-sky-300/80">{l.start.toFixed(2)}–{l.end.toFixed(2)}</span><span>{l.words.join(" ／ ")}</span></div>
            ))}
          </div>
        </section>

        {/* 生成道具交付 */}
        <section className="mt-12 rounded-2xl bg-white/5 p-5 ring-1 ring-white/10">
          <h2 className="text-xl font-bold" style={{ fontFamily: "KuaiLe, sans-serif" }}>新增道具（分镜必需才生成 · 无背景图）</h2>
          <p className="mt-1 text-sm text-indigo-300/80">图集里没有的四类道具：球鞋、玩具、种花工具、探险用品。按项目 Q 版像素口径绿幕生成 → 抠绿 → 缩到图集同尺度。人物全部用原图集，没有新增人物。打包在 <code className="text-orange-200">交付/我和你_新增素材.zip</code>，说明见包内 README.md。</p>
          <div className="mt-4 rounded-xl bg-[repeating-conic-gradient(#ffffff14_0%_25%,transparent_0%_50%)] [background-size:16px_16px] p-4">
            <img src={genSheetUrl} alt="生成道具合图" className="mx-auto w-full max-w-3xl [image-rendering:pixelated]" />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 text-xs sm:grid-cols-3 lg:grid-cols-5">
            {GEN_LIST.map(([n, k, u]) => (
              <div key={k} className="rounded-lg bg-black/20 px-3 py-2"><b className="text-yellow-100">{n}</b><div className="font-mono text-[10px] text-sky-300/80">{k}</div><div className="text-indigo-200/70">{u}</div></div>
            ))}
          </div>
        </section>

        <footer className="py-10 text-center text-xs leading-relaxed text-indigo-300/60">
          角色形象源自 ZipZipPipe《大AI和小AI们》（CC BY-NC-SA 4.0），像素图集沿用 latest-aiyunying 项目 · 角色关系与桥段为本系列原创（ⓞ），不代表任何公司设定 · 歌曲录音授权请自行核对
        </footer>
      </main>
    </div>
  );
}
