// 从 src/mv/data.ts 导出 分镜表.md / 歌词.srt / 卡点.json（文案和代码同源，不手抄）。
import fs from "fs";
import { SHOTS, LINES, BEAT, BAR, LINE, T0, DURATION, END_VOCAL } from "../src/mv/data";
const out = process.argv[2] || "交付/tmp";
fs.mkdirSync(out, { recursive: true });
const ts = (t: number) => { const ms = Math.round(t * 1000); const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60; return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")},${String(ms % 1000).padStart(3, "0")}`; };
fs.writeFileSync(`${out}/歌词.srt`, LINES.map((l, i) => `${i + 1}\n${ts(l.start)} --> ${ts(l.end - 0.05)}\n${l.words.join(" ")}\n`).join("\n"));
fs.writeFileSync(`${out}/卡点.json`, JSON.stringify({
  audio: "我和你.WAV", duration: DURATION, measured: true,
  method: "低频起音包络自相关 + 拍网格最小二乘拟合（279 个起音点）",
  bpm: +(60 / BEAT).toFixed(2), beat: BEAT, bar: BAR, line: LINE, firstBeat: T0, vocalEnd: END_VOCAL,
  note: "逐句起点按 8 拍一句推得；网页预览里有「卡点微调」可整体平移，若人耳校准后有偏差，请改 data.ts 的 T0",
  lines: LINES.map((l) => ({ text: l.words.join(" "), start: +l.start.toFixed(3), end: +l.end.toFixed(3) })),
  shots: SHOTS.map((s) => ({ id: s.id, word: s.word, start: +s.start.toFixed(3), end: +s.end.toFixed(3), frame24: Math.round(s.start * 24) })),
}, null, 2));
let md = `# 《我和你》分镜表（${SHOTS.length} 镜 · 一词一镜）\n\n场景全部程序化绘制（Canvas2D，640×360 低清画布最近邻放大到 1280×720），**没有背景图**。人物只用项目图集里的 Q 版像素格；图集缺的道具按分镜需要生成，见 \`人物/生成/我和你_道具/\`。\n\n卡点：138.06 BPM（拍长 ${BEAT} s），首拍 ${T0} s，一句 8 拍 = ${LINE.toFixed(3)} s。\n\n`;
for (const s of SHOTS) md += `### ${s.id} · ${s.title}（${s.start.toFixed(2)}–${s.end.toFixed(2)} 秒，第 ${Math.round(s.start * 24)} 帧起）\n\n- **词**：「${s.word}」\n- **画面**：${s.desc}\n- **角色**：${s.cast}\n- **为什么这样拍**：${s.why}\n\n`;
fs.writeFileSync(`${out}/分镜表.md`, md);
console.log("docs ->", out);
