// 绿幕道具 → 透明底像素小图 + 合图。用法：node tools/key_props.cjs
const fs=require("fs"),{PNG}=require("pngjs");
const SRC={sneakers:{grid:1,names:["sneakers"],size:[76]},
 toys:{grid:2,names:["toy_robot","toy_blocks","toy_ball","toy_bear"],size:[46,46,40,48]},
 garden:{grid:2,names:["watering_can","seed_packet","sprout_pot","trowel"],size:[44,38,38,38]},
 explore:{grid:2,names:["map","compass","telescope","paper_plane"],size:[44,34,42,40]}};
const isGreen=(r,g,b)=>g>120&&g>r*1.35&&g>b*1.35;
const out={};
for(const [file,cfg] of Object.entries(SRC)){
  const img=PNG.sync.read(fs.readFileSync(`gen/raw/${file}.png`));const {width:W,height:H,data}=img;
  const cells=[];for(let gy=0;gy<cfg.grid;gy++)for(let gx=0;gx<cfg.grid;gx++)cells.push([gx*W/cfg.grid|0,gy*H/cfg.grid|0,(gx+1)*W/cfg.grid|0,(gy+1)*H/cfg.grid|0]);
  cells.forEach((c,ci)=>{
    let x0=1e9,y0=1e9,x1=-1,y1=-1;
    for(let y=c[1]+4;y<c[3]-4;y++)for(let x=c[0]+4;x<c[2]-4;x++){const i=(y*W+x)*4;if(!isGreen(data[i],data[i+1],data[i+2])){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}}
    const bw=x1-x0+1,bh=y1-y0+1;const target=cfg.size[ci];const sc=target/Math.max(bw,bh);
    const ow=Math.max(1,Math.round(bw*sc)),oh=Math.max(1,Math.round(bh*sc));const o=new PNG({width:ow,height:oh});
    for(let oy=0;oy<oh;oy++)for(let ox=0;ox<ow;ox++){
      let r=0,g=0,b=0,n=0,tot=0;const sx0=x0+ox/sc,sy0=y0+oy/sc,sx1=x0+(ox+1)/sc,sy1=y0+(oy+1)/sc;
      for(let y=Math.floor(sy0);y<Math.ceil(sy1);y++)for(let x=Math.floor(sx0);x<Math.ceil(sx1);x++){const i=(y*W+x)*4;tot++;if(!isGreen(data[i],data[i+1],data[i+2])){r+=data[i];g+=data[i+1];b+=data[i+2];n++;}}
      const j=(oy*ow+ox)*4;if(n/tot>=0.45){r/=n;g/=n;b/=n;if(g>r&&g>b)g=Math.max(r,b);// 去绿边
        o.data[j]=r;o.data[j+1]=g;o.data[j+2]=b;o.data[j+3]=255;}else o.data[j+3]=0;}
    const name=cfg.names[ci];fs.writeFileSync(`gen/props/${name}.png`,PNG.sync.write(o));out[name]=o;
  });
}
// 合图：一行排开，间隔 2px
const names=Object.keys(out);const SW=names.reduce((s,n)=>s+out[n].width+2,2),SH=Math.max(...names.map(n=>out[n].height))+4;
const sheet=new PNG({width:SW,height:SH});const rects={};let x=2;
for(const n of names){const p=out[n];for(let y=0;y<p.height;y++)for(let xx=0;xx<p.width;xx++){const s=(y*p.width+xx)*4,d=((y+2)*SW+x+xx)*4;for(let k=0;k<4;k++)sheet.data[d+k]=p.data[s+k];}rects["gen_"+n]=[x,2,p.width,p.height];x+=p.width+2;}
fs.writeFileSync("gen/gen_props.png",PNG.sync.write(sheet));fs.writeFileSync("gen/gen_props.json",JSON.stringify({image:"gen_props.png",w:SW,h:SH,rects},null,1));
console.log(SW,SH,rects);
