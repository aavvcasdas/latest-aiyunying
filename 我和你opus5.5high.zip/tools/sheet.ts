// 分镜总览：node 里逐镜渲一帧拼成一张图（审片用）。
import { createCanvas, Image as NImage, GlobalFonts } from "@napi-rs/canvas";
import fs from "fs";
(globalThis as any).Image = function () {
  const im: any = new NImage();
  const desc = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(im), "src")!;
  Object.defineProperty(im, "src", { set(v: string) { desc.set!.call(im, Buffer.from(v.split(",")[1], "base64")); }, get() { return desc.get!.call(im); } });
  return im;
};
const { SHOTS } = await import("../src/mv/data");
const { renderFrame, OUT_W, OUT_H } = await import("../src/mv/render");
const { W, H } = await import("../src/mv/paint");
GlobalFonts.registerFromPath("/tmp/kuaile.woff", "KuaiLe");
const times = (process.env.TIMES || "").split(",").filter(Boolean).map(Number);
const list = times.length ? times.map((T) => ({ id: "t" + T, T })) : SHOTS.map((s) => ({ id: s.id, T: (s.start + s.end) / 2 + 0.15 }));
const cols = 4, tw = 400, th = 225, rows = Math.ceil(list.length / cols);
const sheet = createCanvas(cols * tw, rows * (th + 18)); const sc = sheet.getContext("2d");
sc.fillStyle = "#111"; sc.fillRect(0, 0, sheet.width, sheet.height);
const low = createCanvas(W, H), hi = createCanvas(OUT_W, OUT_H);
list.forEach((it, i) => {
  // 替换 drawImage 源为 napi Image
  renderFrame(low.getContext("2d") as any, hi.getContext("2d") as any, it.T, true);
  const x = (i % cols) * tw, y = Math.floor(i / cols) * (th + 18);
  sc.drawImage(hi, x, y + 18, tw, th);
  sc.fillStyle = "#fff"; sc.font = "13px sans-serif"; sc.fillText(`${it.id} @${it.T.toFixed(2)}`, x + 4, y + 13);
});
fs.writeFileSync(process.env.OUT || "gen/_sheet.png", sheet.toBuffer("image/png"));
console.log("ok", list.length);
