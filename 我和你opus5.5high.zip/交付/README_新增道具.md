# 《我和你》新增道具（生成）

> 只在分镜里**必须出现、而图集没有**的东西才生成；**没有生成任何背景图**，也**没有新增人物**——八位角色全部用 `人物/atlas.png` 原有的 Q 版像素格。

## 放哪
解压到仓库根目录即可，本目录落在 `人物/生成/我和你_道具/`：

| 文件 | 是什么 |
|---|---|
| `raw/*.png` | 绿幕原图（1024 级，四张：球鞋 / 玩具 2×2 / 种花工具 2×2 / 探险用品 2×2） |
| `props/*.png` | 抠绿 + 缩到图集尺度的单件透明 PNG（13 件） |
| `gen_props.png` + `gen_props.json` | 13 件合成一行的小图集（538×52）与矩形表 `{name: [x, y, w, h]}`，帧名统一 `gen_` 前缀，不会和母版 `prop_*` 撞名 |
| `key_props.cjs` | 抠绿/切格/缩放/合图脚本：`npm i -D pngjs && node key_props.cjs`（在本目录运行，路径按 `gen/raw` → 自行改成 `raw`） |
| `提示词.txt` | 四张图的提示词，口径照 `人物/提示词/00_通用规则.txt` |

## 每件用在哪个镜头
| 帧名 | 道具 | 镜头 |
|---|---|---|
| gen_sneakers | 蓝色帆布球鞋（鞋侧小鲸尾） | S07「球鞋」 |
| gen_toy_robot / gen_toy_blocks / gen_toy_ball / gen_toy_bear | 发条机器人 / 字母积木 / 皮球 / 小熊 | S03「玩具」、S04「丢在旁边」 |
| gen_watering_can / gen_seed_packet / gen_trowel | 喷壶 / 向日葵种子包 / 小铲子 | S19「我和你」（种花） |
| gen_sprout_pot | 小苗盆栽 | 备用 |
| gen_map / gen_compass / gen_telescope / gen_paper_plane | 藏宝图 / 指南针 / 望远镜 / 纸飞机 | S11「装满」、S12「不同的探险」 |

## 接进引擎
- Vite 单页线（本片的做法）：把 `gen_props.png` 放进 `源码/src/assets/`，`gen_props.json` 的 rects 与 `atlasData.ts` 的 `RECTS` 并列查表（见 `番外MV/我和你_童年动画/源码/src/mv/sprites.ts` 的 `frame()`：先查 `RECTS`，查不到再查 `gen_`）。
- 模板线（`通用模板/engine`）：若要烘进母版，按 `人物动作替换.md` 的「像素道具」流程重烘图集；帧名保持 `gen_*`。

## 边界
- 抠图阈值：`g > 120 && g > 1.35r && g > 1.35b` 视为绿幕；缩放时覆盖率 ≥ 45% 才保留像素（硬边、无半透明），残留绿边做了去溢色。
- 这批是**道具**，不是角色形象，不涉及 ZipZipPipe 原设定；按仓库口径仍标 AI 生成来源，公开发布时在发布页注明。
