import whaleFull from "./assets/whale-full.jpg";
import sheet1 from "./assets/expr-sheet-1.jpg";
import sheet2 from "./assets/expr-sheet-2.jpg";
import detailLimbs from "./assets/detail-limbs.jpg";
import deepsea from "./assets/deepsea.jpg";
import expressionsGif from "./assets/whale-expressions.gif";

export const SRC = { whaleFull, sheet1, sheet2, detailLimbs, deepsea, expressionsGif };

export const META = {
  branch: "arena/786ec221-latest-aiyunying",
  repo: "aavvcasdas/latest-aiyunying",
  doc: "docs/通用角色与模板_半成品修改说明.md",
  date: "2026-11-26",
  status: "半成品 · 未人工签收",
  rig: "npm run rig:preview",
};

export const cx = (...v: (string | false | null | undefined)[]) => v.filter(Boolean).join(" ");

/* ---------------------------------------------------------------- diagnosis */

export const DIAGNOSIS = [
  {
    no: "01",
    symptom: "手脚是软的",
    cause: "整条手臂被当作一根横带形变，掌端与鞋尖没有独立刚性骨段，一弯就被拉长、糊成面条。",
    fix: "新原画按肩-肘-腕-掌、髋-膝-踝-鞋尖成型；掌端五指与鞋底硬边单独重绘，关节用局部盖片补画而非拉伸。",
  },
  {
    no: "02",
    symptom: "面部表情是奇怪的表情",
    cause: "在「去眼去嘴」底图上二次叠加五官，残留第二条嘴线，肤色被采样改偏，五官比例失准。",
    fix: "本轮全部表情改用正面独立头像，单格单表情、无残留嘴线、肤色统一，六种与代码 key 一一对应。",
  },
  {
    no: "03",
    symptom: "只有单一静态脸",
    cause: "模板六表情由 rigid-character.ts 每帧同步绘制，仓库里没有可核对的图像参考，无法验收。",
    fix: "交付 12 格表情源表 + 12 帧 GIF（六种已接线 key + 六种扩展），并附逐格 PNG 导出。",
  },
];

/* -------------------------------------------------------------- expressions */

export type Expr = {
  key: string;
  zh: string;
  sheet: 1 | 2;
  col: 0 | 1 | 2;
  row: 0 | 1;
  wired: boolean;
  note: string;
};

/** 顺序与 whale-expressions.gif 的帧序完全一致。 */
export const EXPRESSIONS: Expr[] = [
  { key: "neutral", zh: "平静", sheet: 1, col: 0, row: 0, wired: true, note: "闭口浅笑，眼睑放松" },
  { key: "happy", zh: "喜", sheet: 1, col: 1, row: 0, wired: true, note: "睁眼张口，高光全开" },
  { key: "joy", zh: "乐", sheet: 1, col: 1, row: 1, wired: true, note: "月牙闭眼，露齿大笑" },
  { key: "surprised", zh: "惊讶", sheet: 1, col: 2, row: 1, wired: true, note: "圆睁上扬，小圆口" },
  { key: "shy", zh: "害羞", sheet: 2, col: 0, row: 0, wired: false, note: "重腮红，视线侧移" },
  { key: "smug", zh: "得意", sheet: 2, col: 0, row: 1, wired: false, note: "半眼上挑，单侧嘴角" },
  { key: "love", zh: "爱心", sheet: 2, col: 1, row: 1, wired: false, note: "心形高光填满虹膜" },
  { key: "sleepy", zh: "困", sheet: 2, col: 1, row: 0, wired: false, note: "半垂眼，小哈欠" },
  { key: "flustered", zh: "慌", sheet: 2, col: 2, row: 0, wired: false, note: "汗滴，波浪嘴" },
  { key: "angry", zh: "怒", sheet: 1, col: 2, row: 0, wired: true, note: "压眉，噘嘴" },
  { key: "sad", zh: "哀", sheet: 1, col: 0, row: 1, wired: true, note: "下垂眼，噙泪" },
  { key: "tearful", zh: "哭泣", sheet: 2, col: 2, row: 1, wired: false, note: "两道泪流，颤唇" },
];

/* ----------------------------------------------------------------- manifest */

export type Act = "新增" | "覆盖" | "重跑" | "更新";
export type Row = { g: "A" | "B" | "C"; path: string; note: string; src: string; act: Act };

export const GROUPS: Record<"A" | "B" | "C", { title: string; sub: string }> = {
  A: { title: "直接落地", sub: "覆盖 / 新增即可用，不触发现有切图与绑定" },
  B: { title: "覆盖源图 + 重跑工具", sub: "换原画后必须重切四肢、重标关节点" },
  C: { title: "记录与版本", sub: "提示词、哈希记录与签收状态" },
};

export const ROWS: Row[] = [
  {
    g: "A",
    path: "通用模板/engine/assets/rigid/whale/expressions.gif",
    note: "12 帧表情演示 GIF · 400×400 · 0.5s/帧 · 无限循环",
    src: "whale-expressions.gif",
    act: "新增",
  },
  {
    g: "A",
    path: "docs/prompts/本鲸_表情集_表1.jpg",
    note: "已接线六表情源表 neutral·happy·angry·sad·joy·surprised",
    src: "expr-sheet-1.jpg",
    act: "新增",
  },
  {
    g: "A",
    path: "docs/prompts/本鲸_表情集_表2.jpg",
    note: "扩展六表情源表 shy·sleepy·flustered·smug·love·tearful",
    src: "expr-sheet-2.jpg",
    act: "新增",
  },
  {
    g: "A",
    path: "docs/prompts/本鲸_手脚细节参考.jpg",
    note: "掌端五指 / 鞋尖接地两张细节对照",
    src: "detail-limbs.jpg",
    act: "新增",
  },
  {
    g: "A",
    path: "docs/prompts/本鲸_深海分镜参考.jpg",
    note: "深海光束分镜底图，可用于封面与转场",
    src: "deepsea.jpg",
    act: "新增",
  },
  {
    g: "B",
    path: "paperdoll/assets/whale-regenerated.png",
    note: "全身原画：手脚有骨有形，掌端五指与鞋底不再软塌",
    src: "whale-full.jpg → 转 PNG",
    act: "覆盖",
  },
  {
    g: "B",
    path: "paperdoll/assets/whale-face-cleanplate-v2.png",
    note: "去眼去嘴面部底图，取表1 neutral 格重绘，禁止残留第二条嘴线",
    src: "expr-sheet-1.jpg cell(0,0)",
    act: "覆盖",
  },
  {
    g: "B",
    path: "paperdoll/assets/cutout/{arm,leg}_{R,L}.png",
    note: "四肢分层是切图脚本的输入，须按新原画重新切层",
    src: "手工切层",
    act: "重跑",
  },
  {
    g: "B",
    path: "通用模板/engine/assets/rigid/whale/*.png + bind.json",
    note: "脚本输出：15 张运行时纹理 + 关节点 / 脸部锚点 / 地面高度",
    src: "人物/立绘/tools/prepare-rigid-whale.py",
    act: "重跑",
  },
  {
    g: "B",
    path: "通用模板/engine/assets/rigid/whale/provenance.json",
    note: "来源与哈希由脚本自动写入，模型 / 版本 / seed 如实记 unknown",
    src: "同上",
    act: "重跑",
  },
  {
    g: "C",
    path: "docs/prompts/本鲸_图片生成提示词与资产对应.md",
    note: "追加本轮英文工具输入原文与资产对应关系",
    src: "本轮输入",
    act: "更新",
  },
  {
    g: "C",
    path: "assets.manifest.json",
    note: "刷新可更新版本记录，新增表情资产会被自动发现",
    src: "npm run assets:write",
    act: "更新",
  },
  {
    g: "C",
    path: "docs/quality_comparison/human_sign_off.md",
    note: "补记本轮交付，签收状态仍为「未签收」",
    src: "人工",
    act: "更新",
  },
];

export const STEPS = [
  {
    n: "01",
    title: "落地 A 组：直接可用的新增资产",
    body: "不改任何现有像素，缺目录就建目录。",
    cmd: `mkdir -p "通用模板/engine/assets/rigid/whale" "docs/prompts"
cp whale-expressions.gif "通用模板/engine/assets/rigid/whale/expressions.gif"
cp expr-sheet-1.jpg "docs/prompts/本鲸_表情集_表1.jpg"
cp expr-sheet-2.jpg "docs/prompts/本鲸_表情集_表2.jpg"
cp detail-limbs.jpg "docs/prompts/本鲸_手脚细节参考.jpg"
cp deepsea.jpg       "docs/prompts/本鲸_深海分镜参考.jpg"`,
  },
  {
    n: "02",
    title: "覆盖 B 组：原画与面部底图",
    body: "新原画是 1024×1536，切图脚本的画布与 CHAINS 关节点写死为 912×1136，必须先对齐再覆盖。",
    cmd: `# 先把新原画重排到 912×1136 生产画布，再覆盖
cp whale-full.png "paperdoll/assets/whale-regenerated.png"`,
  },
  {
    n: "03",
    title: "重标关节点并重跑切图",
    body: "prepare-rigid-whale.py 内的 CHAINS 常量与 mgrid[:1136,:912] 按旧原画标注，换图后必须重新标注肩/肘/腕/掌、髋/膝/踝/鞋尖，再运行。",
    cmd: `# 编辑 人物/立绘/tools/prepare-rigid-whale.py 中的 CHAINS
python3 人物/立绘/tools/prepare-rigid-whale.py`,
  },
  {
    n: "04",
    title: "刷新版本记录并回归",
    body: "assets.manifest.json 是可更新版本记录，--strict 用于审计。",
    cmd: `npm run assets:write
npm run typecheck && npm test
node tools/check_rigid_character.mjs
npm run rig:preview   # 5173 端口 /rig.html 逐帧核对掌端与鞋尖`,
  },
];

export const CAVEATS = [
  "本轮为图片工具调用，模型、版本与 seed 均未提供，按仓库规则如实记为 unknown，不承诺同提示词逐像素复现。",
  "两张表情源表来自两次独立调用，同一份角色描述但不是同一张底图，跨格存在轻微发饰与发丝差异。",
  "表情集是图像参考，不等于 rigid-character.ts 的路径绘制已逐格对齐；对齐仍需人工在 rig:preview 上核对。",
  "换原画即作废现有 12 段骨段纹理与 bind.json 关节点，未重跑前不要提交「手脚已修好」的结论。",
  "human_sign_off.md 状态仍为未签收，本交付不改变半成品定性。",
];

export const FILES = [
  { name: "whale-full.jpg", label: "本鲸全身原画（修复后）", dim: "1024×1536", bytes: 202706, sha: "38ae2576df417e99", url: whaleFull },
  { name: "expr-sheet-1.jpg", label: "表情源表 · 已接线六表情", dim: "1536×1024", bytes: 320762, sha: "2378ebd9bda92a65", url: sheet1 },
  { name: "expr-sheet-2.jpg", label: "表情源表 · 扩展六表情", dim: "1536×1024", bytes: 342716, sha: "6c200ae979e6f35a", url: sheet2 },
  { name: "detail-limbs.jpg", label: "手掌 / 鞋尖细节对照", dim: "1536×1024", bytes: 142823, sha: "93cc1410ba0fd94a", url: detailLimbs },
  { name: "deepsea.jpg", label: "深海光束分镜底图", dim: "1672×941", bytes: 122810, sha: "ea528b26cb270631", url: deepsea },
  { name: "whale-expressions.gif", label: "12 帧表情循环 GIF", dim: "400×400 ×12", bytes: 856752, sha: "23e668995714878a", url: expressionsGif },
];

export const fmtBytes = (b: number) =>
  b >= 1024 * 1024 ? `${(b / 1048576).toFixed(2)} MB` : `${Math.round(b / 1024)} KB`;

/* ------------------------------------------------- agent-facing markdown doc */

export const DOC_NAME = "本鲸_重新生成与替换说明.md";

export const REPLACEMENT_DOC = `# 本鲸：重新生成与替换说明

- 日期：${META.date}
- 分支：\`${META.branch}\`
- 仓库：\`${META.repo}\`
- 关联文档：\`${META.doc}\`
- **状态：半成品 · 未人工签收。本文件不改变该状态。**

## 一、为什么要重做

| 症状 | 原因 | 本次处理 |
|---|---|---|
${DIAGNOSIS.map((d) => `| ${d.symptom} | ${d.cause} | ${d.fix} |`).join("\n")}

## 二、交付文件

| 文件 | 内容 | 尺寸 | 字节 | sha256(前16) |
|---|---|---|---|---|
${FILES.map((f) => `| \`${f.name}\` | ${f.label} | ${f.dim} | ${f.bytes} | \`${f.sha}\` |`).join("\n")}

模型、版本与 seed 图片工具均未提供，按仓库规则记为 **unknown**，不承诺同提示词逐像素复现。

## 三、替换清单

${(["A", "B", "C"] as const)
  .map(
    (g) =>
      `### ${g} 组 · ${GROUPS[g].title}\n\n${GROUPS[g].sub}\n\n| 仓库路径 | 来源 | 操作 | 说明 |\n|---|---|---|---|\n` +
      ROWS.filter((r) => r.g === g)
        .map((r) => `| \`${r.path}\` | \`${r.src}\` | ${r.act} | ${r.note} |`)
        .join("\n"),
  )
  .join("\n\n")}

## 四、执行顺序

\`\`\`bash
${STEPS.map((s) => `# ${s.n} ${s.title}\n${s.cmd}`).join("\n\n")}
\`\`\`

## 五、表情 key 对照

模板 \`expression()\` 支持 \`neutral | happy | angry | sad | joy | surprised\` 六个已接线 key。
本轮表情源表按 **3 列 × 2 行** 排布，第 1 张表即六种已接线表情，第 2 张为扩展参考。

| # | key | 中文 | 源表 | 单元格 | 状态 | 描述 |
|---|---|---|---|---|---|---|
${EXPRESSIONS.map(
  (e, i) =>
    `| ${String(i + 1).padStart(2, "0")} | \`${e.key}\` | ${e.zh} | 表${e.sheet} | (${e.col},${e.row}) | ${e.wired ? "已接线" : "扩展"} | ${e.note} |`,
).join("\n")}

GIF \`whale-expressions.gif\` 共 12 帧，帧序与上表从上到下完全一致，400×400，0.5s/帧，无限循环。
逐格 PNG 可在交付页上按 key 导出，文件名 \`whale_face_<key>.png\`，裁切口径与 ImageMagick 的 \`-crop 3x2@ -shave 6x6\` 一致。

## 六、边界

${CAVEATS.map((c, i) => `${i + 1}. ${c}`).join("\n")}
`;
