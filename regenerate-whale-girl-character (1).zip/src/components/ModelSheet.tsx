import { DIAGNOSIS, META, SRC, cx } from "../data";

const CALLOUTS = [
  { y: 30.3, en: "EYE", zh: "眼睛 · 多点高光", d: "深蓝外圈 + 亮蓝虹膜，白色与浅蓝高光大小错落" },
  { y: 42.0, en: "BROOCH", zh: "领结 · 椭圆蓝宝石", d: "深蓝蝴蝶结，金边镶嵌居中" },
  { y: 60.5, en: "HAND", zh: "手掌 · 五指成形", d: "掌端独立刚性段，指节与拇指清楚，不再拉伸糊边" },
  { y: 69.5, en: "SKIRT", zh: "裙摆 · 金十字星", d: "金色十字星、针脚与浅金蝴蝶结点缀" },
  { y: 94.0, en: "SHOE", zh: "鞋尖 · 硬底接地", d: "圆头深蓝玛丽珍，鞋底硬边贴地，袜口与鞋口分离" },
];

const DIMS = [8, 41, 73, 99];

function Corner({ pos }: { pos: string }) {
  return (
    <span
      aria-hidden
      className={cx(
        "pointer-events-none absolute h-3.5 w-3.5 border-navy/45",
        pos,
        pos.includes("top") ? "border-t" : "border-b",
        pos.includes("left") ? "border-l" : "border-r",
      )}
    />
  );
}

export default function ModelSheet() {
  return (
    <section id="sheet" className="relative px-5 pb-24 pt-10 sm:px-8 lg:px-14 lg:pt-16">
      <header className="max-w-[1600px]" data-reveal>
        <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2">
          <span className="micro text-cobalt">Sheet 01 — Regeneration</span>
          <span className="h-px min-w-8 flex-1 bg-navy/25" />
          <span className="micro text-mist">{META.branch}</span>
        </div>

        <h1 className="mt-7 text-[clamp(2.1rem,7.6vw,6.5rem)] font-black leading-[0.96] tracking-[-0.035em] text-ink">
          本鲸重绘
          <span className="block text-cobalt">手脚成型，表情成集</span>
        </h1>

        <div className="mt-7 h-px w-full origin-left bg-navy/30 wipe" />

        <div className="mt-9 grid gap-x-14 gap-y-9 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
          <div>
            <p className="max-w-[46ch] text-[15px] leading-[1.9] text-navy/85">
              针对分支上「手脚是软的、面部表情奇怪」两条反馈重新生图：全身原画按
              <strong className="font-bold text-ink">肩-肘-腕-掌、髋-膝-踝-鞋尖</strong>
              成型，掌端五指与鞋底硬边单独重绘；表情改为正面独立头像，交付
              <strong className="font-bold text-ink"> 12 格表情源表 </strong>
              与<strong className="font-bold text-ink"> 12 帧循环 GIF</strong>，其中六格与
              <code className="mx-1 rounded-sm bg-navy/8 px-1 font-mono text-[12.5px] text-navy">
                expression()
              </code>
              已接线 key 一一对应。
            </p>
          </div>

          <div className="flex items-start justify-between gap-6 border-t border-navy/25 pt-4">
            <dl className="grid grid-cols-[auto_minmax(0,1fr)] gap-x-4 gap-y-2 font-mono text-[12.5px] leading-relaxed">
              {[
                ["分支", META.branch],
                ["仓库", META.repo],
                ["说明", META.doc],
                ["日期", META.date],
                ["状态", META.status],
              ].map(([k, v]) => (
                <div key={k} className="contents">
                  <dt className="text-mist">{k}</dt>
                  <dd className="break-all text-navy">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="hidden shrink-0 -rotate-[7deg] border-[2.5px] border-stamp px-3 py-1.5 text-center sm:block">
              <span className="block font-display text-[15px] font-bold leading-none tracking-[0.14em] text-stamp">
                未签收
              </span>
              <span className="mt-1 block font-mono text-[9px] leading-none tracking-[0.18em] text-stamp/85">
                HUMAN / WIP
              </span>
            </div>
          </div>
        </div>

        {/* diagnosis: horizontal triptych */}
        <ul className="mt-12 grid gap-x-10 gap-y-8 md:grid-cols-3">
          {DIAGNOSIS.map((d) => (
            <li key={d.no} className="border-t-2 border-navy/70 pt-4" data-reveal>
              <div className="flex items-baseline gap-3">
                <span className="font-display text-[12px] font-bold tnum text-gold">{d.no}</span>
                <h3 className="text-[15px] font-black leading-snug text-ink">{d.symptom}</h3>
              </div>
              <p className="mt-3 text-[13px] leading-[1.8] text-mist">
                <span className="text-navy/70">原因 </span>
                {d.cause}
              </p>
              <p className="mt-2 text-[13px] leading-[1.8] text-navy">
                <span className="text-cobalt">本次 </span>
                {d.fix}
              </p>
            </li>
          ))}
        </ul>
      </header>

      {/* ------------------------------------------------- annotated plate */}
      <div className="mt-16 max-w-[1600px]" data-reveal>
        <div className="mb-3 flex items-baseline gap-4">
          <span className="micro text-navy">Fig.01 — 全身原画与部位标注</span>
          <span className="h-px flex-1 bg-navy/20" />
          <span className="micro text-mist">1024 × 1536</span>
        </div>

        <div className="flex items-stretch">
          {/* annotation rail (md+) */}
          <div className="relative hidden w-[142px] shrink-0 md:block lg:w-[172px]">
            {CALLOUTS.map((c, i) => (
              <div
                key={c.en}
                className="callout absolute right-0 w-full -translate-y-1/2 pr-3 text-right"
                style={{ top: `${c.y}%`, animationDelay: `${0.35 + i * 0.11}s` }}
              >
                <div className="micro text-cobalt">{c.en}</div>
                <div className="mt-1 text-[13px] font-bold leading-tight text-ink">{c.zh}</div>
                <div className="mt-1 text-[11.5px] leading-[1.55] text-mist">{c.d}</div>
                <span aria-hidden className="absolute right-0 top-1/2 h-px w-6 bg-navy/50" />
              </div>
            ))}
          </div>

          {/* the plate */}
          <div className="relative min-w-0 flex-1">
            <div className="relative aspect-[2/3] overflow-hidden border border-navy/25 bg-plate">
              <img
                src={SRC.whaleFull}
                alt="本鲸全身原画：Q 版蓝色鲸鱼娘，三头身，女仆装，手脚轮廓清晰"
                className="absolute inset-0 h-full w-full object-cover"
                loading="eager"
                decoding="async"
              />

              {/* dimension line, right edge */}
              <div className="pointer-events-none absolute inset-y-5 right-4 w-px bg-navy/25" />
              {DIMS.map((y) => (
                <span
                  key={y}
                  aria-hidden
                  className="pointer-events-none absolute right-4 h-px w-2.5 bg-navy/35"
                  style={{ top: `${y}%` }}
                />
              ))}
              <span
                className="pointer-events-none absolute right-[26px] top-1/2 -translate-y-1/2 bg-paper/75 px-1 py-1 font-mono text-[10px] tracking-[0.16em] text-navy/75"
                style={{ writingMode: "vertical-rl" }}
              >
                3 HEADS
              </span>

              {/* callout ticks */}
              {CALLOUTS.map((c, i) => (
                <span
                  key={c.en}
                  aria-hidden
                  className="callout pointer-events-none absolute left-0 h-px w-6 bg-navy/55"
                  style={{ top: `${c.y}%`, animationDelay: `${0.45 + i * 0.11}s` }}
                >
                  <span
                    className="absolute -top-[3px] left-[22px] block h-[7px] w-[7px] rounded-full border border-navy bg-paper"
                    style={{ animationDelay: `${0.5 + i * 0.11}s` }}
                  />
                </span>
              ))}

              <Corner pos="left-1.5 top-1.5" />
              <Corner pos="right-1.5 top-1.5" />
              <Corner pos="left-1.5 bottom-1.5" />
              <Corner pos="right-1.5 bottom-1.5" />
            </div>

            <div className="mt-2.5 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
              <span className="font-mono text-[11.5px] text-navy">whale-full.jpg</span>
              <span className="micro text-mist">paperdoll/assets/whale-regenerated.png ← 源</span>
            </div>
          </div>
        </div>

        {/* mobile callout list */}
        <ul className="mt-6 grid gap-x-6 gap-y-3 sm:grid-cols-2 md:hidden">
          {CALLOUTS.map((c) => (
            <li key={c.en} className="border-t border-navy/15 pt-2.5">
              <div className="micro text-cobalt">{c.en}</div>
              <div className="mt-1 text-[13px] font-bold text-ink">{c.zh}</div>
              <div className="mt-0.5 text-[11.5px] leading-[1.6] text-mist">{c.d}</div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
