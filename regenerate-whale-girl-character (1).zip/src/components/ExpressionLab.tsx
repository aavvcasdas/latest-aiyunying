import { useRef, useState } from "react";
import { EXPRESSIONS, SRC, cx, fmtBytes, type Expr } from "../data";

const sheetOf = (e: Expr) => (e.sheet === 1 ? SRC.sheet1 : SRC.sheet2);

/** Exact cell rect inside the 3×2 source sheet, matching the ImageMagick slice. */
function cellRect(img: HTMLImageElement, e: Expr) {
  const cw = img.naturalWidth / 3;
  const ch = img.naturalHeight / 2;
  const inset = 6 * (img.naturalWidth / 1536);
  return {
    sx: e.col * cw + inset,
    sy: e.row * ch + inset,
    sw: Math.round(cw - inset * 2),
    sh: Math.round(ch - inset * 2),
  };
}

function loadImg(src: string) {
  return new Promise<HTMLImageElement>((res, rej) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => rej(new Error("image load failed"));
    img.src = src;
  });
}

function trigger(href: string, download: string) {
  const a = document.createElement("a");
  a.href = href;
  a.download = download;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

export default function ExpressionLab() {
  const [playing, setPlaying] = useState(true);
  const [sel, setSel] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const e = EXPRESSIONS[sel];

  const select = (i: number) => {
    setSel(i);
    setPlaying(false);
  };

  const exportPng = async (item: Expr) => {
    setBusy(item.key);
    setErr(null);
    try {
      const img = await loadImg(sheetOf(item));
      const { sx, sy, sw, sh } = cellRect(img, item);
      const c = document.createElement("canvas");
      c.width = sw;
      c.height = sh;
      const ctx = c.getContext("2d");
      if (!ctx) throw new Error("canvas 2d unavailable");
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
      trigger(c.toDataURL("image/png"), `whale_face_${item.key}.png`);
    } catch {
      setErr("导出失败：源表情表未能载入，请改用下方「下载源表」。");
    } finally {
      setBusy(null);
    }
  };

  const bg = (item: Expr) =>
    ({
      backgroundImage: `url(${sheetOf(item)})`,
      backgroundSize: "300% 200%",
      backgroundPosition: `${(item.col / 2) * 100}% ${item.row * 100}%`,
    }) as const;

  const wired = EXPRESSIONS.filter((x) => x.wired).length;

  return (
    <section id="face" className="relative border-t border-navy/20 px-5 py-20 sm:px-8 lg:px-14">
      <div className="max-w-[1600px]" data-reveal>
        <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2">
          <span className="micro text-cobalt">Sheet 02 — Expressions</span>
          <span className="h-px flex-1 min-w-8 bg-navy/25" />
          <span className="micro text-mist">
            {wired} wired / {EXPRESSIONS.length - wired} extended
          </span>
        </div>

        <div className="mt-7 grid gap-x-14 gap-y-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
          <h2 className="text-[clamp(2rem,4.6vw,3.4rem)] font-black leading-[1.02] tracking-[-0.02em] text-ink">
            十二格表情，
            <br />
            一格一脸，不串味。
          </h2>
          <p className="max-w-[52ch] self-end text-[14.5px] leading-[1.9] text-navy/85">
            旧流程在「去眼去嘴」底图上二次叠五官，容易留下第二条嘴线与偏色的脸。本轮改为正面独立头像，
            单格只画一个表情；前六格直接对应
            <code className="mx-1 rounded-sm bg-navy/8 px-1 font-mono text-[12.5px] text-navy">
              expression()
            </code>
            的已接线 key，后六格是可扩展的参考。
          </p>
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[minmax(0,440px)_minmax(0,1fr)]">
          {/* viewer */}
          <div>
            <div className="relative aspect-square overflow-hidden border border-navy/25 bg-plate">
              {playing ? (
                <img
                  ref={imgRef}
                  src={SRC.expressionsGif}
                  alt="本鲸 12 帧表情循环 GIF"
                  className="absolute inset-0 h-full w-full object-cover"
                />
              ) : (
                <div className="absolute inset-0" style={bg(e)} role="img" aria-label={`${e.zh} 表情`} />
              )}

              <span className="pointer-events-none absolute left-0 top-0 bg-navy px-2.5 py-1.5 font-mono text-[10.5px] tracking-[0.16em] text-pale">
                {playing ? "GIF · LOOP" : `${e.key.toUpperCase()} · ${e.zh}`}
              </span>
              <CornerMarks />
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                onClick={() => setPlaying((p) => !p)}
                className={cx(
                  "border px-4 py-2 font-display text-[12px] font-medium tracking-wider transition-colors",
                  playing
                    ? "border-navy/30 bg-transparent text-navy hover:bg-navy hover:text-pale"
                    : "border-cobalt bg-cobalt text-white hover:bg-navy",
                )}
              >
                {playing ? "⏸ 暂停并定格" : "▶ 播放 GIF"}
              </button>
              <button
                onClick={() => select((sel + EXPRESSIONS.length - 1) % EXPRESSIONS.length)}
                className="border border-navy/30 px-3 py-2 font-mono text-[12px] text-navy transition-colors hover:border-cobalt hover:text-cobalt"
                aria-label="上一格"
              >
                ←
              </button>
              <button
                onClick={() => select((sel + 1) % EXPRESSIONS.length)}
                className="border border-navy/30 px-3 py-2 font-mono text-[12px] text-navy transition-colors hover:border-cobalt hover:text-cobalt"
                aria-label="下一格"
              >
                →
              </button>
              <a
                href={SRC.expressionsGif}
                download="whale-expressions.gif"
                className="ml-auto border border-navy bg-navy px-4 py-2 font-display text-[12px] font-medium tracking-wider text-pale transition-colors hover:bg-cobalt hover:border-cobalt"
              >
                ↓ GIF · {fmtBytes(856752)}
              </a>
            </div>
          </div>

          {/* detail + strip */}
          <div className="min-w-0">
            <div className="border-t border-navy/25 pt-4">
              <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
                <span className="font-mono text-[13px] font-medium text-cobalt">'{e.key}'</span>
                <span className="text-[22px] font-black leading-none text-ink">{e.zh}</span>
                <span
                  className={cx(
                    "micro px-1.5 py-1",
                    e.wired ? "bg-gold/20 text-gold" : "bg-navy/8 text-mist",
                  )}
                >
                  {e.wired ? "wired · 已接线" : "reference · 扩展"}
                </span>
              </div>
              <p className="mt-3 max-w-[48ch] text-[14px] leading-[1.85] text-navy/85">{e.note}</p>
              <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 font-mono text-[11.5px] text-mist">
                <span>
                  sheet-{e.sheet} · cell({e.col},{e.row})
                </span>
                <span>500 × 500 px</span>
                <span>whale_face_{e.key}.png</span>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={() => exportPng(e)}
                  disabled={busy !== null}
                  className="border border-cobalt bg-cobalt px-4 py-2 font-display text-[12px] font-medium tracking-wider text-white transition-colors hover:bg-navy hover:border-navy disabled:opacity-50"
                >
                  {busy === e.key ? "导出中…" : "↓ 导出本格 PNG"}
                </button>
                <a
                  href={sheetOf(e)}
                  download={`expr-sheet-${e.sheet}.jpg`}
                  className="border border-navy/30 px-4 py-2 font-display text-[12px] font-medium tracking-wider text-navy transition-colors hover:border-cobalt hover:text-cobalt"
                >
                  ↓ 源表情表 {e.sheet}
                </a>
              </div>
              {err && <p className="mt-3 text-[12.5px] text-stamp">{err}</p>}
            </div>

            {/* 12-cell strip */}
            <div className="mt-9">
              <div className="flex items-baseline gap-4">
                <span className="micro text-navy">Frame index — 与 GIF 帧序一致</span>
                <span className="h-px flex-1 bg-navy/20" />
              </div>
              <ul className="mt-4 grid grid-cols-4 gap-2.5 sm:grid-cols-6">
                {EXPRESSIONS.map((item, i) => (
                  <li key={item.key}>
                    <button
                      onClick={() => select(i)}
                      aria-pressed={i === sel && !playing}
                      className="group block w-full text-left"
                    >
                      <span
                        className={cx(
                          "relative block aspect-square w-full overflow-hidden border transition-all",
                          i === sel && !playing
                            ? "border-cobalt ring-2 ring-cobalt/30"
                            : "border-navy/20 group-hover:border-cobalt",
                        )}
                        style={bg(item)}
                      >
                        {item.wired && (
                          <span className="absolute right-1 top-1 block h-1.5 w-1.5 rounded-full bg-gold" />
                        )}
                      </span>
                      <span className="mt-1.5 block font-mono text-[10px] leading-tight text-mist">
                        {String(i + 1).padStart(2, "0")} {item.key}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CornerMarks() {
  return (
    <>
      <span aria-hidden className="pointer-events-none absolute left-1.5 top-1.5 h-3 w-3 border-l border-t border-pale/70" />
      <span aria-hidden className="pointer-events-none absolute right-1.5 top-1.5 h-3 w-3 border-r border-t border-pale/70" />
      <span aria-hidden className="pointer-events-none absolute bottom-1.5 left-1.5 h-3 w-3 border-b border-l border-pale/70" />
      <span aria-hidden className="pointer-events-none absolute bottom-1.5 right-1.5 h-3 w-3 border-b border-r border-pale/70" />
    </>
  );
}
