import { SRC } from "../data";

const COMPARE = [
  {
    en: "HAND",
    zh: "掌端 · 手",
    before: "整条手臂是一张 hands.png 横带，弯肘靠拉伸补关节，掌端跟着变形糊成面条；所谓腕关节只是把同一张图来回晃动。",
    after: "上臂 / 前臂 / 手掌三段刚性纹理，掌端单独切图并局部重绘关节盖片。五指、拇指与掌纹成型，骨段只平移与旋转，不拉伸、不横带。",
  },
  {
    en: "FOOT",
    zh: "鞋尖 · 脚",
    before: "膝盖沿用了错位的袜口锚点，鞋口与袜口粘在一起，接地靠把鞋底压扁来「够到」地面。",
    after: "髋-膝-踝-鞋尖重新标注，鞋从实际鞋口分开，鞋底硬边贴地；袜口留在腿段，摆动脚可真正抬离地面。",
  },
];

export default function Limbs() {
  return (
    <section id="limbs" className="relative border-t border-navy/20 px-5 py-20 sm:px-8 lg:px-14">
      <div className="max-w-[1600px]" data-reveal>
        <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2">
          <span className="micro text-cobalt">Sheet 03 — Limbs</span>
          <span className="h-px flex-1 min-w-8 bg-navy/25" />
          <span className="micro text-mist">rigid · 3 segments / limb</span>
        </div>

        <div className="mt-7 grid gap-x-14 gap-y-9 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.45fr)]">
          <div>
            <h2 className="text-[clamp(2rem,4.6vw,3.4rem)] font-black leading-[1.02] tracking-[-0.02em] text-ink">
              把横带
              <br />
              换成骨段。
            </h2>
            <p className="mt-6 max-w-[42ch] text-[14.5px] leading-[1.9] text-navy/85">
              「手脚是软的」不是动作问题，是切图问题。手臂被当成一整张可拉伸的图，一弯就变形；
              现在每肢拆成三段刚性纹理，关节用局部盖片补画，而不是用形变糊过去。
            </p>
            <div className="mt-7 border-l-2 border-gold pl-4">
              <p className="text-[13px] leading-[1.85] text-mist">
                换原画后，<code className="font-mono text-[12.5px] text-navy">prepare-rigid-whale.py</code> 里的
                <code className="mx-1 font-mono text-[12.5px] text-navy">CHAINS</code>关节点与
                <code className="mx-1 font-mono text-[12.5px] text-navy">mgrid[:1136,:912]</code>
                仍是按旧原画标注的常量，必须重新标注后才能重跑。
              </p>
            </div>
          </div>

          <figure className="min-w-0">
            <div className="relative aspect-[3/2] overflow-hidden border border-navy/25 bg-plate">
              <img
                src={SRC.detailLimbs}
                alt="手掌五指与玛丽珍鞋细节对照：掌端五指清晰、鞋底硬边接地"
                className="absolute inset-0 h-full w-full object-cover"
                loading="lazy"
                decoding="async"
              />
              <span className="pointer-events-none absolute left-0 top-0 bg-navy px-2.5 py-1.5 font-mono text-[10.5px] tracking-[0.16em] text-pale">
                FIG.02 · DETAIL
              </span>
            </div>
            <figcaption className="mt-2.5 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
              <span className="font-mono text-[11.5px] text-navy">detail-limbs.jpg</span>
              <span className="micro text-mist">掌端五指 / 鞋尖接地</span>
            </figcaption>
          </figure>
        </div>

        <ul className="mt-14 grid gap-x-12 gap-y-10 md:grid-cols-2">
          {COMPARE.map((c) => (
            <li key={c.en} className="border-t border-navy/25 pt-5" data-reveal>
              <div className="flex items-baseline gap-3">
                <span className="micro text-cobalt">{c.en}</span>
                <h3 className="text-[17px] font-black text-ink">{c.zh}</h3>
              </div>
              <div className="mt-5 grid gap-4">
                <div className="bg-stamp/[0.06] p-4">
                  <div className="micro text-stamp">Before — 旧</div>
                  <p className="mt-2 text-[13.5px] leading-[1.85] text-navy/80">{c.before}</p>
                </div>
                <div className="bg-cobalt/[0.07] p-4">
                  <div className="micro text-cobalt">After — 本次</div>
                  <p className="mt-2 text-[13.5px] leading-[1.85] text-navy">{c.after}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
