import { cx } from "../data";

export const SECTIONS = [
  { id: "sheet", no: "01", label: "总览", en: "SHEET" },
  { id: "face", no: "02", label: "表情", en: "FACE" },
  { id: "limbs", no: "03", label: "手脚", en: "LIMBS" },
  { id: "manifest", no: "04", label: "清单", en: "MANIFEST" },
  { id: "run", no: "05", label: "执行", en: "RUN" },
];

export default function Rail({ active }: { active: string }) {
  const go = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      {/* Desktop: fixed index rail, vertical Chinese labels */}
      <nav
        aria-label="章节索引"
        className="fixed left-0 top-0 z-40 hidden h-screen w-[76px] flex-col justify-between gap-6 overflow-y-auto border-r border-navy/20 bg-paper/85 py-5 backdrop-blur-sm lg:flex"
      >
        <div className="flex flex-col items-center gap-1">
          <span className="micro text-navy/70">鲸</span>
          <span className="mt-1 h-6 w-px bg-navy/25" />
        </div>

        <ul className="flex flex-col items-center gap-7">
          {SECTIONS.map((s) => {
            const on = active === s.id;
            return (
              <li key={s.id} className="relative">
                <button
                  onClick={() => go(s.id)}
                  aria-current={on ? "true" : undefined}
                  className={cx(
                    "group flex flex-col items-center gap-2 transition-colors",
                    on ? "text-ink" : "text-mist hover:text-cobalt",
                  )}
                >
                  <span className="font-display text-[15px] font-bold tnum leading-none">{s.no}</span>
                  <span
                    className="text-[12px] leading-none tracking-[0.28em]"
                    style={{ writingMode: "vertical-rl" }}
                  >
                    {s.label}
                  </span>
                  <span
                    className={cx(
                      "h-px w-5 transition-all",
                      on ? "bg-cobalt" : "bg-navy/25 group-hover:bg-cobalt/60",
                    )}
                  />
                </button>
              </li>
            );
          })}
        </ul>

        <div className="flex flex-col items-center gap-2">
          <span className="h-6 w-px bg-navy/25" />
          <span
            className="micro text-mist"
            style={{ writingMode: "vertical-rl", letterSpacing: "0.24em" }}
          >
            WIP
          </span>
        </div>
      </nav>

      {/* Mobile: sticky strip */}
      <div className="sticky top-0 z-40 border-b border-navy/20 bg-paper/92 backdrop-blur-sm lg:hidden">
        <div className="flex items-center gap-3 overflow-x-auto px-4 py-2.5">
          <span className="micro shrink-0 text-navy">本鲸 / 交付单</span>
          <span className="h-3 w-px shrink-0 bg-navy/25" />
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => go(s.id)}
              className={cx(
                "shrink-0 font-display text-[11px] font-medium tnum tracking-wider transition-colors",
                active === s.id ? "text-cobalt" : "text-mist",
              )}
            >
              {s.no} {s.label}
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
