import { useState } from "react";
import {
  FILES,
  GROUPS,
  META,
  ROWS,
  STEPS,
  CAVEATS,
  DOC_NAME,
  REPLACEMENT_DOC,
  fmtBytes,
  cx,
} from "../data";

async function writeClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export default function Manifest() {
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (text: string, id: string) => {
    const ok = await writeClipboard(text);
    setCopied(ok ? id : "fail");
    window.setTimeout(() => setCopied(null), 1600);
  };

  const manifestJson = () =>
    JSON.stringify(
      {
        schema: 1,
        generatedBy: "本鲸资产修复交付单",
        branch: META.branch,
        repo: META.repo,
        date: META.date,
        status: META.status,
        note: "模型 / 版本 / seed 均未由图片工具提供，如实记为 unknown。",
        files: FILES.map((f) => ({ name: f.name, label: f.label, dim: f.dim, bytes: f.bytes, sha256: f.sha })),
        replacements: ROWS.map((r) => ({
          group: r.g,
          target: r.path,
          source: r.src,
          action: r.act,
          note: r.note,
        })),
      },
      null,
      2,
    );

  const downloadManifest = () => {
    const blob = new Blob([manifestJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "whale_asset_manifest.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  const command = STEPS.map((s) => `# ${s.n} ${s.title}\n${s.cmd}`).join("\n\n");

  const downloadDoc = () => {
    const blob = new Blob([REPLACEMENT_DOC], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = DOC_NAME;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  return (
    <>
      {/* ------------------------------------------------------ 04 清单 */}
      <section id="manifest" className="relative border-t border-navy/20 px-5 py-20 sm:px-8 lg:px-14">
        <div className="max-w-[1600px]" data-reveal>
          <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2">
            <span className="micro text-cobalt">Sheet 04 — Replacement manifest</span>
            <span className="h-px flex-1 min-w-8 bg-navy/25" />
            <button
              onClick={downloadManifest}
              className="micro border border-navy/30 px-2.5 py-1.5 text-navy transition-colors hover:border-cobalt hover:text-cobalt"
            >
              ↓ manifest.json
            </button>
          </div>

          <div className="mt-7 grid gap-x-14 gap-y-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
            <h2 className="text-[clamp(2rem,4.6vw,3.4rem)] font-black leading-[1.02] tracking-[-0.02em] text-ink">
              替换清单，
              <br />
              按组落地。
            </h2>
            <p className="max-w-[52ch] self-end text-[14.5px] leading-[1.9] text-navy/85">
              A 组是可直接覆盖或新增的成品文件，落完不触发现有切图；B 组换的是源图，落完必须重标关节点并重跑切图脚本，
              否则 12 段骨段纹理与 <code className="font-mono text-[12.5px]">bind.json</code> 全部对不上；
              C 组只动记录与版本。给 agent 的执行顺序见下一节。
            </p>
          </div>

          {/* column header */}
          <div className="mt-12 hidden border-b border-navy/30 pb-2 md:grid md:grid-cols-[34px_minmax(0,1fr)_minmax(0,1.1fr)_minmax(0,0.72fr)_96px] md:gap-x-4">
            <span className="micro text-mist">组</span>
            <span className="micro text-mist">仓库路径</span>
            <span className="micro text-mist">说明</span>
            <span className="micro text-mist">来源</span>
            <span className="micro text-right text-mist">操作</span>
          </div>

          {(["A", "B", "C"] as const).map((g) => (
            <div key={g} className="mb-10">
              <div className="mt-6 flex flex-wrap items-baseline gap-x-4 gap-y-1 border-b border-navy/15 pb-2">
                <span className="font-display text-[13px] font-bold tracking-[0.16em] text-gold">{g} 组</span>
                <span className="text-[14.5px] font-bold text-ink">{GROUPS[g].title}</span>
                <span className="text-[12.5px] text-mist">{GROUPS[g].sub}</span>
              </div>

              <ul>
                {ROWS.filter((r) => r.g === g).map((r) => (
                  <li
                    key={r.path}
                    className="grid gap-x-4 gap-y-1.5 border-b border-navy/10 py-3.5 transition-colors hover:bg-navy/[0.035] md:grid-cols-[34px_minmax(0,1fr)_minmax(0,1.1fr)_minmax(0,0.72fr)_96px] md:items-baseline"
                  >
                    <span className="font-display text-[12px] font-bold text-mist">{r.g}</span>

                    <code className="block break-all font-mono text-[12.5px] leading-[1.65] text-navy">
                      {r.path}
                    </code>

                    <span className="block text-[13px] leading-[1.7] text-navy/80">{r.note}</span>

                    <span className="block break-all font-mono text-[11.5px] leading-[1.6] text-mist">
                      {r.src}
                    </span>

                    <span className="flex items-center gap-2 md:justify-end">
                      <span
                        className={cx(
                          "micro px-1.5 py-1",
                          r.act === "新增" && "bg-cobalt/12 text-cobalt",
                          r.act === "覆盖" && "bg-gold/20 text-gold",
                          r.act === "重跑" && "bg-stamp/12 text-stamp",
                          r.act === "更新" && "bg-navy/8 text-mist",
                        )}
                      >
                        {r.act}
                      </span>
                      <button
                        title="复制路径"
                        aria-label={`复制路径 ${r.path}`}
                        onClick={() => copy(r.path, r.path)}
                        className={cx(
                          "border px-1.5 py-1 font-mono text-[10px] transition-colors",
                          copied === r.path
                            ? "border-cobalt bg-cobalt text-white"
                            : "border-navy/25 text-mist hover:border-cobalt hover:text-cobalt",
                        )}
                      >
                        {copied === r.path ? "✓" : "⧉"}
                      </button>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------ 05 执行 */}
      <section id="run" className="relative border-t border-navy/20 px-5 py-20 sm:px-8 lg:px-14">
        <div className="max-w-[1600px]" data-reveal>
          <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2">
            <span className="micro text-cobalt">Sheet 05 — Agent runbook</span>
            <span className="h-px flex-1 min-w-8 bg-navy/25" />
            <span className="micro text-mist">{META.rig}</span>
          </div>

          <div className="mt-7 flex flex-wrap items-end justify-between gap-6">
            <h2 className="text-[clamp(2rem,4.6vw,3.4rem)] font-black leading-[1.02] tracking-[-0.02em] text-ink">
              执行顺序
            </h2>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={downloadDoc}
                className="border border-cobalt bg-cobalt px-4 py-2.5 font-display text-[12px] font-medium tracking-wider text-white transition-colors hover:border-navy hover:bg-navy"
              >
                ↓ 替换说明 .md
              </button>
              <button
                onClick={() => copy(command, "ALL")}
                className="border border-navy bg-navy px-4 py-2.5 font-display text-[12px] font-medium tracking-wider text-pale transition-colors hover:border-cobalt hover:bg-cobalt"
              >
                {copied === "ALL" ? "✓ 已复制到剪贴板" : "⧉ 复制全部命令"}
              </button>
            </div>
          </div>

          <ol className="mt-10 space-y-7">
            {STEPS.map((s) => (
              <li key={s.n} className="grid gap-x-6 gap-y-3 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
                <div className="flex gap-4">
                  <span className="font-display text-[13px] font-bold tnum text-gold">{s.n}</span>
                  <div>
                    <h3 className="text-[15.5px] font-bold leading-snug text-ink">{s.title}</h3>
                    <p className="mt-2 max-w-[46ch] text-[13.5px] leading-[1.85] text-mist">{s.body}</p>
                  </div>
                </div>
                <pre className="overflow-x-auto border border-navy/25 bg-ink px-4 py-3.5 font-mono text-[12.5px] leading-[1.75] text-pale">
                  <code>{s.cmd}</code>
                </pre>
              </li>
            ))}
          </ol>

          {/* caveats */}
          <div className="mt-16 grid gap-x-12 gap-y-8 lg:grid-cols-[minmax(0,0.5fr)_minmax(0,1.5fr)]">
            <div>
              <span className="micro text-stamp">Caveats — 不可越过的边界</span>
              <p className="mt-3 text-[13px] leading-[1.8] text-mist">
                与仓库 <span className="font-mono text-[12px] text-navy">human_sign_off.md</span> 一致：
                机器检查通过不等于视觉验收通过。
              </p>
            </div>
            <ul className="space-y-3">
              {CAVEATS.map((c, i) => (
                <li key={i} className="flex gap-4 border-t border-navy/15 pt-3">
                  <span className="font-display text-[12px] font-bold tnum text-gold">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[13.5px] leading-[1.85] text-navy/85">{c}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* downloads */}
          <div className="mt-16">
            <div className="flex flex-wrap items-baseline gap-x-5 gap-y-2 border-b border-navy/30 pb-2">
              <span className="micro text-navy">Downloads — 全部交付文件</span>
              <span className="h-px flex-1 bg-navy/15" />
              <span className="micro text-mist">sha256 前 16 位</span>
            </div>
            <ul>
              {FILES.map((f) => (
                <li
                  key={f.name}
                  className="grid gap-x-5 gap-y-2 border-b border-navy/10 py-4 transition-colors hover:bg-navy/[0.035] md:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)_110px_minmax(0,0.9fr)_auto] md:items-center"
                >
                  <div className="min-w-0">
                    <div className="font-mono text-[13px] text-navy">{f.name}</div>
                    <div className="mt-0.5 text-[12.5px] text-mist">{f.label}</div>
                  </div>
                  <div className="font-mono text-[11.5px] text-mist">{f.dim}</div>
                  <div className="font-mono text-[11.5px] tnum text-mist">{fmtBytes(f.bytes)}</div>
                  <div className="min-w-0 truncate font-mono text-[11.5px] text-navy/70" title={f.sha}>
                    {f.sha}
                  </div>
                  <a
                    href={f.url}
                    download={f.name}
                    className="justify-self-start border border-navy/30 px-3.5 py-2 font-display text-[12px] font-medium tracking-wider text-navy transition-colors hover:border-cobalt hover:bg-cobalt hover:text-white md:justify-self-end"
                  >
                    ↓ 下载
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
}
