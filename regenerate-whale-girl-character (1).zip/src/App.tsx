import { useEffect, useState } from "react";
import Rail, { SECTIONS } from "./components/Rail";
import ModelSheet from "./components/ModelSheet";
import ExpressionLab from "./components/ExpressionLab";
import Limbs from "./components/Limbs";
import Manifest from "./components/Manifest";
import { META, SRC } from "./data";

function DeepSeaBand() {
  return (
    <section className="relative isolate overflow-hidden bg-ink">
      <img
        src={SRC.deepsea}
        alt=""
        aria-hidden
        className="absolute inset-0 h-full w-full object-cover opacity-90"
        loading="lazy"
        decoding="async"
      />
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(100deg, rgba(6,26,60,0.94) 0%, rgba(6,26,60,0.86) 38%, rgba(6,26,60,0.42) 72%, rgba(6,26,60,0.30) 100%)",
        }}
      />
      <div className="relative px-5 py-24 sm:px-8 lg:px-14 lg:py-32">
        <div className="max-w-[1600px]" data-reveal>
          <span className="micro text-sea">Status — {META.status}</span>
          <p className="mt-6 max-w-[18ch] text-[clamp(2.1rem,5.4vw,4.4rem)] font-black leading-[1.06] tracking-[-0.025em] text-white">
            骨长测过了，
            <br />
            不等于手脚自然。
          </p>
          <div className="mt-8 h-px w-40 origin-left bg-sea/70 wipe" />
          <p className="mt-7 max-w-[54ch] text-[14.5px] leading-[1.95] text-pale/85">
            本轮交付的是可核对的图像资产：全身原画、十二格表情源表、循环 GIF 与替换清单。
            肩 / 膝轮廓、遮挡与正面原画的二维步态仍待人工在骨架定格台上逐帧确认，
            <span className="text-white"> 签收状态不变。</span>
          </p>
          <div className="mt-9 flex flex-wrap gap-x-8 gap-y-3 font-mono text-[12px] text-pale/70">
            <span>{META.rig}</span>
            <span>docs/quality_comparison/human_sign_off.md</span>
            <span>npm test · 66 JS / 13 PY</span>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  const [active, setActive] = useState(SECTIONS[0].id);

  /* reveal-on-scroll, with a hard fallback so nothing can stay invisible */
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll<HTMLElement>("[data-reveal]"));
    const reveal = (el: HTMLElement) => el.classList.add("is-in");

    if (!("IntersectionObserver" in window)) {
      nodes.forEach(reveal);
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            reveal(en.target as HTMLElement);
            io.unobserve(en.target);
          }
        });
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.05 },
    );

    nodes.forEach((n) => {
      if (n.getBoundingClientRect().top < window.innerHeight) reveal(n);
      else io.observe(n);
    });

    const safety = window.setTimeout(() => nodes.forEach(reveal), 2600);
    return () => {
      io.disconnect();
      window.clearTimeout(safety);
    };
  }, []);

  /* section spy for the index rail */
  useEffect(() => {
    if (!("IntersectionObserver" in window)) return;
    const io = new IntersectionObserver(
      (entries) => {
        const hit = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (hit) setActive(hit.target.id);
      },
      { rootMargin: "-42% 0px -50% 0px", threshold: [0, 0.2, 0.6] },
    );
    SECTIONS.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  return (
    <div className="drafting relative min-h-screen">
      <Rail active={active} />
      <div className="lg:pl-[76px]">
        <main>
          <ModelSheet />
          <ExpressionLab />
          <DeepSeaBand />
          <Limbs />
          <Manifest />
        </main>

        <footer className="border-t border-navy/25 px-5 py-10 sm:px-8 lg:px-14">
          <div className="flex max-w-[1600px] flex-wrap items-baseline justify-between gap-x-8 gap-y-4">
            <div>
              <div className="font-display text-[13px] font-bold tracking-[0.16em] text-navy">
                本鲸 · 资产修复交付单
              </div>
              <div className="mt-2 font-mono text-[11.5px] leading-relaxed text-mist">
                {META.repo} @ {META.branch}
              </div>
            </div>
            <div className="max-w-[52ch] text-[12.5px] leading-[1.85] text-mist">
              图片工具未提供模型、版本与 seed，按仓库规则记为 unknown；本页不改变
              <span className="font-mono text-[11.5px] text-navy"> 半成品 / 未签收 </span>
              状态，也不构成发布或商业授权结论。
            </div>
            <div className="micro text-mist">{META.date}</div>
          </div>
        </footer>
      </div>
    </div>
  );
}
