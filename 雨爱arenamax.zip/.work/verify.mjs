import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 960 }, deviceScaleFactor: 1 });
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
page.on('console', (message) => { if (message.type() === 'error') console.log('Console:', message.text().slice(0, 220)); });
await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });
await page.screenshot({ path: '.work/desktop-refined.png', fullPage: true });
assert.equal(await page.locator('.lyric-row').count(), 23);

await page.getByRole('button', { name: '播放影片', exact: true }).click();
await page.waitForFunction(() => Number(document.querySelector('.seek-range')?.value) > 500, { timeout: 20000 });
assert.ok(Number(await page.getByRole('slider', { name: '影片播放进度' }).inputValue()) > 500);
await page.getByRole('button', { name: '暂停播放', exact: true }).click();
console.log('PASS synchronized music playback');

await page.locator('[data-lyric="2"]').click();
await page.waitForTimeout(300);
assert.ok(Math.abs(Number(await page.getByRole('slider', { name: '影片播放进度' }).inputValue()) / 30 - 26.44) < 0.1);
await page.getByRole('switch', { name: '显示中文字幕' }).click();
assert.equal(await page.getByRole('switch', { name: '显示中文字幕' }).getAttribute('aria-checked'), 'false');
await page.getByRole('button', { name: '撤销', exact: true }).click();
assert.equal(await page.getByRole('switch', { name: '显示中文字幕' }).getAttribute('aria-checked'), 'true');
console.log('PASS lyric seeking, subtitle toggle, undo');

await page.getByRole('tab', { name: '画面风格' }).click();
await page.getByRole('button', { name: '暖阳奶油', exact: true }).click();
assert.ok((await page.locator('.video-stage img').first().getAttribute('style')).includes('sepia'));
await page.getByRole('button', { name: '撤销', exact: true }).click();
await page.getByRole('tab', { name: '歌词与字幕' }).click();
await page.getByRole('button', { name: '编辑', exact: true }).click();
await page.getByRole('textbox', { name: '第 1 句歌词', exact: true }).fill('窗外的天气');
await page.getByRole('button', { name: '保存字幕', exact: true }).click();
console.log('PASS palette, lyric editor, save');

await page.getByRole('button', { name: '分镜', exact: true }).click();
assert.equal(await page.locator('.storyboard-scene').count(), 4);
await page.getByRole('button', { name: '编辑分镜 窗边听雨' }).click();
await page.getByLabel('分镜名称', { exact: true }).fill('窗边听雨');
await page.getByRole('button', { name: '保存分镜', exact: true }).click();
await page.getByRole('button', { name: '返回创作', exact: true }).click();
await page.getByRole('button', { name: '素材', exact: true }).click();
assert.equal(await page.locator('.asset-grid article').count(), 4);
await page.keyboard.press('Escape');
await page.getByRole('button', { name: '使用帮助', exact: true }).click();
await page.keyboard.press('Escape');
console.log('PASS storyboard, scene editor, asset library, accessible dialogs');

await page.getByRole('button', { name: '导出影片', exact: true }).click();
await page.getByLabel('影片格式', { exact: true }).selectOption('webm');
await page.getByLabel('画面清晰度', { exact: true }).selectOption('720');
await page.getByLabel('导出范围', { exact: true }).selectOption('preview');
const downloadPromise = page.waitForEvent('download', { timeout: 180000 });
await page.getByRole('button', { name: '开始导出影片', exact: true }).click();
try {
  const download = await downloadPromise;
  await download.saveAs('.work/test-preview.webm');
  console.log('PASS actual Remotion video export:', download.suggestedFilename());
} catch (error) {
  console.log('EXPORT STATE', await page.locator('.modal').innerText());
  throw error;
}
await page.screenshot({ path: '.work/export-complete.png' });
await page.keyboard.press('Escape');
await page.setViewportSize({ width: 390, height: 844 });
await page.screenshot({ path: '.work/mobile-refined.png', fullPage: true });
assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), 390);
assert.deepEqual(errors, []);
console.log('PASS mobile layout and no uncaught runtime errors');
await browser.close();