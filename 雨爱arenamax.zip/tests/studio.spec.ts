import { expect, test } from '@playwright/test';

test.use({ baseURL: 'http://localhost:5173' });

test('plays the original song and seeks to a lyric', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: '雨爱', exact: true })).toBeVisible();
  await expect(page.locator('.lyric-row')).toHaveCount(23);
  await page.getByRole('button', { name: '播放影片', exact: true }).click();
  await expect.poll(async () => Number(await page.getByRole('slider', { name: '影片播放进度' }).inputValue())).toBeGreaterThan(500);
  await page.getByRole('button', { name: '暂停播放', exact: true }).click();
  await page.locator('[data-lyric="2"]').click();
  await expect(page.getByRole('slider', { name: '影片播放进度' })).toHaveValue('793');
  await expect(page.locator('[data-lyric="2"]')).toHaveClass(/active/);
});

test('edits subtitles, preserves changes, and supports undo', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('switch', { name: '显示中文字幕' }).click();
  await expect(page.getByRole('switch', { name: '显示中文字幕' })).toHaveAttribute('aria-checked', 'false');
  await page.getByRole('button', { name: '撤销', exact: true }).click();
  await expect(page.getByRole('switch', { name: '显示中文字幕' })).toHaveAttribute('aria-checked', 'true');
  await page.getByRole('button', { name: '编辑', exact: true }).click();
  await page.getByRole('textbox', { name: '第 1 句歌词', exact: true }).fill('窗外的天气 测试');
  await page.getByRole('button', { name: '保存字幕', exact: true }).click();
  await expect(page.getByText('已自动保存')).toBeVisible();
  await page.reload();
  await expect(page.locator('[data-lyric="0"]')).toContainText('窗外的天气 测试');
});

test('validates a project backup and restores it', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByText('已自动保存')).toBeVisible();
  const project = await page.evaluate(() => JSON.parse(localStorage.getItem('rainfilm-project-v2')!));
  project.title = '温柔的雨';
  await page.locator('input[type="file"]').setInputFiles({ name: 'project.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(project)) });
  await expect(page.getByRole('heading', { name: '温柔的雨', exact: true })).toBeVisible();
  await page.locator('input[type="file"]').setInputFiles({ name: 'invalid.json', mimeType: 'application/json', buffer: Buffer.from('{}') });
  await expect(page.getByRole('status')).toContainText('不是有效的雨映项目');
  await expect(page.getByRole('heading', { name: '温柔的雨', exact: true })).toBeVisible();
});

test('downloads the complete MP4 and the timed SRT', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: '导出影片', exact: true }).click();
  const filmDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: '下载完整影片', exact: true }).click();
  expect(await (await filmDownload).failure()).toBeNull();
  await expect(page.locator('.export-success')).toBeVisible();
  await page.getByLabel('影片格式', { exact: true }).selectOption('webm');
  await expect(page.getByRole('button', { name: '开始导出影片', exact: true })).toBeVisible();
  const subtitleDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: '下载 SRT 字幕' }).click();
  expect(await (await subtitleDownload).failure()).toBeNull();
});

test('adapts to mobile without horizontal overflow', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await expect(page.locator('.video-stage')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390);
  await page.getByRole('button', { name: '分镜', exact: true }).click();
  await expect(page.locator('.storyboard-scene')).toHaveCount(4);
  await page.getByRole('button', { name: '返回创作', exact: true }).click();
  await expect(page.locator('.video-stage')).toBeVisible();
});