import { cancelRender, continueRender, delayRender, staticFile } from 'remotion';

// Register the same local font in the Player, browser exporter, and CLI renderer.
if (typeof document !== 'undefined') {
  const handle = delayRender('Loading the Chinese subtitle font');
  const font = new FontFace('Rain Sans', `url("${staticFile('fonts/rain-sans.woff2')}")`, { weight: '100 900' });
  font.load().then((loaded) => {
    document.fonts.add(loaded);
    continueRender(handle);
  }).catch((error: unknown) => cancelRender(error));
}