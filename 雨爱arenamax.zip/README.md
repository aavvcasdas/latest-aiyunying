# Rainfilm / 雨映

为《雨爱》司凤版制作的治愈系软 3D 音乐影像工作台。界面入口为 `src/App.tsx`，影片组件为 `src/remotion/RainLove.tsx`。

## 使用

- 运行 `npm run dev` 打开工作台。
- 运行 `npm run build` 构建可部署的静态网站。
- 点击播放，或用空格键播放 / 暂停。左右方向键跳转 5 秒，M 键切换静音。
- 点击歌词或时间线可定位影片。支持歌词和时间编辑、字幕开关、字号、色调、粒子特效、分镜笔记、撤销和重做。
- 修改保存在当前浏览器的 localStorage 中。导出面板可保存项目 JSON 和 SRT 字幕；设置中的“导入项目备份”可恢复此前下载的 JSON。
- 原版 1080p MP4 位于 `public/exports/rain-love.mp4`，可在导出面板直接下载。
- 修改后的影片通过 `@remotion/web-renderer` 在本地浏览器导出。支持完整影片、当前章节和 5 秒试片，支持取消渲染。编码支持取决于浏览器；MP4 编码不可用时请选择 WebM。需要 HTTPS 或 localhost 环境。

## 影片

- 1920 × 1080，30 fps，3938 帧，约 2 分 11 秒。
- 原音源虽然命名为 MP3，实际包含 H.264 视频和 AAC 音频。`public/audio/rain-love.m4a` 为原 AAC 音轨的无损提取，没有重新演唱或替换音乐。
- 四组原创软 3D 风格场景：雨窗、雨伞、云端记忆、雨后彩虹。
- Remotion 逐帧驱动运镜、交叉淡化、雨滴、微光、字幕和片尾。场景使用 3D 风格渲染图，不是可旋转的实时 3D 模型。
- 18 句用户提供的歌词，加上原声中重复副歌的 5 句，共 23 个字幕片段。起止时间参考原声自动逐词转录，中文以用户提供文本为准，可在编辑器逐句微调。
- 原声的前奏和尾奏均保留。工作台初始预览定位在 16.2 秒，便于看到歌词和画面；完整导出从 0 秒开始。
- 时间线的波形由原始音频实际采样生成，素材、字体及音轨均在本地提供。

## Remotion Studio 与命令行

运行 `npx remotion studio src/remotion/Root.tsx` 打开 Remotion Studio。

运行 `npx remotion render src/remotion/Root.tsx RainLove public/exports/rain-love.mp4 --codec=h264 --crf=20` 重新渲染原版影片。

如需渲染编辑后的项目，将下载的 JSON 包装为 `{ "project": ... }`，使用 Remotion 的 `--props` 参数传入。命令行渲染需要受支持的 Chromium 和相应系统依赖。

## 素材与许可

音频来源是用户提供的 GitHub 链接，仅用于本次创作。公开发布音乐影片前请确认相关音乐授权。场景原画为本项目生成。中文字体基于 Noto Sans SC 子集，许可证见 `public/fonts/OFL.txt`。Remotion 的使用遵循其自身许可条款。

## 验证

先运行开发服务器，再运行 `npx playwright test tests/studio.spec.ts --workers=1`，可检查播放、逐句跳转、字幕编辑、本地保存、项目恢复、影片下载和移动端布局。首次运行需通过 `npx playwright install --with-deps chromium` 安装测试浏览器。