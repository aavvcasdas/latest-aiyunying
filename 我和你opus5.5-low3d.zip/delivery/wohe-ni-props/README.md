# 番外MV《我和你》· 新增像素道具包（3D three.js 版 + 2D 像素版共用）

给 `aavvcasdas/latest-aiyunying`（分支 `arena/bb6a02da-latest-aiyunying`）补的 6 件道具。《我和你》分镜里要用，原仓库 `人物/道具/props.png` 里没有这些（它只有算盘、饭盆、书、茶杯、沙漏、放大镜、红鞋等 15 件）。

> **只生成了道具，没生成人物。** 仓库规矩是「人物形象提示词只是参考：出的图不进图集、不进成片」。
> 所以登场的八位 AI 娘全部用仓库原有的 Q 版像素图集（`人物/q版/*.png`、`人物/行走/walk.png`、`人物/变体/variants.png`）。
> 背景一张都没生成，全是 Canvas2D 代码画的（天空、房间、花园、地球、光线）。

## 3D 版（three.js）里怎么用的

- 道具和角色一样，当成**始终朝向镜头的纸片**（`PlaneGeometry` + `MeshBasicMaterial`，`alphaTest 0.3`，贴图 `NearestFilter`）立在 3D 场景里：
  球鞋（「球鞋」跑道特写）、探险背包（「装满」）、喷壶（「种下」）。
- 3D 版里**电视、玩具（泰迪熊 / 火箭 / 积木）、时钟、纸飞机、地球、花朵**都改用 three.js 几何体实时搭建（见 `src/lib/mv3d/kit.ts`），
  没再出图；`tv.png / toys.png / paperplane.png` 留给 2D 像素版和以后的模板线作品用。
- 3D 版没有额外生成任何人物或背景图，所以本包内容和 2D 版一样，没有新增文件。

### 在 three.js 工程里加载一件道具（与 MV 源码一致的写法）

```ts
const tex = new THREE.TextureLoader().load("/人物/道具/我和你/backpack.png");
tex.magFilter = tex.minFilter = THREE.NearestFilter; tex.colorSpace = THREE.SRGBColorSpace;
const geo = new THREE.PlaneGeometry(1, 1); geo.translate(0, 0.5, 0);           // 锚点：底边中心
const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.3, side: THREE.DoubleSide }));
mesh.scale.set(89 * 0.02 * 2.2, 96 * 0.02 * 2.2, 1);                            // 1px = 0.02 单位，与 Q 版角色同比例
// 每帧：mesh.rotation.y = Math.atan2(cam.x - mesh.position.x, cam.z - mesh.position.z);
```

## 包里有什么

```
人物/道具/我和你/
├── toys.png          玩具堆（泰迪熊 + 铁皮火箭 + A 字积木）      92×96   ← 「玩具 丢在旁边」
├── tv.png            老式显像管电视（雪花屏、兔耳天线）          68×96   ← 「电视 里没有新鲜」
├── sneakers.png      儿童球鞋（白底天蓝条、红鞋带）              72×32   ← 「球鞋 跑不过时间」
├── backpack.png      探险背包（藏宝图 + 黄铜指南针）              89×96   ← 「装满 不同的探险」
├── paperplane.png    纸飞机（白底天蓝条）                        72×49   ← 「我和你 飞到蓝蓝的天边」
├── wateringcan.png   小喷壶 + 向日葵种子袋                       72×45   ← 「我和你 种下满满的花园」
├── index.json        帧表：{name, file, w, h, anchor, 用在哪句}
└── 原图/*_hi.png     抠图后、缩小前的高分辨率透明底原图（要重新缩放时用）
人物/提示词/道具_我和你_绿幕.txt   6 件道具的生图提示词，跟 00_通用规则.txt 同一口径
```

规格跟母版图集对齐：
- **透明底 PNG、硬边 alpha**（只有 0 / 255，不带半透明边），跟 `NearestFilter` 硬边一致；
- 最长边 72~96 px，跟单帧约 84×90 的 Q 版角色并排时比例合适；
- 绿幕抠图：`g > 1.35·max(r, b)` 判定成背景，再做去绿溢色，最后 alpha 阈值 110 二值化。

## 怎么加进项目

1. 把压缩包解到仓库根目录，路径会自动对上：
   ```bash
   unzip wohe-ni-props.zip -d /path/to/latest-aiyunying
   ```
2. **直接当散图用（推荐）**：Vite 单页 / Canvas2D 工程里按 `index.json` 加载：
   ```ts
   const img = new Image();
   img.src = "/人物/道具/我和你/tv.png";
   // 锚点：底边中心。ctx.imageSmoothingEnabled = false;
   ctx.drawImage(img, x - img.width / 2 * s, y - img.height * s, img.width * s, img.height * s);
   ```
3. **想并进母版图集**（可选）：按 `人物动作替换.md`「像素道具 → 重烘图集」那节，把这 6 张加到
   `通用模板/engine/assets/cast_atlas.png` 的道具行，命名建议 `prop_toys / prop_tv / prop_sneakers / prop_backpack / prop_paperplane / prop_wateringcan`，
   然后跑 `python3 tools/split_cast.py` 重新拆出 `人物/道具/props.png` 和 `人物/index.json`。
   注意：这几件比原道具（约 22×16）大很多，并进 props 行要么缩到 ~28 px，要么单开一行。

## 《我和你》MV 用到的人物分工

| 角色 | 在 MV 里是谁 | 主要动作 |
|---|---|---|
| whale 鲸鱼娘（大肥鱼） | 「我」：孤单的小孩，想看更大的世界 | sad / walk / point / surprise / hop / wave / spin |
| claude 小克 | 「你」：陪在身边的人（研究资料里鲸鱼×小克这条关系线） | curtsy / walk / hop / nod / idle |
| gpt 白龙娘 | 带大家「飞到蓝蓝的天边」 | gpt_fly / float / hover |
| qwen / doubao / gemini / kimi | 「满满的花园」里的朋友 | hop / sway / spin / lookaround |
| zai 阔耳狐 | 打盹被「暖暖的光线」叫醒 | doze → alert → hop |

## 许可

- 道具：本次 AI 生成，跟随项目整体 CC BY-NC-SA 4.0 发布（署名、非商业、相同方式共享）。
- 角色形象：原作 ZipZipPipe《大AI和小AI们》，CC BY-NC-SA 4.0。
- 音乐《我和你》：原仓库 `我和你.WAV`，录音授权未核，公开发布前自行确认。
