import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CUES } from "@/data/cues";
import { CAST, CAST_ORDER } from "@/data/cast";
import { FH, FW, LOOKS, fmtTime } from "@/lib/mv";
import { useMVPlayer } from "@/hooks/useMVPlayer";
import { StageView } from "@/components/StageView";
import { LyricBar, type LyricTone } from "@/components/LyricBar";
import { Chip, SidePanel, TopBar, Transport, type Tab } from "@/components/Hud";

export default function App() {
  const p = useMVPlayer();
  const cue = CUES[p.cueIndex];
  const look = LOOKS[cue.shot.look];

  const [started, setStarted] = useState(false);
  const [stageReady, setStageReady] = useState(false);
  const [panel, setPanel] = useState(true);
  const [tab, setTab] = useState<Tab>("cues");
  const [tone, setTone] = useState<LyricTone>("gold");
  const [karaoke, setKaraoke] = useState(true);
  const [subtitles, setSubtitles] = useState(true);
  const [words3d, setWords3d] = useState(true);
  const [wordMark, setWordMark] = useState(true);
  const [showTags, setShowTags] = useState(false);
  const [fxOn, setFxOn] = useState(true);
  const [fit, setFit] = useState(0.42);

  const wrapRef = useRef<HTMLDivElement | null>(null);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const workRef = useRef<HTMLSpanElement | null>(null);
  const pointer = useRef({ x: 0, y: 0, tx: 0, ty: 0 });
  const rootRef = useRef<HTMLDivElement | null>(null);

  /* 图集最迟 4 秒后放行（图集随页面内嵌，正常一瞬就好） */
  useEffect(() => {
    const id = window.setTimeout(() => setStageReady(true), 4000);
    return () => window.clearTimeout(id);
  }, []);

  /* 画面按 1600×900 画，再整体缩放贴屏 */
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const measure = () => {
      const r = el.getBoundingClientRect();
      setFit(Math.max(0.2, Math.min(r.width / FW, r.height / FH)));
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    window.addEventListener("resize", measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [panel]);

  /* 每帧：能量写进 CSS 变量、烧录工作样片时码 */
  useEffect(() => {
    return p.subscribe((t, e) => {
      frameRef.current?.style.setProperty("--energy", e.toFixed(3));
      if (workRef.current) {
        workRef.current.textContent = `SHOT ${String(cue.i + 1).padStart(2, "0")} · ${fmtTime(t)} · LOOK ${cue.shot.look} · ${look.name} · SET ${cue.shot.set}`;
      }
    });
  }, [p, cue, look]);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const r = wrapRef.current?.getBoundingClientRect();
    if (!r) return;
    pointer.current.tx = ((e.clientX - r.left) / r.width) * 2 - 1;
    pointer.current.ty = ((e.clientY - r.top) / r.height) * 2 - 1;
  }, []);

  const start = useCallback(() => {
    setStarted(true);
    p.play();
    if (p.anchors.length === 0 && p.offset === 0) void p.autoAlign();
  }, [p]);

  const fullscreen = useCallback(() => {
    const el = rootRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        if (!started) start();
        else p.toggle();
      } else if (e.code === "ArrowRight") {
        e.preventDefault();
        p.seek(p.getTime() + (e.shiftKey ? 15 : 5));
      } else if (e.code === "ArrowLeft") {
        e.preventDefault();
        p.seek(p.getTime() - (e.shiftKey ? 15 : 5));
      } else if (e.code === "ArrowDown") {
        e.preventDefault();
        p.stepCue(1);
      } else if (e.code === "ArrowUp") {
        e.preventDefault();
        p.stepCue(-1);
      } else if (e.key === "f" || e.key === "F") {
        fullscreen();
      } else if (e.key === "s" || e.key === "S") {
        setSubtitles((v) => !v);
      } else if (e.key === "k" || e.key === "K") {
        setKaraoke((v) => !v);
      } else if (e.key === "w" || e.key === "W") {
        setWords3d((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [p, started, start, fullscreen]);

  const nextCue = useMemo(() => CUES.slice(p.cueIndex + 1).find((c) => c.text) ?? null, [p.cueIndex]);
  const onstage = useMemo(() => CAST_ORDER.filter((id) => cue.shot.cast.some((c) => c.id === id)), [cue]);

  return (
    <div ref={rootRef} className="flex h-full flex-col overflow-hidden bg-[#120d22]">
      <audio ref={p.audioRef} src={p.src} preload="auto" className="hidden" />

      <TopBar p={p} cue={cue} onTogglePanel={() => setPanel((v) => !v)} />

      <div className="relative flex min-h-0 flex-1">
        <main
          ref={wrapRef}
          onPointerMove={onPointerMove}
          onPointerLeave={() => {
            pointer.current.tx = 0;
            pointer.current.ty = 0;
          }}
          className="relative min-w-0 flex-1 overflow-hidden"
          style={{
            background: `radial-gradient(120% 100% at 50% 0%, ${look.swatch[0]}66, #0c0819 70%)`,
            transition: "background 700ms linear",
          }}
        >
          <div className="absolute inset-0 grid place-items-center">
            <div
              ref={frameRef}
              className="grain relative overflow-hidden"
              style={{
                width: FW,
                height: FH,
                transform: `scale(${fit})`,
                transformOrigin: "center center",
                borderRadius: 4,
                background: "#0c0819",
                boxShadow: `0 40px 120px rgba(0,0,0,.65), 0 0 0 1px rgba(255,209,102,.16), 0 0 calc(60px + var(--energy,0) * 120px) ${look.light}22`,
                transition: "box-shadow 300ms linear",
              }}
            >
              <StageView p={p} cue={cue} fxOn={fxOn} words3d={words3d} showTags={showTags} pointer={pointer} onReady={() => setStageReady(true)} />

              {/* 能量呼吸光 */}
              <div
                className="pointer-events-none absolute inset-0"
                style={{
                  background: `radial-gradient(70% 55% at 50% 78%, ${look.light}, transparent 70%)`,
                  opacity: "calc(.03 + var(--energy,0) * .18)",
                  mixBlendMode: "screen",
                }}
              />

              {/* 字卡（前奏 / 间奏 / 落幅） */}
              {cue.shot.card && (
                <div key={cue.i} className="reveal pointer-events-none absolute inset-x-0 top-[13%] flex flex-col items-center">
                  <div
                    className="font-display px-10 py-5 text-center"
                    style={{
                      fontSize: cue.i === 0 ? 96 : 62,
                      letterSpacing: cue.i === 0 ? 14 : 8,
                      color: "#fff6d8",
                      textShadow: `0 3px 0 ${look.ink}, 0 6px 0 ${look.ink}aa, 0 16px 40px rgba(8,4,20,.6)`,
                      transform: "rotate(-1.2deg)",
                    }}
                  >
                    {cue.shot.card.title}
                  </div>
                  {cue.shot.card.sub && (
                    <div
                      className="mt-2 rounded-full border px-5 py-1.5"
                      style={{
                        fontFamily: "var(--display)",
                        fontSize: cue.i === 0 ? 24 : 19,
                        letterSpacing: 6,
                        color: look.paper,
                        borderColor: `${look.light}66`,
                        background: "rgba(16,10,32,.45)",
                        transform: "rotate(0.8deg)",
                      }}
                    >
                      {cue.shot.card.sub}
                    </div>
                  )}
                </div>
              )}

              {subtitles && (
                <LyricBar
                  cue={cue}
                  next={nextCue}
                  getTime={p.getTime}
                  getEnergy={p.getEnergy}
                  tone={tone}
                  karaoke={karaoke}
                  onWord={wordMark}
                  visible={Boolean(cue.text)}
                  paused={!p.playing}
                />
              )}

              {/* 切镜：闪白 / 渐黑 */}
              {cue.shot.flash && (
                <div
                  key={`f${cue.i}`}
                  className="pointer-events-none absolute inset-0"
                  style={{
                    background: cue.shot.flash === "white" ? "#fff8ea" : "#08050f",
                    animation: "flashWhite 460ms ease-out forwards",
                    zIndex: 70,
                  }}
                />
              )}

              <div className="vignette pointer-events-none absolute inset-0" style={{ zIndex: 55 }} />

              {/* 左侧镜号轨 */}
              <div className="pointer-events-none absolute left-3 top-1/2 flex -translate-y-1/2 flex-col gap-[3px]" style={{ zIndex: 74 }}>
                {CUES.map((c) => (
                  <span
                    key={c.i}
                    style={{
                      width: c.i === cue.i ? 16 : 7,
                      height: 3,
                      borderRadius: 2,
                      background: c.i === cue.i ? "#ffd166" : c.i < cue.i ? "rgba(255,224,170,.34)" : "rgba(255,224,170,.14)",
                      transition: "all 260ms ease-out",
                      boxShadow: c.i === cue.i ? "0 0 10px rgba(255,209,102,.8)" : "none",
                    }}
                  />
                ))}
              </div>

              {/* 工作样片烧录 */}
              <div className="pointer-events-none absolute bottom-2.5 left-4 flex items-center gap-2" style={{ zIndex: 74 }}>
                <span className="h-2 w-2 rounded-full" style={{ background: p.playing ? "#ff6b6b" : "#7f8db0", boxShadow: p.playing ? "0 0 10px #ff6b6b" : "none" }} />
                <span ref={workRef} className="font-mono-num text-[11px] tracking-[0.16em] text-[rgba(255,246,224,.55)]">
                  SHOT 01 · 0:00.00 · LOOK dusk · 黄昏 · SET shore
                </span>
              </div>
              <div className="pointer-events-none absolute bottom-2.5 right-4 flex items-center gap-2" style={{ zIndex: 74 }}>
                <span className="font-mono-num text-[11px] tracking-[0.16em] text-[rgba(255,246,224,.4)]">three.js · 1600 × 900 · 像素纸片人</span>
              </div>

              {/* 开场场记卡 */}
              {!started && (
                <div className="absolute inset-0" style={{ zIndex: 80, background: "radial-gradient(90% 70% at 30% 70%, rgba(10,6,22,.72), rgba(10,6,22,.42))" }}>
                  <div className="paper absolute left-[6%] top-[50%] w-[540px] -rotate-[1.6deg] p-6" style={{ borderRadius: 3, boxShadow: "0 26px 60px rgba(6,3,16,.6)" }}>
                    <div className="flex items-center gap-2 text-[11px] tracking-[0.3em] text-[#7a5a2b]">
                      <span className="inline-block h-[3px] w-8 bg-[#c9922f]" />
                      番外 MV · 复刻 · 立体童话书做法
                    </div>
                    <h2 className="font-display mt-2 text-[64px] leading-[0.95] text-[#241c44]" style={{ textShadow: "0 3px 0 #f0c987, 0 6px 0 #d9a857, 0 12px 22px rgba(80,50,10,.35)" }}>
                      背对背
                      <br />
                      拥抱
                    </h2>
                    <p className="mt-3 text-[13px] leading-relaxed text-[#4a3d63]">
                      照《童话镇》那套：<span className="font-semibold">three.js 搭的立体世界</span>（toon 体块 + 墨线 + 三灯 look）里，立着仓库自带的
                      <span className="font-semibold">像素纸片人</span>；歌词按<span className="font-semibold">字与词</span>做成挂在镜头前的立体字牌，唱到哪张哪张往前顶。
                      全片 {CUES.length} 镜 / {fmtTime(p.duration)}。
                    </p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {onstage.length === 0 && <Chip color="#7a5a2b">空镜 · 黄昏纸岸</Chip>}
                      {CAST_ORDER.slice(0, 6).map((id) => (
                        <span key={id} className="rounded-[3px] border border-[#d8bd8c] bg-[#fffaf0] px-2 py-[3px] text-[11px] text-[#5b4326]">
                          {CAST[id].name}
                        </span>
                      ))}
                    </div>
                    <button
                      type="button"
                      onClick={start}
                      disabled={!stageReady}
                      className="btn mt-5 flex w-full items-center justify-center gap-3 rounded-[4px] border-2 border-[#8a5a12] px-5 py-3 disabled:opacity-60"
                      style={{
                        background: "linear-gradient(180deg,#ffd98a,#f2b64c)",
                        color: "#3a2408",
                        fontFamily: "var(--display)",
                        fontSize: 22,
                        letterSpacing: 8,
                        boxShadow: "0 8px 0 #a9762a, 0 16px 26px rgba(80,50,10,.35)",
                      }}
                    >
                      <svg width="18" height="20" viewBox="0 0 18 20">
                        <path d="M1 1.6 L16.4 10 L1 18.4 Z" fill="currentColor" />
                      </svg>
                      {stageReady ? "放这支片子" : "纸片人装载中…"}
                    </button>
                    <div className="mt-2 text-[11px] tracking-[0.12em] text-[#7a6a4b]">空格 = 播放 / 暂停 · ←→ 跳 5 秒 · ↑↓ 换镜 · W 立体字牌 · S 字幕条 · K 下一句</div>
                    <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-[#e2cda4] pt-2 text-[11px] text-[#6c5a3c]">
                      <span>音源：背对背拥抱.m4a（{fmtTime(p.duration)} · 已内嵌）</span>
                      <a className="underline decoration-dotted underline-offset-2 hover:text-[#a3641a]" href="https://github.com/aavvcasdas/latest-aiyunying/blob/arena/bb6a02da-latest-aiyunying/%E8%83%8C%E5%AF%B9%E8%83%8C%E6%8B%A5%E6%8A%B1.mp4" target="_blank" rel="noreferrer">
                        对照原片 mp4
                      </a>
                      <a className="underline decoration-dotted underline-offset-2 hover:text-[#a3641a]" href="https://github.com/aavvcasdas/latest-aiyunying/tree/arena/bb6a02da-latest-aiyunying" target="_blank" rel="noreferrer">
                        素材分支
                      </a>
                    </div>
                  </div>

                  <div className="absolute right-[5%] top-[12%] w-[280px] rotate-[2deg] rounded-[3px] border border-[rgba(255,209,102,.35)] bg-[rgba(16,10,32,.72)] p-3 backdrop-blur-[2px]">
                    <div className="font-display text-[15px] tracking-[0.2em] text-[#ffe9b8]">选角</div>
                    <ul className="mt-2 space-y-1 text-[11.5px] leading-snug text-[rgba(255,244,224,.72)]">
                      <li><span className="text-[#ffd166]">本鲸</span> 主角 · 背对背的那一半</li>
                      <li><span className="text-[#ffd166]">小克</span> 戴金冠 · 先听完再改一个字</li>
                      <li><span className="text-[#ffd166]">Kimi</span> 旧账卷轴 · 翻不完的那条</li>
                      <li><span className="text-[#ffd166]">千问</span> 排顺序 · 这一步不能跳</li>
                      <li><span className="text-[#ffd166]">猫</span> 绕圈 · 真话在圈上跑</li>
                      <li><span className="text-[#ffd166]">豆包</span> 送信 · 把话送到手上</li>
                      <li><span className="text-[#ffd166]">智谱</span> 影子 · 不肯长大的那个</li>
                      <li><span className="text-[#ffd166]">龙娘</span> 烽火 · 立起来又飞走</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>

        {panel && (
          <div className="absolute inset-y-0 right-0 z-40 w-[86vw] max-w-[380px] shrink-0 lg:static lg:z-20 lg:w-[368px] lg:max-w-none">
            <SidePanel p={p} cue={cue} tab={tab} setTab={setTab} />
          </div>
        )}
      </div>

      <Transport
        p={p}
        tone={tone}
        setTone={setTone}
        karaoke={karaoke}
        setKaraoke={setKaraoke}
        subtitles={subtitles}
        setSubtitles={setSubtitles}
        showTags={showTags}
        setShowTags={setShowTags}
        wordMark={wordMark}
        setWordMark={setWordMark}
        fxOn={fxOn}
        setFxOn={setFxOn}
        words3d={words3d}
        setWords3d={setWords3d}
        onFullscreen={fullscreen}
      />
    </div>
  );
}
